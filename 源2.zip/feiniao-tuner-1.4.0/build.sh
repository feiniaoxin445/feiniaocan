#!/usr/bin/env bash
# 飞鸟调参 · 构建脚本(不依赖 Gradle,直连 aapt2 + javac + d8 + apksigner)
set -euo pipefail

export JAVA_HOME="${JAVA_HOME:-/usr/lib/jvm/java-17-openjdk-amd64}"
export PATH="$JAVA_HOME/bin:$PATH"

# 允许用环境变量覆盖,默认走沙箱内置工具链
BT="${BT:-/tmp/asdk/android-14}"
PLAT="${PLAT:-/tmp/asdk/android-35/android.jar}"
OUT=feiniao-tuner.apk

cd "$(dirname "$0")"
rm -rf build
mkdir -p build/compiled build/gen build/classes build/dex

echo "[1/6] 编译资源"
"$BT/aapt2" compile --dir res -o build/compiled/res.zip

echo "[2/6] 链接资源与清单"
"$BT/aapt2" link -o build/app.apk \
  -I "$PLAT" \
  --manifest AndroidManifest.xml \
  --java build/gen \
  --min-sdk-version 24 --target-sdk-version 34 \
  --version-code 9 --version-name 1.4.0 \
  --auto-add-overlay \
  build/compiled/res.zip

echo "[3/6] 编译 Java 源码"
find java build/gen -name '*.java' > build/sources.txt
javac -source 8 -target 8 -nowarn -encoding UTF-8 \
  -bootclasspath "$PLAT" \
  -classpath "$BT/core-lambda-stubs.jar" \
  -d build/classes \
  @build/sources.txt

echo "[4/6] 转 dex"
find build/classes -name '*.class' > build/classes.txt
"$BT/d8" --lib "$PLAT" --min-api 24 --release \
  --output build/dex @build/classes.txt

echo "[5/6] 打包"
cp build/app.apk build/unsigned.apk
( cd build && zip -q -j unsigned.apk dex/classes.dex )
"$BT/zipalign" -f -p 4 build/unsigned.apk build/aligned.apk

if [ ! -f keystore.jks ]; then
  echo "     生成签名密钥"
  keytool -genkeypair -keystore keystore.jks -alias feiniao \
    -keyalg RSA -keysize 2048 -validity 10000 \
    -storepass feiniao123 -keypass feiniao123 \
    -dname "CN=Feiniao Tuner, OU=Dev, O=Zaka, L=NA, ST=NA, C=CN" >/dev/null 2>&1
fi

echo "[6/6] 签名"
"$BT/apksigner" sign \
  --ks keystore.jks --ks-pass pass:feiniao123 --key-pass pass:feiniao123 \
  --v1-signing-enabled true --v2-signing-enabled true --v3-signing-enabled true \
  --out "$OUT" build/aligned.apk

ls -la "$OUT"
echo "BUILD_OK"

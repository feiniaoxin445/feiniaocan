package com.feiniao.tuner;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

import com.feiniao.tuner.core.Analysis;
import com.feiniao.tuner.model.Segment;

/**
 * 距离热力条 —— 把 0 ~ 总距离 铺成一条带刻度的横条:
 *
 *   绿色 = 该距离段打中过(越亮命中率越高)
 *   红色 = 该距离段只有没打中的记录
 *   灰色 = 本次视频没有覆盖到
 *
 * 一眼看出参数在哪段距离站得住、哪段距离是空的。
 */
public class DistanceBar extends View {

    private Analysis.DistSummary d;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path clip = new Path();
    private final RectF rr = new RectF();

    public DistanceBar(Context c) {
        super(c);
        t.setTextAlign(Paint.Align.CENTER);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
    }

    public void setData(Analysis.DistSummary s) {
        d = s;
        invalidate();
    }

    @Override
    protected void onMeasure(int w, int h) {
        int width = MeasureSpec.getSize(w);
        setMeasuredDimension(width, Ui.dp(getContext(), 46));
    }

    @Override
    protected void onDraw(Canvas cv) {
        final int w = getWidth();
        final Context c = getContext();
        final float barTop = Ui.dp(c, 4);
        final float barH = Ui.dp(c, 24);
        final float left = 0f;
        final float right = w;
        final float radius = Ui.dp(c, 8);

        /* ---- 底槽 ---- */
        p.setColor(Ui.SURFACE_2);
        rr.set(left, barTop, right, barTop + barH);
        cv.drawRoundRect(rr, radius, radius, p);

        if (d != null && d.cells > 0) {
            int cells = d.cells;
            float cw = (right - left) / cells;

            cv.save();
            clip.reset();
            clip.addRoundRect(rr, radius, radius, Path.Direction.CW);
            cv.clipPath(clip);

            for (int i = 0; i < cells; i++) {
                int total = d.cellTotal != null && i < d.cellTotal.length ? d.cellTotal[i] : 0;
                int hit = d.cellHit != null && i < d.cellHit.length ? d.cellHit[i] : 0;

                int col;
                if (total == 0) {
                    col = Ui.SURFACE_2;
                } else if (hit > 0) {
                    int rate = Math.round(hit * 100f / total);
                    int alpha = 90 + Math.round(165f * rate / 100f);
                    col = withAlpha(Ui.GREEN, alpha);
                } else {
                    col = withAlpha(Ui.RED, 190);
                }
                p.setColor(col);
                cv.drawRect(left + i * cw, barTop, left + (i + 1) * cw + 0.6f, barTop + barH, p);
            }
            cv.restore();

            /* ---- 打中 / 没打中的距离标记 ---- */
            if (d.measured) {
                p.setColor(withAlpha(Ui.GREEN, 255));
                if (d.hasHit) {
                    float x = pos(d, d.hitMin, left, right);
                    cv.drawCircle(x, barTop + barH * 0.5f, Ui.dp(c, 2.2f), p);
                }
                p.setColor(withAlpha(Ui.RED, 255));
                if (d.hasMiss) {
                    float x = pos(d, d.missMin, left, right);
                    cv.drawCircle(x, barTop + barH * 0.5f, Ui.dp(c, 2.2f), p);
                }
            }
        }

        /* ---- 刻度 ---- */
        float total = d != null && d.total > 0 ? d.total : 400f;
        t.setTextSize(Ui.dp(c, 9.6f));
        t.setColor(Ui.TEXT_DIM);
        float baseY = barTop + barH + Ui.dp(c, 12);
        for (int i = 0; i <= 4; i++) {
            float k = i / 4f;
            float v = total * k;
            float x = left + (right - left) * k;
            if (i == 0) t.setTextAlign(Paint.Align.LEFT);
            else if (i == 4) t.setTextAlign(Paint.Align.RIGHT);
            else t.setTextAlign(Paint.Align.CENTER);
            cv.drawText(Segment.trim(Math.round(v)) + (i == 4 ? " m" : ""), x, baseY, t);
        }
        t.setTextAlign(Paint.Align.CENTER);
    }

    private float pos(Analysis.DistSummary s, float meters, float left, float right) {
        float total = s.total > 0 ? s.total : 400f;
        float k = meters / total;
        if (k < 0f) k = 0f;
        if (k > 1f) k = 1f;
        return left + (right - left) * k;
    }

    private static int withAlpha(int color, int a) {
        if (a < 0) a = 0;
        if (a > 255) a = 255;
        return (color & 0x00FFFFFF) | (a << 24);
    }
}

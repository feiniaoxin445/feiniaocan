package com.feiniao.tuner;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.view.animation.Interpolator;

/**
 * 启动过渡动画(朱雀 · 液态玻璃):
 *
 *   ① 液态色雾在深空底上慢慢游开,底部浮出一层液面,几片玻璃薄片飘起来
 *   ② 一只朱雀从右侧踏步进场 —— 长腿交替落地、每落一步脚下荡开一圈涟漪,
 *      身体随步子轻轻起伏,脑后三缕长冠翎跟着一步一摇
 *   ③ 走到画面中心站定,冠翎抖一下定住,双翼自前缘向后逐根张成羽扇,
 *      三缕长尾羽同时向后荡开,成一座展翼立像;翼尖抖落的飞羽缓缓飘下
 *   ④ 立像收作一颗光点,沉降到画面中心
 *   ⑤ 光点拉出玻璃圆环,环上一道折射光扫过,环内朱雀展翼标长出来
 *   ⑥ 「飞鸟信」逐字浮现、字距收拢,液态下划线展开
 *   ⑦ 整幅画面玻璃化淡出(自身 alpha 淡出),与主界面交叉过渡
 *
 * 全部由代码绘制,零图片资源。
 * 节奏:005 起步 → 38 定步 → 42 张翼 → 64 满翼 → 78 化形 → 92 圆环 → 100 交接。
 */
public class SplashView extends View {

    public interface Done { void onDone(); }

    /** 整段动画时长(主界面据此排交叉淡入) */
    public static final long DURATION = 5200L;
    /** 主界面开始淡入的进度点 */
    public static final float HANDOFF_AT = 0.84f;

    private static final int SHARDS  = 6;    // 玻璃薄片
    private static final int QUILLS  = 8;    // 每侧主飞羽
    private static final int CREST   = 3;    // 冠翎(朱雀三缕)
    private static final int TAIL    = 5;    // 长尾羽
    private static final int FALLING = 12;   // 飘落飞羽

    private float p;
    private ValueAnimator anim;
    private final Done done;
    private boolean fired;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint soft = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glass = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);

    private final Path tmp = new Path();
    private final Path limb = new Path();
    private final Path mark = new Path();
    private final RectF rr = new RectF();

    private static final Interpolator OUT = new DecelerateInterpolator(2.4f);
    private static final Interpolator OUT_SOFT = new DecelerateInterpolator(1.5f);
    /** 张翼手感:撑开时带一点过冲,再落回定格(只放在展翼那一段) */
    private static final Interpolator OVER = new OvershootInterpolator(0.85f);

    public SplashView(Context c, Done d) {
        super(c);
        this.done = d;
        setBackgroundColor(Ui.BG);

        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setStrokeJoin(Paint.Join.ROUND);

        fill.setStyle(Paint.Style.FILL);
        glass.setStyle(Paint.Style.FILL);

        txt.setTextAlign(Paint.Align.CENTER);
        txt.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));

        buildWingMark();
    }

    /* ================= 生命周期 ================= */

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (anim == null && !fired) {
            anim = ValueAnimator.ofFloat(0f, 1f);
            anim.setDuration(DURATION);
            anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator a) {
                    p = (Float) a.getAnimatedValue();
                    /* 末段本 View 自身淡出,与同步淡入的主界面叠着走 */
                    setAlpha(1f - seg(p, HANDOFF_AT + 0.06f, 1f));
                    invalidate();
                }
            });
            anim.addListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator a) {
                    p = 1f;
                    invalidate();
                    finish();
                }
            });
            anim.start();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        stop();
        super.onDetachedFromWindow();
    }

    private void stop() {
        if (anim != null) {
            anim.removeAllListeners();
            anim.cancel();
            anim = null;
        }
    }

    private void finish() {
        if (fired) return;
        fired = true;
        stop();
        if (done != null) done.onDone();
    }

    /** 点一下可以跳过:先快进到立像定格,再柔和淡出,不硬切 */
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
            if (p < 0.76f) {
                p = 0.76f;          // 先快进到立像定格,避免"啪"一下黑屏
                invalidate();
            }
            animate().alpha(0f).setDuration(200)
                    .withEndAction(new Runnable() {
                        @Override public void run() { finish(); }
                    }).start();
            return true;
        }
        return super.onTouchEvent(e);
    }

    /* ================= 绘制 ================= */

    @Override
    protected void onDraw(Canvas cv) {
        final int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;

        cv.drawColor(Ui.BG);

        final float cx = w * 0.5f;
        final float cy = h * 0.40f;
        final float unit = Math.min(w * 0.94f, h * 0.56f);
        final float groundY = cy + unit * 0.60f;

        final float fade = 1f - seg(p, 0.90f, 1f);

        /* ---------- ① 液态色雾 ---------- */
        drawFog(cv, cx, cy, unit, w, h, fade);

        /* ---------- ② 液面 + 玻璃薄片 ---------- */
        drawGround(cv, w, h, groundY, unit, fade);
        drawShards(cv, cx, cy, unit, fade);

        /* ---------- ③ 朱雀:踏步入场 → 站定 → 张翼 ---------- */
        final float walkT0  = seg(p, 0.05f, 0.36f);
        final float walkT   = smooth(walkT0);
        final float standT  = OUT.getInterpolation(seg(p, 0.32f, 0.46f));
        final float openAll = OVER.getInterpolation(seg(p, 0.38f, 0.64f));
        final float tailAll = OUT.getInterpolation(seg(p, 0.42f, 0.70f));
        final float morph   = seg(p, 0.70f, 0.84f);

        final float stepPhase = walkT * 5.0f * 2f * (float) Math.PI;
        final float jolt = seg(p, 0.30f, 0.50f);
        final float sway = (float) Math.sin(stepPhase) * 0.42f * (1f - standT)
                + (float) Math.sin(jolt * Math.PI * 4f) * (1f - jolt) * 1.3f * standT;

        final float birdIn = seg(p, 0.04f, 0.12f);
        final float birdA = birdIn * (1f - morph) * fade;

        final float bx = lerp(w * 1.18f, cx, walkT);
        final float bh = unit * lerp(0.50f, 0.62f, standT);

        if (birdA > 0.012f) {
            // 脚下的涟漪(走一步荡一圈)
            if (walkT0 > 0.01f && walkT0 < 0.999f && standT < 0.99f) {
                drawSteps(cv, bx, groundY, unit, stepPhase, birdA * (1f - standT));
            }
            float s = bh * (1f - 0.90f * morph);
            float ax = lerp(bx, cx, morph);
            float ay = lerp(groundY, cy, morph) + s * 0.30f * (1f - morph);
            cv.save();
            cv.translate(ax, ay);
            cv.scale(s, s);
            drawPhoenix(cv, stepPhase, standT, openAll, tailAll, sway, birdA);
            cv.restore();
        }

        /* ---------- ④ 翼尖抖落的飞羽 ---------- */
        drawFalling(cv, cx, cy, unit, seg(p, 0.56f, 0.88f), fade);

        /* ---------- ⑤ 光点 → 玻璃圆环 + 朱雀展翼标 ---------- */
        float logoA = seg(p, 0.74f, 0.92f) * fade;
        if (logoA > 0.002f) {
            float ringT = OUT.getInterpolation(seg(p, 0.71f, 0.90f));
            float r = unit * 0.20f;

            // 玻璃盘:环内一层薄玻璃
            soft.setShader(new RadialGradient(cx, cy, r * 1.5f,
                    new int[]{withAlpha(0xFFBFD6FF, (int) (0x22 * logoA)), 0x00000000},
                    new float[]{0f, 1f}, Shader.TileMode.CLAMP));
            cv.drawCircle(cx, cy, r * 1.5f, soft);
            soft.setShader(null);

            // 外圈柔晕
            line.setStrokeWidth(Math.max(1f, unit * 0.008f));
            line.setColor(withAlpha(Ui.PRIMARY, (int) (44 * logoA)));
            cv.drawCircle(cx, cy, r + unit * 0.045f, line);

            // 主环(顺时针生长)
            RectF oval = new RectF(cx - r, cy - r, cx + r, cy + r);
            line.setStrokeWidth(Math.max(2f, unit * 0.011f));
            line.setColor(withAlpha(Ui.PRIMARY, (int) (236 * logoA)));
            cv.drawArc(oval, -90f, 360f * ringT, false, line);

            // 环上跑光
            if (ringT < 1f) {
                double ang = Math.toRadians(-90.0 + 360.0 * ringT);
                float hx = (float) (cx + Math.cos(ang) * r);
                float hy = (float) (cy + Math.sin(ang) * r);
                soft.setShader(new RadialGradient(hx, hy, unit * 0.06f,
                        new int[]{withAlpha(Ui.PRIMARY, (int) (210 * logoA)), 0x00FFFFFF},
                        new float[]{0f, 1f}, Shader.TileMode.CLAMP));
                cv.drawCircle(hx, hy, unit * 0.06f, soft);
                soft.setShader(null);
            }

            // 环内朱雀展翼标(玻璃渐变)
            float birdT = OUT_SOFT.getInterpolation(seg(p, 0.76f, 0.94f)) * fade;
            if (birdT > 0.01f) {
                float bs = r * (0.46f + 0.56f * birdT);
                drawWingMark(cv, cx, cy + unit * 0.002f, bs, birdT * logoA);
            }
        }

        /* ---------- ⑥ 品牌字 ---------- */
        float wordT = seg(p, 0.84f, 0.97f);
        if (wordT > 0.002f) {
            drawBrand(cv, cx, cy + unit * 0.54f, unit, wordT * fade);
        }

        /* ---------- ⑦ 交叉交接 ----------
         * 不再往画布上叠黑,而是让本 View 自身 alpha 淡出(见 updateListener),
         * 底下的主界面同一时间淡入 —— 两屏叠着走,交接处不再有黑场硬切。 */
        if (fade < 0.998f) {
            cv.drawColor(withAlpha(Ui.BG, (int) (255 * (1f - fade) * 0.85f)));
        }
    }

    /* ================= ① 色雾 ================= */

    private void drawFog(Canvas cv, float cx, float cy, float unit,
                         float w, float h, float fade) {
        float t = seg(p, 0f, 0.5f);
        if (t <= 0.01f) return;

        final float[] kx = {0.20f, 0.82f, 0.42f, 0.66f};
        final float[] ky = {0.16f, 0.32f, 0.84f, 0.60f};
        final int[] cols = {Ui.PRIMARY, Ui.PURPLE, 0xFF37B5A8, Ui.AMBER};
        final float[] rad = {0.46f, 0.40f, 0.42f, 0.30f};

        for (int i = 0; i < kx.length; i++) {
            float ph = i * 2.1f;
            float px = cx + (kx[i] - 0.5f) * w
                    + (float) Math.sin(p * 3.1f + ph) * unit * 0.13f;
            float py = h * ky[i] + (float) Math.cos(p * 2.6f + ph) * unit * 0.11f;
            float r = unit * rad[i];
            int a = (int) (0x2E * t * fade);
            if (a <= 1) continue;
            soft.setShader(new RadialGradient(px, py, r,
                    new int[]{withAlpha(cols[i], a), withAlpha(cols[i], 0)},
                    new float[]{0f, 1f}, Shader.TileMode.CLAMP));
            cv.drawCircle(px, py, r, soft);
            soft.setShader(null);
        }
    }

    /* ================= ② 液面 ================= */

    private void drawGround(Canvas cv, float w, float h, float groundY,
                            float unit, float fade) {
        float t = OUT_SOFT.getInterpolation(seg(p, 0.06f, 0.46f)) * fade;
        if (t <= 0.01f) return;

        // 液面:一条平铺的冷光,越往下越淡
        rr.set(0f, groundY, w, groundY + unit * 0.20f);
        soft.setShader(new LinearGradient(0f, rr.top, 0f, rr.bottom,
                new int[]{withAlpha(Ui.PRIMARY, (int) (34 * t)),
                        withAlpha(Ui.PURPLE, (int) (10 * t)),
                        0x00000000},
                new float[]{0f, 0.42f, 1f}, Shader.TileMode.CLAMP));
        cv.drawRect(rr, soft);
        soft.setShader(null);

        // 水面那道亮线
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(Math.max(1f, unit * 0.0032f));
        line.setShader(new LinearGradient(0f, 0f, w, 0f,
                new int[]{0x00FFFFFF, withAlpha(0xFFCFE0FF, (int) (120 * t)),
                        withAlpha(0xFFCFE0FF, (int) (120 * t)), 0x00FFFFFF},
                new float[]{0f, 0.22f, 0.78f, 1f}, Shader.TileMode.CLAMP));
        cv.drawLine(w * 0.05f, groundY, w * 0.95f, groundY, line);
        line.setShader(null);

        // 远景点缀:几道短横线,撑一下纵深
        line.setStrokeWidth(Math.max(1f, unit * 0.002f));
        line.setColor(withAlpha(0xFF9FC0F5, (int) (40 * t)));
        for (int i = 0; i < 4; i++) {
            float y = groundY + unit * (0.045f + i * 0.038f);
            float half = unit * (0.34f - i * 0.055f);
            cv.drawLine(cx0(w) - half, y, cx0(w) + half, y, line);
        }
    }

    private static float cx0(float w) { return w * 0.5f; }

    /** 走进来的每一步:脚下荡开的涟漪 */
    private void drawSteps(Canvas cv, float x, float groundY, float unit,
                           float phase, float alpha) {
        if (alpha <= 0.01f) return;
        line.setStyle(Paint.Style.STROKE);
        for (int i = 0; i < 3; i++) {
            float k = phase / (float) Math.PI + i / 3f;
            k = k - (float) Math.floor(k);
            float r = unit * (0.035f + 0.085f * k);
            float a = (1f - k) * (1f - k) * 0.34f * alpha;
            if (a <= 0.01f) continue;
            line.setStrokeWidth(Math.max(1f, unit * 0.004f * (1f - k * 0.6f)));
            line.setColor(withAlpha(0xFFBFD6FF, (int) (255 * a)));
            rr.set(x - r, groundY - r * 0.30f, x + r, groundY + r * 0.30f);
            cv.drawOval(rr, line);
        }
    }

    /* ================= 玻璃薄片 ================= */

    private void drawShards(Canvas cv, float cx, float cy, float unit, float fade) {
        float t = OUT.getInterpolation(seg(p, 0.22f, 0.76f));
        if (t <= 0.001f) return;
        float a = seg(p, 0.22f, 0.40f) * (1f - seg(p, 0.74f, 0.90f)) * fade;
        if (a <= 0.01f) return;

        final float d = Ui.density(getContext());

        for (int i = 0; i < SHARDS; i++) {
            float ph = i * 1.73f;
            float ang = ph + p * 1.4f;
            float startR = unit * (1.45f + 0.22f * i);
            float endR = unit * 0.27f;
            float r = lerp(startR, endR, t);

            float sx = cx + (float) Math.cos(ang) * r;
            float sy = cy + (float) Math.sin(ang) * r * 0.62f;

            float sw = unit * (0.18f + 0.05f * (i % 3));
            float sh = unit * (0.032f + 0.011f * ((i + 1) % 3));
            float rot = lerp((float) Math.toDegrees(ang), (float) Math.toDegrees(ang) + 42f, t);

            cv.save();
            cv.translate(sx, sy);
            cv.rotate(rot);
            rr.set(-sw * 0.5f, -sh * 0.5f, sw * 0.5f, sh * 0.5f);

            glass.setShader(new LinearGradient(rr.left, rr.top, rr.right, rr.bottom,
                    withAlpha(0xFFFFFFFF, (int) (40 * a)),
                    withAlpha(0xFF9FC0F5, (int) (16 * a)),
                    Shader.TileMode.CLAMP));
            cv.drawRoundRect(rr, sh * 0.5f, sh * 0.5f, glass);
            glass.setShader(null);

            line.setStyle(Paint.Style.STROKE);
            line.setStrokeWidth(Math.max(1f, d));
            line.setColor(withAlpha(0xFFFFFFFF, (int) (70 * a)));
            cv.drawRoundRect(rr, sh * 0.5f, sh * 0.5f, line);

            cv.restore();
        }
    }

    /* ================= ③ 朱雀本体 ================= */

    /**
     * 单位坐标:脚底 y=0、头顶 y≈-0.95、身体中心 x≈0,面朝 +x。
     * 调用方已经 translate 到脚下、scale 到身高。
     * 跟蛇鹫的差别集中在三处:三缕长冠翎、五缕带分叉的长尾羽、张得更开的羽扇。
     */
    private void drawPhoenix(Canvas cv, float phase, float stand, float open,
                             float tailOpen, float sway, float alpha) {
        final int col = withAlpha(0xFFEAF2FF, (int) (255 * clamp(alpha)));

        fill.setStyle(Paint.Style.FILL);
        fill.setShader(null);

        /* ---- 长尾羽(先画,压在身后;五缕:向后下扫再扬起) ---- */
        fill.setColor(col);
        final float te = clamp(tailOpen);
        for (int i = 0; i < TAIL; i++) {
            float t = i / (float) (TAIL - 1);
            float deg = lerp(148f, 196f, t);
            float grow = 0.32f + 0.68f * te;              // 收着时只露一截,站定后长开
            float len = lerp(0.46f, 0.34f, t) * grow
                    * (1f + 0.03f * (float) Math.sin(sway * 3f + i));
            float bx0 = -0.026f - i * 0.009f;
            float by0 = -0.560f + i * 0.021f;
            quill(tmp, bx0, by0, deg, len, 0.034f);
            cv.drawPath(tmp, fill);
            // 羽梢再甩一缕,做出凤尾那种分叉卷翘
            float ax = bx0 + (float) Math.cos(Math.toRadians(deg)) * len;
            float ay = by0 + (float) Math.sin(Math.toRadians(deg)) * len;
            quill(tmp, ax, ay, deg + lerp(24f, 54f, t), len * 0.40f, 0.018f);
            cv.drawPath(tmp, fill);
        }

        /* ---- 双翼(压在身体后面) ---- */
        drawWings(cv, open, col, alpha);

        /* ---- 躯干(竖纺锤,比蛇鹫瘦一点) ---- */
        tmp.reset();
        rr.set(-0.072f, -0.760f, 0.076f, -0.436f);
        tmp.addOval(rr, Path.Direction.CW);
        cv.drawPath(tmp, fill);

        /* ---- 颈(S 形,更长更秀) ---- */
        limb.reset();
        limb.moveTo(0.012f, -0.694f);
        limb.quadTo(0.004f, -0.792f, 0.046f, -0.874f);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(0.046f);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setColor(col);
        cv.drawPath(limb, line);

        /* ---- 头 ---- */
        tmp.reset();
        tmp.addCircle(0.064f, -0.898f, 0.042f, Path.Direction.CW);
        cv.drawPath(tmp, fill);

        /* ---- 尖直喙(朱雀不是钩喙) ---- */
        tmp.reset();
        tmp.moveTo(0.092f, -0.912f);
        tmp.quadTo(0.140f, -0.908f, 0.172f, -0.898f);
        tmp.quadTo(0.138f, -0.884f, 0.090f, -0.882f);
        tmp.close();
        cv.drawPath(tmp, fill);

        /* ---- 三缕长冠翎(脑后向后上,随步一摇) ---- */
        for (int i = 0; i < CREST; i++) {
            float t = CREST <= 1 ? 0f : i / (float) (CREST - 1);
            float deg = lerp(196f, 232f, t) + sway * (7f + i * 3.0f);
            float len = 0.22f + 0.10f * (float) Math.sin(Math.PI * (0.30f + 0.70f * t));
            float bx0 = 0.052f - i * 0.014f;
            float by0 = -0.918f - i * 0.006f;
            quill(tmp, bx0, by0, deg, len, 0.020f);
            cv.drawPath(tmp, fill);
        }

        /* ---- 细长腿(交替落地) ---- */
        drawLegs(cv, phase, stand, col);
    }

    /** 每侧翼展成一把羽扇:自前缘向后逐根张开,末段留一点过冲回弹 */
    private void drawWings(Canvas cv, float open, int col, float alpha) {
        fill.setColor(col);
        for (int side = 0; side < 2; side++) {
            final float dir = side == 0 ? -1f : 1f;
            for (int i = 0; i < QUILLS; i++) {
                float t = i / (float) (QUILLS - 1);
                // 每根带一点延迟:前缘先张,后缘跟上
                float d = (open - i * 0.040f) / 0.72f;
                if (d < 0f) d = 0f;
                if (d > 1.16f) d = 1.16f;            // 放宽上限,留住那点过冲
                float e = OUT.getInterpolation(clamp(d));
                float over = d > 1f ? (d - 1f) : 0f; // 过冲量:再撑出去一点再收
                float wid = lerp(0.28f, lerp(0.94f, 0.60f, t), e) * (1f + over * 0.45f);
                float wdt = lerp(0.030f, 0.050f, e) * (1f - over * 0.22f);

                // 收拢时贴体下垂,张开时扫成扇形(朱雀比蛇鹫张得更开)
                float deg = 86f + t * 4f;
                if (e > 0f) {
                    deg = lerp(88f + t * 6f, lerp(-30f, 26f, t), e);
                }
                if (dir < 0f) deg = 180f - deg;

                float sx = dir * (0.022f + i * 0.005f);
                float sy = -0.712f - i * 0.009f;
                quill(tmp, sx, sy, deg, wid, wdt);
                cv.drawPath(tmp, fill);
            }
            // 翼根:一小块把羽根拢住
            tmp.reset();
            rr.set(dir * 0.006f - 0.054f, -0.766f, dir * 0.006f + 0.054f, -0.654f);
            tmp.addOval(rr, Path.Direction.CW);
            cv.drawPath(tmp, fill);
        }
    }

    private void drawLegs(Canvas cv, float phase, float stand, int col) {
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setStrokeJoin(Paint.Join.ROUND);
        line.setColor(col);

        final float hipX = 0.006f, hipY = -0.458f;

        for (int i = 0; i < 2; i++) {
            float ph = phase + (i == 0 ? 0f : (float) Math.PI);
            float c = ph / (2f * (float) Math.PI);
            c = c - (float) Math.floor(c);

            float fx, fy;
            if (c < 0.52f) {                     // 支撑:脚踩地,相对身体后移
                float k = c / 0.52f;
                fx = lerp(0.052f, -0.072f, k);
                fy = 0f;
            } else {                             // 摆动:抬腿前迈
                float k = (c - 0.52f) / 0.48f;
                fx = lerp(-0.072f, 0.052f, k);
                fy = -0.086f * (float) Math.sin(k * Math.PI);
            }
            // 站定:两腿踩实,一前一后
            float sx = i == 0 ? -0.056f : 0.046f;
            fx = lerp(fx, sx, stand);
            fy = lerp(fy, 0f, stand);

            float kx = (hipX + fx) * 0.5f + 0.026f;
            float ky = (hipY + fy) * 0.5f + 0.010f;

            line.setStrokeWidth(0.024f);
            limb.reset();
            limb.moveTo(hipX, hipY);
            limb.quadTo(kx, ky, fx, fy);
            cv.drawPath(limb, line);

            // 三趾
            line.setStrokeWidth(0.016f);
            cv.drawLine(fx, fy, fx + 0.046f, fy, line);
            cv.drawLine(fx, fy, fx - 0.040f, fy, line);
            cv.drawLine(fx, fy, fx - 0.012f, fy + 0.012f, line);
        }
    }

    /* ================= ④ 飘落的飞羽 ================= */

    private void drawFalling(Canvas cv, float cx, float cy, float unit,
                             float t, float fade) {
        if (t <= 0f || t >= 1f) return;
        fill.setColor(withAlpha(0xFFDCE8FF, 0xFF));
        for (int i = 0; i < FALLING; i++) {
            float ph = i * 0.83f;
            float born = (i / (float) FALLING) * 0.42f;
            float life = clamp((t - born) / 0.58f);
            if (life <= 0f || life >= 1f) continue;

            float a = (1f - life) * 0.80f * fade * clamp(t * 4f);
            if (a <= 0.01f) continue;

            float sx = cx + (float) Math.sin(ph * 3.7f) * unit * 0.44f;
            float sy = cy + unit * 0.06f;
            float x = sx - life * unit * 0.13f
                    + (float) Math.sin(life * 6.4f + ph) * unit * 0.075f;
            float y = sy + life * unit * 0.66f;
            float rot = ph * 62f + life * 240f;

            fill.setColor(withAlpha(0xFFDCE8FF, (int) (255 * a)));
            quill(tmp, x, y, rot, unit * 0.040f, unit * 0.016f);
            cv.drawPath(tmp, fill);
        }
    }

    /* ================= 通用:一根羽毛(柳叶形) ================= */

    private static void quill(Path out, float x0, float y0,
                              float deg, float len, float wid) {
        double a = Math.toRadians(deg);
        float dx = (float) Math.cos(a), dy = (float) Math.sin(a);
        float nx = -dy, ny = dx;
        float tx = x0 + dx * len, ty = y0 + dy * len;
        float mx = x0 + dx * len * 0.5f, my = y0 + dy * len * 0.5f;

        out.reset();
        out.moveTo(x0 + nx * wid * 0.5f, y0 + ny * wid * 0.5f);
        out.quadTo(mx + nx * wid * 0.46f, my + ny * wid * 0.46f, tx, ty);
        out.quadTo(mx - nx * wid * 0.34f, my - ny * wid * 0.34f,
                x0 - nx * wid * 0.5f, y0 - ny * wid * 0.5f);
        out.close();
    }

    /* ================= 环内朱雀标 ================= */

    /** 朱雀展翼标:上扬双翼 + 分叉长尾,做玻璃渐变填充 */
    private void buildWingMark() {
        mark.reset();
        // 左翼(上扬)
        mark.moveTo(-1.02f, -0.34f);
        mark.quadTo(-0.74f, -0.66f, -0.30f, -0.46f);
        mark.quadTo(-0.10f, -0.36f, -0.05f, -0.16f);
        // 右翼
        mark.quadTo(0.00f, -0.05f, 0.05f, -0.16f);
        mark.quadTo(0.10f, -0.36f, 0.30f, -0.46f);
        mark.quadTo(0.74f, -0.66f, 1.02f, -0.34f);
        // 右长尾(下垂后翘)
        mark.quadTo(0.70f, 0.06f, 0.42f, 0.40f);
        mark.quadTo(0.30f, 0.58f, 0.16f, 0.82f);
        mark.quadTo(0.10f, 0.56f, 0.00f, 0.42f);
        // 左长尾
        mark.quadTo(-0.10f, 0.56f, -0.16f, 0.82f);
        mark.quadTo(-0.30f, 0.58f, -0.42f, 0.40f);
        mark.quadTo(-0.70f, 0.06f, -1.02f, -0.34f);
        mark.close();
    }

    private void drawWingMark(Canvas cv, float cx, float cy, float s, float a) {
        float k = clamp(a);
        cv.save();
        cv.translate(cx, cy);
        cv.scale(s, s + (1f - k) * s * 0.14f);
        fill.setShader(new LinearGradient(-1f, -0.7f, 1f, 0.8f,
                withAlpha(0xFFEAF2FF, (int) (255 * k)),
                withAlpha(Ui.PRIMARY, (int) (255 * k)),
                withAlpha(Ui.PURPLE, (int) (235 * k)),
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        cv.drawPath(mark, fill);
        fill.setShader(null);
        cv.restore();
    }

    /* ================= 品牌文字 ================= */

    private void drawBrand(Canvas cv, float cx, float baseY, float unit, float a) {
        final String s = "飞鸟信";
        float size = unit * 0.178f;
        txt.setTextSize(size);

        float[] wd = new float[s.length()];
        float sum = 0;
        for (int i = 0; i < s.length(); i++) {
            wd[i] = txt.measureText(s.substring(i, i + 1));
            sum += wd[i];
        }

        float ease = OUT.getInterpolation(a);
        float gap = size * lerp(0.62f, 0.16f, ease);
        float fullW = sum + gap * (s.length() - 1);
        float x = cx - fullW * 0.5f;

        for (int i = 0; i < s.length(); i++) {
            float at = clamp((a - i * 0.13f) / 0.62f);
            if (at > 0.001f) {
                float e = OUT.getInterpolation(at);
                txt.setColor(withAlpha(Ui.TEXT, (int) (255 * e)));
                cv.drawText(s.substring(i, i + 1),
                        x + wd[i] * 0.5f,
                        baseY + (1f - e) * size * 0.34f, txt);
            }
            x += wd[i] + gap;
        }

        // 液态玻璃下划线
        float lw = fullW * 1.18f * ease;
        if (lw > 1f) {
            float ly = baseY + unit * 0.088f;
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeWidth(Math.max(1f, unit * 0.0035f));
            line.setShader(new LinearGradient(cx - lw * 0.5f, 0, cx + lw * 0.5f, 0,
                    new int[]{withAlpha(Ui.PRIMARY, 0), withAlpha(Ui.PRIMARY, (int) (190 * a)),
                            withAlpha(Ui.PURPLE, (int) (190 * a)), withAlpha(Ui.PURPLE, 0)},
                    new float[]{0f, 0.25f, 0.75f, 1f}, Shader.TileMode.CLAMP));
            cv.drawLine(cx - lw * 0.5f, ly, cx + lw * 0.5f, ly, line);
            line.setShader(null);

            line.setStrokeWidth(Math.max(1f, unit * 0.009f));
            line.setShader(new LinearGradient(cx - lw * 0.5f, 0, cx + lw * 0.5f, 0,
                    new int[]{0x00FFFFFF, withAlpha(0xFFFFFFFF, (int) (26 * a)), 0x00FFFFFF},
                    new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
            cv.drawLine(cx - lw * 0.5f, ly + unit * 0.006f,
                    cx + lw * 0.5f, ly + unit * 0.006f, line);
            line.setShader(null);
        }

        // 副标题
        float sub = seg(a, 0.55f, 1f);
        if (sub > 0.01f) {
            txt.setTextSize(unit * 0.042f);
            txt.setLetterSpacing(0.32f);
            txt.setColor(withAlpha(Ui.TEXT_DIM, (int) (215 * sub)));
            cv.drawText("VERMILION PHOENIX  ·  弹道调参引擎", cx, baseY + unit * 0.178f, txt);
            txt.setLetterSpacing(0f);
        }
    }

    /* ================= 小工具 ================= */

    private static float smooth(float t) {
        t = clamp(t);
        return t * t * (3f - 2f * t);
    }

    private static float seg(float p, float a, float b) {
        if (b <= a) return p >= b ? 1f : 0f;
        return clamp((p - a) / (b - a));
    }

    private static float clamp(float v) {
        return v < 0f ? 0f : (v > 1f ? 1f : v);
    }

    private static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    private static int withAlpha(int color, int a) {
        if (a < 0) a = 0;
        if (a > 255) a = 255;
        return (color & 0x00FFFFFF) | (a << 24);
    }

    @SuppressWarnings("unused")
    private static int mix(int c1, int c2, float t) {
        t = clamp(t);
        int a1 = (c1 >>> 24), r1 = (c1 >> 16) & 0xFF, g1 = (c1 >> 8) & 0xFF, b1 = c1 & 0xFF;
        int a2 = (c2 >>> 24), r2 = (c2 >> 16) & 0xFF, g2 = (c2 >> 8) & 0xFF, b2 = c2 & 0xFF;
        return ((int) (a1 + (a2 - a1) * t) << 24)
                | ((int) (r1 + (r2 - r1) * t) << 16)
                | ((int) (g1 + (g2 - g1) * t) << 8)
                | (int) (b1 + (b2 - b1) * t);
    }
}

package com.feiniao.tuner.util;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

/** 存储访问框架(SAF)工具:目录选取、读写、真实路径换算 */
public final class Saf {

    private Saf() {}

    /** 把 tree uri 换成可直接给 root 用的文件系统路径;失败返回 null */
    public static String treeToPath(Uri treeUri) {
        try {
            String docId = DocumentsContract.getTreeDocumentId(treeUri);
            if (docId == null) return null;
            String id = docId;
            int colon = id.indexOf(':');
            if (colon < 0) return null;
            String vol = id.substring(0, colon);
            String rel = id.substring(colon + 1);
            if (vol.equalsIgnoreCase("primary")) {
                String p = "/storage/emulated/0";
                return rel.isEmpty() ? p : p + "/" + rel;
            }
            if (vol.equalsIgnoreCase("raw")) {
                return rel.startsWith("/") ? rel : "/" + rel;
            }
            String p = "/storage/" + vol;
            return rel.isEmpty() ? p : p + "/" + rel;
        } catch (Throwable t) {
            return null;
        }
    }

    /** 目录下的文件名列表 */
    public static List<String> listChildren(Context c, Uri treeUri) {
        List<String> out = new ArrayList<>();
        Cursor cur = null;
        try {
            Uri dir = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri,
                    DocumentsContract.getTreeDocumentId(treeUri));
            cur = c.getContentResolver().query(dir,
                    new String[]{DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                            DocumentsContract.Document.COLUMN_MIME_TYPE}, null, null, null);
            if (cur != null) {
                while (cur.moveToNext()) out.add(cur.getString(0));
            }
        } catch (Throwable ignored) {
        } finally {
            if (cur != null) try { cur.close(); } catch (Throwable ignored) {}
        }
        return out;
    }

    /** 写入(同名文件先删),返回是否成功 */
    public static boolean writeIntoTree(Context c, Uri treeUri, String name, String content) {
        try {
            Uri dir = DocumentsContract.buildDocumentUriUsingTree(treeUri,
                    DocumentsContract.getTreeDocumentId(treeUri));

            // 已存在同名 → 找到并直接覆盖
            Uri existing = find(c, treeUri, name);
            if (existing != null) {
                OutputStream os = c.getContentResolver().openOutputStream(existing, "wt");
                if (os == null) return false;
                byte[] b = content.getBytes("UTF-8");
                os.write(b);
                os.flush();
                os.close();
                return true;
            }

            Uri created = DocumentsContract.createDocument(c.getContentResolver(), dir,
                    "application/octet-stream", name);
            if (created == null) return false;
            OutputStream os = c.getContentResolver().openOutputStream(created, "wt");
            if (os == null) return false;
            os.write(content.getBytes("UTF-8"));
            os.flush();
            os.close();
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    public static Uri find(Context c, Uri treeUri, String name) {
        Cursor cur = null;
        try {
            Uri dir = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri,
                    DocumentsContract.getTreeDocumentId(treeUri));
            cur = c.getContentResolver().query(dir,
                    new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                            DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null);
            if (cur != null) {
                while (cur.moveToNext()) {
                    if (name.equals(cur.getString(1))) {
                        return DocumentsContract.buildDocumentUriUsingTree(treeUri, cur.getString(0));
                    }
                }
            }
        } catch (Throwable ignored) {
        } finally {
            if (cur != null) try { cur.close(); } catch (Throwable ignored) {}
        }
        return null;
    }

    public static String readText(Context c, Uri fileUri, int limit) throws Exception {
        InputStream in = c.getContentResolver().openInputStream(fileUri);
        if (in == null) throw new IllegalStateException("无法打开该文件");
        try {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] b = new byte[8192];
            int n, total = 0;
            while ((n = in.read(b)) > 0) {
                bo.write(b, 0, n);
                total += n;
                if (total > limit) break;
            }
            return bo.toString("UTF-8").replace("\uFEFF", "");
        } finally {
            try { in.close(); } catch (Throwable ignored) {}
        }
    }

    public static String displayName(Context c, Uri uri) {
        Cursor cur = null;
        try {
            cur = c.getContentResolver().query(uri, null, null, null, null);
            if (cur != null && cur.moveToFirst()) {
                int i = cur.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
                if (i >= 0) return cur.getString(i);
            }
        } catch (Throwable ignored) {
        } finally {
            if (cur != null) try { cur.close(); } catch (Throwable ignored) {}
        }
        return String.valueOf(uri.getLastPathSegment());
    }
}

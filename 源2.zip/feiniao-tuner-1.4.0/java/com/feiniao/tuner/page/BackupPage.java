package com.feiniao.tuner.page;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.feiniao.tuner.Prefs;
import com.feiniao.tuner.Ui;
import com.feiniao.tuner.model.ParamSet;
import com.feiniao.tuner.model.ParamStore;
import com.feiniao.tuner.root.ParamReplacer;
import com.feiniao.tuner.root.Shell;

import java.util.ArrayList;
import java.util.List;

/** 备份参数:读取路径 → 复制到 飞鸟信参数 文件夹 */
public class BackupPage extends Page {

    private static final int REQ_SRC = 2401;
    private static final int REQ_TREE = 2402;

    private ParamSet ps;
    private EditText fSrc, fDst, fName;
    private TextView srcInfo, logBox;
    private LinearLayout listBox;

    @Override
    public String title() {
        return "参数备份";
    }

    @Override
    public View build(Context c, final Host host) {
        this.ctx = c;
        this.host = host;
        ps = ParamStore.loadCurrent(c);

        LinearLayout page = Ui.page(c);
        ScrollView sc = Ui.scroll(c);
        sc.addView(page);

        Ui.stack(page, Ui.body(c,
                "给参数上保险。填好要备份的路径,一键把文件整个复制到「飞鸟信参数」文件夹里存着,"
                        + "手滑改坏了随时能恢复回去。"));

        /* ---------- 备份设置 ---------- */
        LinearLayout card = Ui.card(c);
        card.addView(Ui.h2(c, "备份设置"));
        card.addView(Ui.gap(c, 10));

        fSrc = Ui.input(c, "要备份的文件或目录路径");
        fSrc.setText(Prefs.getStr("bk_src", ""));
        card.addView(fSrc);
        card.addView(Ui.gap(c, 8));
        srcInfo = Ui.dim(c, "");
        card.addView(srcInfo);
        card.addView(Ui.gap(c, 10));

        LinearLayout sb = Ui.row(c);
        TextView pickFile = Ui.button(c, "选择文件", 2);
        TextView pickDir = Ui.button(c, "选择目录", 2);
        TextView check = Ui.button(c, "检测路径", 1);
        addW(sb, pickFile, 1f, 8);
        addW(sb, pickDir, 1f, 8);
        addW(sb, check, 1f, 0);
        card.addView(sb);

        pickFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                host.pickDocument(REQ_SRC, "*/*", "选择参数文件", BackupPage.this);
            }
        });
        pickDir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                host.pickTree(REQ_TREE, "选择参数目录", BackupPage.this);
            }
        });
        check.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { checkSrc(); }
        });

        card.addView(Ui.gap(c, 14));
        fDst = Ui.input(c, "/sdcard/飞鸟信参数");
        fDst.setText(Prefs.getStr("bk_dst", "/sdcard/飞鸟信参数"));
        card.addView(Ui.field(c, "备份到文件夹", fDst));
        card.addView(Ui.gap(c, 10));
        fName = Ui.input(c, "留空 = 用原文件名");
        fName.setText(Prefs.getStr("bk_name", ""));
        card.addView(Ui.field(c, "备份文件名", fName));
        card.addView(Ui.gap(c, 12));

        TextView doBackup = Ui.button(c, "开始备份", 0);
        card.addView(doBackup);
        doBackup.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { doBackup(); }
        });

        Ui.stack(page, card);

        /* ---------- 本地方案也存一份 ---------- */
        LinearLayout local = Ui.card(c);
        local.addView(Ui.h2(c, "顺带存一份本地方案"));
        local.addView(Ui.gap(c, 6));
        local.addView(Ui.dim(c, "把当前工作方案以 json 形式写进备份文件夹,换手机也能带过去。"));
        local.addView(Ui.gap(c, 10));
        TextView saveLocal = Ui.button(c, "导出当前方案到备份文件夹", 1);
        local.addView(saveLocal);
        saveLocal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { exportLocal(); }
        });
        Ui.stack(page, local);

        /* ---------- 已备份列表 ---------- */
        LinearLayout list = Ui.card(c);
        list.addView(Ui.h2(c, "备份文件夹内容"));
        list.addView(Ui.gap(c, 8));
        listBox = Ui.col(c);
        list.addView(listBox);
        list.addView(Ui.gap(c, 10));
        TextView refresh = Ui.button(c, "刷新列表", 1);
        list.addView(refresh);
        refresh.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { refreshList(); }
        });
        Ui.stack(page, list);

        /* ---------- 日志 ---------- */
        LinearLayout lg = Ui.card(c);
        lg.addView(Ui.h2(c, "执行日志"));
        lg.addView(Ui.gap(c, 8));
        logBox = Ui.dim(c, "等待操作。");
        logBox.setTextIsSelectable(true);
        lg.addView(logBox);
        Ui.stack(page, lg);

        root = sc;
        checkSrc();
        refreshList();
        return root;
    }

    @Override
    public void onShow() {
        if (root == null) return;
        ps = ParamStore.loadCurrent(ctx);
    }

    /* ---------------- 路径检测 ---------------- */

    private void checkSrc() {
        final String src = fSrc.getText().toString().trim();
        if (src.isEmpty()) {
            if (srcInfo != null) srcInfo.setText("还没填要备份的路径。");
            return;
        }
        Prefs.setStr("bk_src", src);
        if (srcInfo != null) srcInfo.setText("检测中…");
        new Thread(new Runnable() {
            @Override
            public void run() {
                final String out = Shell.su("[ -e " + Shell.q(src) + " ] && ls -ld "
                        + Shell.q(src) + " || echo __MISS__").all();
                final boolean miss = out.contains("__MISS__");
                if (srcInfo != null) {
                    srcInfo.post(new Runnable() {
                        @Override
                        public void run() {
                            if (srcInfo != null) {
                                srcInfo.setText(miss
                                        ? "路径不存在或 root 未授权:" + src
                                        : out.trim());
                                srcInfo.setTextColor(miss ? Ui.RED : Ui.TEXT_SUB);
                            }
                        }
                    });
                }
            }
        }).start();
    }

    /* ---------------- 备份 ---------------- */

    private void doBackup() {
        final String src = fSrc.getText().toString().trim();
        final String dst = fDst.getText().toString().trim();
        final String name = fName.getText().toString().trim();
        if (src.isEmpty()) { toast("先填要备份的路径"); return; }
        if (dst.isEmpty()) { toast("先填备份文件夹"); return; }
        Prefs.setStr("bk_src", src);
        Prefs.setStr("bk_dst", dst);
        Prefs.setStr("bk_name", name);
        setLog("正在备份…");

        new Thread(new Runnable() {
            @Override
            public void run() {
                StringBuilder sb = new StringBuilder();
                sb.append("源:").append(src).append("\n");
                sb.append("目标文件夹:").append(dst).append("\n");

                String realSrc = src;
                if (!name.isEmpty()) {
                    // 指定了备份名 → 先复制成临时名再改名
                    String tmp = new java.io.File(src).getParent() + "/" + name;
                    Shell.Result c = Shell.su("cp -rf " + Shell.q(src) + " " + Shell.q(tmp)
                            + " && echo __OK__");
                    if (c.all().contains("__OK__")) realSrc = tmp;
                }

                ParamReplacer.Out o = ParamReplacer.backupTo(realSrc, dst);
                sb.append("结果:").append(o.msg).append("\n");
                if (o.detail != null && !o.detail.isEmpty()) sb.append(o.detail).append("\n");
                setLog(sb.toString());
                toast(o.ok ? "备份完成" : "备份失败");
                refreshList();
            }
        }).start();
    }

    private void exportLocal() {
        final String dst = fDst.getText().toString().trim();
        if (dst.isEmpty()) { toast("先填备份文件夹"); return; }
        final String json = ParamStore.toJsonText(ParamStore.loadCurrent(ctx));
        final String fname = "方案_" + ps.name.replaceAll("[\\\\/:*?\"<>|]", "_") + ".json";
        setLog("正在导出本地方案…");
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    java.io.File staged = new java.io.File(ctx.getCacheDir(), fname);
                    ParamStore.writeText(staged, json);
                    ParamReplacer.Out o = ParamReplacer.backupTo(staged.getAbsolutePath(), dst);
                    setLog("导出:" + fname + "\n结果:" + o.msg
                            + (o.detail.isEmpty() ? "" : "\n" + o.detail));
                    toast(o.ok ? "已导出" : "导出失败");
                    refreshList();
                } catch (Throwable t) {
                    setLog("导出失败:" + t.getMessage());
                }
            }
        }).start();
    }

    /* ---------------- 列表 ---------------- */

    private void refreshList() {
        final String dst = fDst == null ? "/sdcard/飞鸟信参数"
                : fDst.getText().toString().trim();
        if (listBox == null) return;
        new Thread(new Runnable() {
            @Override
            public void run() {
                final String out = Shell.su("ls -1 " + Shell.q(dst) + " 2>/dev/null || echo __EMPTY__").all();
                final List<String> items = new ArrayList<>();
                for (String line : out.split("\n")) {
                    String s = line.trim();
                    if (s.isEmpty() || s.startsWith("__")) continue;
                    if (s.startsWith("ls:")) continue;
                    items.add(s);
                }
                if (listBox == null) return;
                listBox.post(new Runnable() {
                    @Override
                    public void run() {
                        if (listBox == null) return;
                        listBox.removeAllViews();
                        if (items.isEmpty()) {
                            listBox.addView(Ui.dim(ctx, "备份文件夹现在是空的:"
                                    + dst + "\n(路径不存在或 root 未授权也会显示为空)"));
                            return;
                        }
                        for (final String it : items) {
                            LinearLayout row = Ui.row(ctx);
                            TextView nm = Ui.text(ctx, it, 13f, Ui.TEXT, false);
                            nm.setLayoutParams(new LinearLayout.LayoutParams(0,
                                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                            TextView restore = Ui.button(ctx, "恢复", 1);
                            row.addView(nm);
                            row.addView(restore);
                            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.WRAP_CONTENT);
                            lp.bottomMargin = Ui.dp(ctx, 8);
                            row.setLayoutParams(lp);
                            restore.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) { restore(dst, it); }
                            });
                            listBox.addView(row);
                        }
                    }
                });
            }
        }).start();
    }

    private void restore(final String dst, final String name) {
        final String src = fSrc.getText().toString().trim();
        if (src.isEmpty()) {
            toast("先把要恢复到的路径填上(就是备份时那个源路径)");
            return;
        }
        setLog("正在恢复 " + name + " → " + src);
        new Thread(new Runnable() {
            @Override
            public void run() {
                String from = dst + "/" + name;
                Shell.Result r = Shell.su("cp -f " + Shell.q(from) + " " + Shell.q(src)
                        + " && chmod 666 " + Shell.q(src) + " && echo __OK__ "
                        + "&& ls -l " + Shell.q(src));
                String all = r.all();
                setLog("恢复:" + (all.contains("__OK__") ? "成功" : "失败") + "\n"
                        + all.replace("__OK__", "").trim());
                toast(all.contains("__OK__") ? "已恢复" : "恢复失败");
            }
        }).start();
    }

    /* ---------------- 结果 ---------------- */

    @Override
    public void onResult(int req, int result, Intent data) {
        if (result != android.app.Activity.RESULT_OK || data == null || data.getData() == null) return;
        String path = com.feiniao.tuner.util.Saf.treeToPath(data.getData());
        if (path == null) {
            toast("这个位置换算不出真实路径,手动填一下吧");
            return;
        }
        if (req == REQ_SRC) {
            fSrc.setText(path);
            Prefs.setStr("bk_src", path);
            checkSrc();
        } else if (req == REQ_TREE) {
            fSrc.setText(path);
            Prefs.setStr("bk_src", path);
            checkSrc();
        }
    }

    private void setLog(final String s) {
        if (logBox == null) return;
        logBox.post(new Runnable() {
            @Override
            public void run() {
                if (logBox != null) logBox.setText(s.trim());
            }
        });
    }

    private void addW(LinearLayout parent, View v, float weight, int rightMarginDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, weight);
        lp.rightMargin = Ui.dp(ctx, rightMarginDp);
        parent.addView(v, lp);
    }
}

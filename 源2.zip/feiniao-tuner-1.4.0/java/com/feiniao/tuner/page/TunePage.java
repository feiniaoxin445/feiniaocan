package com.feiniao.tuner.page;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.feiniao.tuner.DistanceBar;
import com.feiniao.tuner.Prefs;
import com.feiniao.tuner.Ui;
import com.feiniao.tuner.core.Analysis;
import com.feiniao.tuner.core.AutoTune;
import com.feiniao.tuner.core.IniBuilder;
import com.feiniao.tuner.core.Physics;
import com.feiniao.tuner.core.Reports;
import com.feiniao.tuner.core.WeaponPreset;
import com.feiniao.tuner.model.ParamSet;
import com.feiniao.tuner.model.ParamStore;
import com.feiniao.tuner.model.Segment;
import com.feiniao.tuner.util.Saf;
import com.feiniao.tuner.vision.ScreenEngine;
import com.feiniao.tuner.vision.VideoAnalyzer;

import java.util.List;

/** 调参:视频逐帧分析 + 实时屏幕识别 */
public class TunePage extends Page {

    private static final int REQ_VIDEO = 2201;
    private static final int REQ_EXPORT = 2202;

    private ParamSet ps;
    private TextView statusLine;
    private TextView resultBox;
    private LinearLayout reportBox;
    private TextView engineBtn;
    private EditText fFps, fStep, fPpm, fBullet, fBody, fScale, fLeadIn, fLock;
    private EditText fRedHue, fPurpleLo, fPurpleHi, fSat, fVal, fWork;

    private Analysis.Report last;
    private android.net.Uri lastVideo;

    /* 总距离 / 命中统计 视图 */
    private TextView totalBig, distInfo, distSummary;
    private LinearLayout distBox, hitBox;
    private DistanceBar distBar;

    /* 视频调参:视频信息 / 参数体积 / 横向衰减 / 预判命中表 */
    private TextView videoInfo, sizeLine, decayLine, weaponTip;
    private LinearLayout predictHitBox;
    private String weaponId;
    private boolean useSlotGap;

    @Override
    public String title() {
        return "AI 调参";
    }

    @Override
    public View build(Context c, Host host) {
        this.ctx = c;
        this.host = host;
        ps = ParamStore.loadCurrent(c);
        weaponId = Prefs.getStr("weapon_id",
                ps.weapon != null ? ps.weapon : WeaponPreset.ID_REVOLVER);
        useSlotGap = Prefs.getB("use_slot_gap", true);

        LinearLayout page = Ui.page(c);
        ScrollView sc = Ui.scroll(c);
        sc.addView(page);

        Ui.stack(page, Ui.body(c,
                "两种调参方式:一是导入一段对枪视频,逐帧识别红/紫子弹标记,反推距离、人物速度、所需预判,"
                        + "再和参数表逐段对比告诉你偏大还是偏小;二是直接开屏幕识别,实时把预判偏差顶在屏幕上。"
                        + "视频调参下面会实时显示当前这份参数的内存大小和横向衰减值。"));

        /* ---------- 当前参数 · 总距离 ---------- */
        LinearLayout dcard = Ui.card(c);
        dcard.addView(Ui.h2(c, "当前参数 · 总距离"));
        dcard.addView(Ui.gap(c, 10));

        totalBig = Ui.text(c, "— m", 30, Ui.PRIMARY, true);
        dcard.addView(totalBig);
        dcard.addView(Ui.gap(c, 7));
        distInfo = Ui.dim(c, "");
        dcard.addView(distInfo);
        dcard.addView(Ui.gap(c, 12));

        distBar = new DistanceBar(c);
        dcard.addView(distBar);
        dcard.addView(Ui.gap(c, 9));

        LinearLayout legend = Ui.row(c);
        legend.addView(legendDot(c, Ui.GREEN, "打中"));
        legend.addView(legendDot(c, Ui.RED, "没打中"));
        legend.addView(legendDot(c, Ui.SURFACE_2, "未覆盖"));
        dcard.addView(legend);

        dcard.addView(Ui.gap(c, 12));
        distSummary = Ui.body(c, "");
        dcard.addView(distSummary);
        dcard.addView(Ui.gap(c, 10));
        distBox = Ui.col(c);
        dcard.addView(distBox);
        Ui.stack(page, dcard);

        /* ---------- 视频分析 ---------- */
        LinearLayout card = Ui.card(c);
        card.addView(Ui.h2(c, "视频调参 · 导入视频"));
        card.addView(Ui.gap(c, 6));
        card.addView(Ui.dim(c, "从相册 / 文件里挑一段对枪录像导进来,引擎逐帧过一遍,"
                + "把这段距离该给多少预判算出来,直接对着你的参数表调。"));
        card.addView(Ui.gap(c, 8));

        fFps = num(); fStep = num(); fPpm = num(); fBullet = num();
        fBody = num(); fScale = num(); fLeadIn = num();

        fFps.setText(Segment.trim(Prefs.getF("an_fps", 0f)));
        fStep.setText(String.valueOf(Prefs.getI("an_step", 1)));
        fPpm.setText(Segment.trim(Prefs.getF("an_ppm", 0f)));
        fBullet.setText(Segment.trim(Prefs.getF("an_bullet", ps.bulletRef)));
        fBody.setText(Segment.trim(Prefs.getF("an_body", ps.bodyWidth)));
        fScale.setText(Segment.trim(Prefs.getF("an_scale", ps.speedScale)));
        fLeadIn.setText(String.valueOf(Prefs.getI("an_leadin", 0)));

        card.addView(Ui.field(c, "采样帧率 fps", fFps));
        card.addView(Ui.gap(c, 8));
        card.addView(Ui.field(c, "每隔 N 帧取一帧", fStep));
        card.addView(Ui.gap(c, 8));
        card.addView(Ui.field(c, "像素当量 px/m", fPpm));
        card.addView(Ui.gap(c, 8));
        card.addView(Ui.field(c, "参考子弹速度", fBullet));
        card.addView(Ui.gap(c, 8));
        card.addView(Ui.field(c, "身位当量 (米)", fBody));
        card.addView(Ui.gap(c, 8));
        card.addView(Ui.field(c, "速度换算 (米/秒)", fScale));
        card.addView(Ui.gap(c, 8));
        card.addView(Ui.field(c, "出膛补偿 (帧)", fLeadIn));
        card.addView(Ui.gap(c, 4));
        card.addView(Ui.dim(c, "fps 填 0 = 自动探测;像素当量填 0 = 用弹道飞行时间反推距离。"));
        card.addView(Ui.gap(c, 12));

        TextView pick = Ui.button(c, "导入视频并开始调参", 0);
        card.addView(pick);
        pick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                host.pickDocument(REQ_VIDEO, "video/*", "导入对枪视频", TunePage.this);
            }
        });
        card.addView(Ui.gap(c, 10));
        statusLine = Ui.dim(c, "等待导入视频。");
        card.addView(statusLine);

        /* ---- 调参下面的实时面板:参数内存大小 + 横向衰减 ---- */
        card.addView(Ui.gap(c, 12));
        card.addView(Ui.divider(c));

        sizeLine = Ui.text(c, "参数内存大小 —", 13.5f, Ui.PRIMARY, true);
        card.addView(sizeLine);
        card.addView(Ui.gap(c, 7));
        decayLine = Ui.text(c, "横向衰减 —", 13f, Ui.TEXT_SUB, false);
        card.addView(decayLine);
        card.addView(Ui.gap(c, 7));
        videoInfo = Ui.dim(c, "还没导入视频。导入之后这里会显示视频时长、采样帧率,"
                + "以及本次分析实际用的参考弹速、身位当量这些参数。");
        card.addView(videoInfo);
        Ui.stack(page, card);

        /* ---------- 分析结果 ---------- */
        LinearLayout rep = Ui.card(c);
        rep.addView(Ui.h2(c, "分析结果 · 逐段对比"));
        rep.addView(Ui.gap(c, 8));
        resultBox = Ui.dim(c, "还没有分析数据。");
        rep.addView(resultBox);
        rep.addView(Ui.gap(c, 10));
        reportBox = Ui.col(c);
        rep.addView(reportBox);
        rep.addView(Ui.gap(c, 10));

        LinearLayout rbtns = Ui.row(c);
        TextView apply = Ui.button(c, "一键套用建议值", 0);
        TextView dump = Ui.button(c, "导出报告", 2);
        addWeight(rbtns, apply, 1.3f, 8);
        addWeight(rbtns, dump, 1f, 0);
        rep.addView(rbtns);

        apply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (last == null || last.rows.isEmpty()) { toast("先跑一次视频分析"); return; }
                int n = 0;
                for (Analysis.SegRow row : last.rows) {
                    Segment s = ps.nearest(row.distance);
                    if (s != null && Math.abs(s.distance - row.distance) < 0.5f
                            && Math.abs(row.suggest - s.predict) > 0.001f) {
                        s.predict = row.suggest;
                        n++;
                    }
                }
                ParamStore.saveCurrent(ctx, ps);
                toast(n > 0 ? ("已套用 " + n + " 段建议值") : "各段已经吻合,不需要动");
            }
        });
        dump.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (last == null) { toast("先跑一次视频分析"); return; }
                host.pickCreate(REQ_EXPORT, "text/plain", "飞鸟调参报告.txt", TunePage.this);
            }
        });

        Ui.stack(page, rep);

        /* ---------- 预判命中表 ---------- */
        LinearLayout ph = Ui.card(c);
        ph.addView(Ui.h2(c, "预判命中表"));
        ph.addView(Ui.gap(c, 6));
        ph.addView(Ui.dim(c, "按参数表每一档距离列出:这档该给多少预判、这段距离实测打中还是没打中、"
                + "命中率多少,以及这一档要不要动横向衰减 —— 只有 19 / 20(打顶飞)档才动。"));
        ph.addView(Ui.gap(c, 12));
        predictHitBox = Ui.col(c);
        ph.addView(predictHitBox);
        Ui.stack(page, ph);

        /* ---------- 一键调节 ---------- */
        LinearLayout one = Ui.card(c);
        one.addView(Ui.h2(c, "一键调节"));
        one.addView(Ui.gap(c, 6));
        one.addView(Ui.dim(c, "按当前武器思路把整张表重算一遍:有实测样本的段用实测建议值,"
                + "没样本的段按理论值加下坠补偿补齐,横向衰减只给 19 / 20 打顶飞档。"));
        one.addView(Ui.gap(c, 12));

        final WeaponPreset[] weapons = WeaponPreset.all();
        final TextView[] wchips = new TextView[weapons.length];
        LinearLayout wrow = Ui.row(c);
        for (int i = 0; i < weapons.length; i++) {
            final WeaponPreset wp = weapons[i];
            TextView chip = Ui.chip(c, wp.name, wp.id.equals(weaponId));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.rightMargin = Ui.dp(c, 8);
            chip.setLayoutParams(lp);
            chip.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    weaponId = wp.id;
                    Prefs.setStr("weapon_id", weaponId);
                    for (int k = 0; k < wchips.length; k++) {
                        boolean on = weapons[k].id.equals(weaponId);
                        wchips[k].setBackground(on ? Ui.pressable(Ui.PRIMARY, Ui.R_PILL, ctx)
                                : Ui.pressable(Ui.SURFACE_2, Ui.R_PILL, ctx));
                        wchips[k].setTextColor(on ? Ui.ON_PRIMARY : Ui.TEXT_SUB);
                    }
                    refreshWeaponTip();
                }
            });
            wchips[i] = chip;
            wrow.addView(chip);
        }
        one.addView(wrow);
        one.addView(Ui.gap(c, 10));

        weaponTip = Ui.dim(c, "");
        one.addView(weaponTip);
        one.addView(Ui.gap(c, 12));

        LinearLayout ob = Ui.row(c);
        TextView doAll = Ui.button(c, "一键调节整表", 0);
        TextView doDecay = Ui.button(c, "只重算横向衰减", 1);
        addWeight(ob, doAll, 1.25f, 8);
        addWeight(ob, doDecay, 1f, 0);
        one.addView(ob);
        one.addView(Ui.gap(c, 9));

        /* ---- 想去思路页接着调 ---- */
        TextView toStrategy = Ui.button(c, "去「思路」页:导入打法思路 + 智能推演", 1);
        one.addView(toStrategy);
        one.addView(Ui.gap(c, 9));
        one.addView(Ui.dim(c, "想写得比「一键调节」更细的时候走这条路:把打法写成一段人话丢进去,"
                + "引擎解析成口径铺整张表,再结合上面这份实测数据逐段推演该改哪几处、为什么改。"));
        toStrategy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (host != null) host.switchTo(2);
            }
        });

        final TextView swMeasure = Ui.chip(c,
                useSlotGap ? "武器提前量差:开" : "武器提前量差:关", useSlotGap);
        one.addView(swMeasure);
        swMeasure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                useSlotGap = !useSlotGap;
                Prefs.setB("use_slot_gap", useSlotGap);
                swMeasure.setText(useSlotGap ? "武器提前量差:开" : "武器提前量差:关");
                swMeasure.setBackground(useSlotGap ? Ui.pressable(Ui.PRIMARY, Ui.R_PILL, ctx)
                        : Ui.pressable(Ui.SURFACE_2, Ui.R_PILL, ctx));
                swMeasure.setTextColor(useSlotGap ? Ui.ON_PRIMARY : Ui.TEXT_SUB);
            }
        });

        doAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ps = ParamStore.loadCurrent(ctx);
                WeaponPreset w = WeaponPreset.byId(weaponId);
                int n = AutoTune.oneKey(ps, w, useSlotGap, last, true);
                ps.weapon = weaponId;
                ParamStore.saveCurrent(ctx, ps);
                refreshDist();
                toast(n > 0 ? ("整表已重算,动了 " + n + " 处") : "整表已经对齐,不用动");
            }
        });
        doDecay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ps = ParamStore.loadCurrent(ctx);
                int n = AutoTune.recalcDecay(ps);
                ParamStore.saveCurrent(ctx, ps);
                refreshDist();
                toast(n > 0 ? ("横向衰减重算完,动了 " + n + " 段") : "横向衰减本来就是对的");
            }
        });

        one.addView(Ui.gap(c, 10));
        one.addView(Ui.dim(c, "口径版本 · " + WeaponPreset.VERSION + ":" + WeaponPreset.VERSION_NOTE));

        Ui.stack(page, one);

        /* ---------- 命中统计 · 打中 / 没打中 ---------- */
        LinearLayout hcard = Ui.card(c);
        hcard.addView(Ui.h2(c, "命中统计 · 打中与没打中"));
        hcard.addView(Ui.gap(c, 6));
        hcard.addView(Ui.dim(c, "按「人物速度 + 子弹速度」分档,统计每档打中了哪些距离、哪些距离没打中。"
                + "判定口径:一次交火里检测到紫色预判点即记为打中,只有红外弹轨迹的记为没打中。"));
        hcard.addView(Ui.gap(c, 12));
        hitBox = Ui.col(c);
        hcard.addView(hitBox);
        Ui.stack(page, hcard);

        /* ---------- 实时屏幕识别 ---------- */
        LinearLayout live = Ui.card(c);
        live.addView(Ui.h2(c, "实时屏幕识别"));
        live.addView(Ui.gap(c, 6));
        live.addView(Ui.dim(c, "开着识别进游戏,悬浮 HUD 会实时标出识别到的子弹与预判点,"
                + "并把当前锁定分段的参数预判、理论预判、偏差顶在屏幕上。控制球拖动可移位,点一下收起/展开面板。"));
        live.addView(Ui.gap(c, 12));

        engineBtn = Ui.button(c, ScreenEngine.RUNNING ? "停止识别" : "开始识别", 0);
        live.addView(engineBtn);
        engineBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ScreenEngine.RUNNING) {
                    ScreenEngine.stop(ctx);
                    refreshEngineBtn();
                    toast("识别已停止");
                } else {
                    host.ensureOverlay(new Runnable() {
                        @Override
                        public void run() {
                            host.startProjection();
                        }
                    });
                }
            }
        });

        live.addView(Ui.gap(c, 10));
        TextView lockTip = Ui.dim(c, "锁定分段:识别 HUD 会按下面锁定的距离来显示对比。");
        live.addView(lockTip);
        live.addView(Ui.gap(c, 6));
        fLock = num();
        fLock.setText(Segment.trim(Prefs.getF("lock_distance", ps.totalDistance * 0.5f)));
        live.addView(Ui.field(c, "锁定距离 (米)", fLock));
        live.addView(Ui.gap(c, 8));
        LinearLayout lockRow = Ui.row(c);
        TextView saveLock = Ui.button(c, "保存锁定", 1);
        TextView autoLock = Ui.button(c, "自动取中段", 2);
        addWeight(lockRow, saveLock, 1f, 8);
        addWeight(lockRow, autoLock, 1f, 0);
        live.addView(lockRow);
        saveLock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Prefs.setF("lock_distance", numOf(fLock, ps.totalDistance * 0.5f));
                toast("锁定已更新");
            }
        });
        autoLock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Prefs.setF("lock_distance", ps.totalDistance * 0.5f);
                fLock.setText(Segment.trim(ps.totalDistance * 0.5f));
                toast("已取中段");
            }
        });

        Ui.stack(page, live);

        /* ---------- 识别微调 ---------- */
        LinearLayout tune = Ui.card(c);
        tune.addView(Ui.h2(c, "识别引擎微调"));
        tune.addView(Ui.gap(c, 6));
        tune.addView(Ui.dim(c, "颜色抓不准的时候来这里调阈值。红色容差调大能把偏橙的红也吃进来;"
                + "紫色区间控制紫/品红的判定范围;最低饱和度调低可以抓暗光下的标记。"));
        tune.addView(Ui.gap(c, 10));

        fRedHue = num(); fPurpleLo = num(); fPurpleHi = num();
        fSat = num(); fVal = num(); fWork = num();
        fRedHue.setText(Segment.trim(Prefs.getF("cfg_redhue", 15f)));
        fPurpleLo.setText(Segment.trim(Prefs.getF("cfg_plo", 256f)));
        fPurpleHi.setText(Segment.trim(Prefs.getF("cfg_phi", 326f)));
        fSat.setText(Segment.trim(Prefs.getF("cfg_sat", 0.40f)));
        fVal.setText(Segment.trim(Prefs.getF("cfg_val", 0.38f)));
        fWork.setText(String.valueOf(Prefs.getI("cfg_work", 480)));

        tune.addView(Ui.field(c, "红色容差 (度)", fRedHue));
        tune.addView(Ui.gap(c, 8));
        tune.addView(Ui.field(c, "紫色下限 (度)", fPurpleLo));
        tune.addView(Ui.gap(c, 8));
        tune.addView(Ui.field(c, "紫色上限 (度)", fPurpleHi));
        tune.addView(Ui.gap(c, 8));
        tune.addView(Ui.field(c, "最低饱和度", fSat));
        tune.addView(Ui.gap(c, 8));
        tune.addView(Ui.field(c, "最低亮度", fVal));
        tune.addView(Ui.gap(c, 8));
        tune.addView(Ui.field(c, "识别分辨率宽", fWork));
        tune.addView(Ui.gap(c, 12));

        LinearLayout tuneBtns = Ui.row(c);
        TextView save2 = Ui.button(c, "保存阈值", 1);
        TextView def = Ui.button(c, "恢复默认", 2);
        addWeight(tuneBtns, save2, 1f, 8);
        addWeight(tuneBtns, def, 1f, 0);
        tune.addView(tuneBtns);
        save2.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { saveTune(); }
        });
        def.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Prefs.setF("cfg_redhue", 15f);
                Prefs.setF("cfg_plo", 256f);
                Prefs.setF("cfg_phi", 326f);
                Prefs.setF("cfg_sat", 0.40f);
                Prefs.setF("cfg_val", 0.38f);
                Prefs.setI("cfg_work", 480);
                fRedHue.setText("15");
                fPurpleLo.setText("256");
                fPurpleHi.setText("326");
                fSat.setText("0.4");
                fVal.setText("0.38");
                fWork.setText("480");
                toast("阈值已恢复默认");
            }
        });

        LinearLayout sw = Ui.row(c);
        sw.setPadding(0, Ui.dp(c, 10), 0, 0);
        final TextView sw1 = Ui.chip(c, "显示标记框", Prefs.getB("cfg_showbox", true));
        final TextView sw2 = Ui.chip(c, "显示准星", Prefs.getB("cfg_cross", true));
        final TextView sw3 = Ui.chip(c, "显示连线", Prefs.getB("cfg_link", true));
        final TextView sw4 = Ui.chip(c, "显示面板", Prefs.getB("cfg_panel", true));
        View.OnClickListener toggler = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (v == sw1) { boolean b = !Prefs.getB("cfg_showbox", true); Prefs.setB("cfg_showbox", b); sw1.setText("显示标记框"); sw1.setBackground(Ui.pressable(b ? Ui.PRIMARY : Ui.SURFACE_2, Ui.R_PILL, ctx)); sw1.setTextColor(b ? Ui.ON_PRIMARY : Ui.TEXT_SUB); }
                if (v == sw2) { boolean b = !Prefs.getB("cfg_cross", true); Prefs.setB("cfg_cross", b); sw2.setBackground(Ui.pressable(b ? Ui.PRIMARY : Ui.SURFACE_2, Ui.R_PILL, ctx)); sw2.setTextColor(b ? Ui.ON_PRIMARY : Ui.TEXT_SUB); }
                if (v == sw3) { boolean b = !Prefs.getB("cfg_link", true); Prefs.setB("cfg_link", b); sw3.setBackground(Ui.pressable(b ? Ui.PRIMARY : Ui.SURFACE_2, Ui.R_PILL, ctx)); sw3.setTextColor(b ? Ui.ON_PRIMARY : Ui.TEXT_SUB); }
                if (v == sw4) { boolean b = !Prefs.getB("cfg_panel", true); Prefs.setB("cfg_panel", b); sw4.setBackground(Ui.pressable(b ? Ui.PRIMARY : Ui.SURFACE_2, Ui.R_PILL, ctx)); sw4.setTextColor(b ? Ui.ON_PRIMARY : Ui.TEXT_SUB); }
            }
        };
        sw1.setOnClickListener(toggler);
        sw2.setOnClickListener(toggler);
        sw3.setOnClickListener(toggler);
        sw4.setOnClickListener(toggler);
        LinearLayout swRow1 = Ui.row(c);
        LinearLayout.LayoutParams cw = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cw.rightMargin = Ui.dp(c, 8);
        swRow1.addView(sw1, cw);
        swRow1.addView(sw2, cw);
        tune.addView(swRow1);
        LinearLayout swRow2 = Ui.row(c);
        swRow2.setPadding(0, Ui.dp(c, 8), 0, 0);
        swRow2.addView(sw3, cw);
        swRow2.addView(sw4, cw);
        tune.addView(swRow2);

        Ui.stack(page, tune);

        root = sc;
        refreshEngineBtn();
        refreshWeaponTip();
        refreshMeta();
        return root;
    }

    @Override
    public void onShow() {
        if (root == null) return;
        ps = ParamStore.loadCurrent(ctx);
        refreshEngineBtn();
        refreshDist();
    }

    private void refreshEngineBtn() {
        if (engineBtn == null) return;
        boolean on = ScreenEngine.RUNNING;
        engineBtn.setText(on ? "停止识别" : "开始识别");
    }

    private void saveTune() {
        Prefs.setF("an_fps", numOf(fFps, 0));
        Prefs.setI("an_step", Math.max(1, (int) numOf(fStep, 1)));
        Prefs.setF("an_ppm", numOf(fPpm, 0));
        Prefs.setF("an_bullet", numOf(fBullet, ps.bulletRef));
        Prefs.setF("an_body", numOf(fBody, ps.bodyWidth));
        Prefs.setF("an_scale", numOf(fScale, ps.speedScale));
        Prefs.setI("an_leadin", (int) numOf(fLeadIn, 0));
        Prefs.setF("cfg_redhue", numOf(fRedHue, 15));
        Prefs.setF("cfg_plo", numOf(fPurpleLo, 256));
        Prefs.setF("cfg_phi", numOf(fPurpleHi, 326));
        Prefs.setF("cfg_sat", numOf(fSat, 0.4f));
        Prefs.setF("cfg_val", numOf(fVal, 0.38f));
        Prefs.setI("cfg_work", Math.max(160, (int) numOf(fWork, 480)));
        toast("参数已保存");
    }

    @Override
    public void onResult(int req, int result, Intent data) {
        if (result != android.app.Activity.RESULT_OK || data == null || data.getData() == null) return;

        if (req == REQ_VIDEO) {
            saveTune();
            lastVideo = data.getData();
            startAnalyze(lastVideo);
        } else if (req == REQ_EXPORT) {
            try {
                java.io.OutputStream os = ctx.getContentResolver().openOutputStream(data.getData());
                if (os == null) { toast("导出失败"); return; }
                os.write(buildReportText().getBytes("UTF-8"));
                os.flush();
                os.close();
                toast("报告已导出");
            } catch (Throwable t) {
                toast("导出失败");
            }
        }
    }

    private void startAnalyze(android.net.Uri uri) {
        VideoAnalyzer.Config cfg = VideoAnalyzer.Config.from(ps);
        cfg.fps = numOf(fFps, 0);
        cfg.frameStep = Math.max(1, (int) numOf(fStep, 1));
        cfg.pxPerMeter = numOf(fPpm, 0);
        cfg.bulletRef = numOf(fBullet, ps.bulletRef);
        cfg.bodyWidth = numOf(fBody, ps.bodyWidth);
        cfg.speedScale = numOf(fScale, ps.speedScale);
        cfg.leadInFrames = (int) numOf(fLeadIn, 0);
        cfg.workWidth = Prefs.getI("cfg_work", 480);
        cfg.color.redHueTol = Prefs.getF("cfg_redhue", 15f);
        cfg.color.purpleLo = Prefs.getF("cfg_plo", 256f);
        cfg.color.purpleHi = Prefs.getF("cfg_phi", 326f);
        cfg.color.minSat = Prefs.getF("cfg_sat", 0.40f);
        cfg.color.minVal = Prefs.getF("cfg_val", 0.38f);
        cfg.color.detectRed = Prefs.getB("cfg_red", true);
        cfg.color.detectPurple = Prefs.getB("cfg_purple", true);

        statusLine.setText("正在逐帧分析…");
        reportBox.removeAllViews();

        VideoAnalyzer.run(ctx, uri, ps, cfg, new VideoAnalyzer.Callback() {
            @Override
            public void onProgress(final int percent, final String msg) {
                statusLine.setText("分析中 " + percent + "% · " + msg);
            }

            @Override
            public void onFinish(final Analysis.Report report) {
                last = report;
                Reports.last = report;      // 给「思路」页的智能推演用
                renderReport(report);
            }

            @Override
            public void onFail(final String msg) {
                statusLine.setText("分析失败:" + msg);
                toast(msg);
            }
        });
    }

    private void renderReport(Analysis.Report r) {
        statusLine.setText("分析完成 · 帧数 " + r.framesTotal + " · 命中子弹 "
                + r.bulletFrames + " 帧 · 预判点 " + r.leadFrames + " 帧 · 有效弹道 "
                + r.validBursts + "/" + r.bursts + " 段 · 打中 " + r.dist.hitDist.size()
                + " · 没打中 " + r.dist.missDist.size()
                + (r.angleSamples > 0 ? " · 交火方向角均值 "
                + Physics.fmt(r.angleAvgDeg, 1) + "° · 斜向系数 "
                + Physics.fmt(r.slantAvg, 2) : ""));

        resultBox.setText("视频 " + (r.durationMs / 1000f) + " 秒 · 采样 " + Math.round(r.fps)
                + "fps · 平均距离 " + Math.round(r.estDistance) + "m · 像素当量 "
                + Math.round(r.pxPerMeter) + " px/m");

        if (videoInfo != null) {
            videoInfo.setText("已导入视频:" + (Math.round(r.durationMs / 100f) / 10f) + " 秒 · 采样 "
                    + Math.round(r.fps) + "fps · 帧数 " + r.framesTotal
                    + " · 有效弹道 " + r.validBursts + "/" + r.bursts
                    + "\n本次调参口径:参考弹速 " + Segment.trim(numOf(fBullet, ps.bulletRef))
                    + " · 身位当量 " + Segment.trim(numOf(fBody, ps.bodyWidth))
                    + " · 速度换算 " + Segment.trim(numOf(fScale, ps.speedScale))
                    + " · 武器 " + WeaponPreset.byId(weaponId).name);
        }

        reportBox.removeAllViews();

        if (!r.logs.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (String s : r.logs) sb.append("· ").append(s).append("\n");
            TextView log = Ui.dim(ctx, sb.toString().trim());
            reportBox.addView(log);
            reportBox.addView(Ui.gap(ctx, 8));
        }

        // 表头
        LinearLayout h = Ui.row(ctx);
        h.addView(cell("距离", 0.8f, true));
        h.addView(cell("人物速度", 1f, true));
        h.addView(cell("弹速", 0.9f, true));
        h.addView(cell("实测预判", 1f, true));
        h.addView(cell("参数预判", 1f, true));
        h.addView(cell("结论", 1.2f, true));
        reportBox.addView(h);

        for (Analysis.SegRow row : r.rows) {
            reportBox.addView(hline());

            LinearLayout line = Ui.row(ctx);
            line.addView(cell(Segment.trim(row.distance) + "m", 0.8f, false));
            line.addView(cell(Physics.fmt(row.charSpeed, 1), 1f, false));
            line.addView(cell(Segment.trim(row.bulletSpeed), 0.9f, false));
            line.addView(cell(row.samples == 0 ? "—" : Physics.fmt(row.need, 2), 1f, true));
            line.addView(cell(Physics.fmt(row.cur, 2), 1f, false));

            int col = row.sumVerdict == 0 ? Ui.GREEN : (row.sumVerdict > 0 ? Ui.AMBER : Ui.PRIMARY);
            TextView vv = Ui.text(ctx, row.samples == 0 ? "缺样本" : Physics.verdictText(row.sumVerdict),
                    11.5f, col, true);
            vv.setGravity(android.view.Gravity.CENTER);
            vv.setLayoutParams(new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1.2f));
            line.addView(vv);
            reportBox.addView(line);

            StringBuilder note = new StringBuilder();
            if (row.samples == 0) {
                note.append("该段本次视频里没有对应距离的样本");
            } else {
                note.append("样本 ").append(row.samples).append(" · 偏差 ")
                        .append(row.diff > 0 ? "+" : "").append(Physics.fmt(row.diff, 2))
                        .append(" · 建议 ").append(Physics.fmt(row.suggest, 2)).append(" 身位");
                if (row.theory) note.append(" · 理论推算");
            }
            note.append("\n横向衰减:").append(row.hDecay
                    ? "人物速度在 19/20 档,需要动"
                    : "人物速度不在 19/20 档,不需要动");

            reportBox.addView(Ui.gap(ctx, 2));
            reportBox.addView(Ui.dim(ctx, note.toString()));
        }

        // 汇总建议
        reportBox.addView(Ui.gap(ctx, 12));
        reportBox.addView(Ui.section(ctx, "整体建议"));
        int up = 0, down = 0, ok = 0, none = 0;
        for (Analysis.SegRow row : r.rows) {
            if (row.samples == 0) none++;
            else if (row.sumVerdict > 0) up++;
            else if (row.sumVerdict < 0) down++;
            else ok++;
        }
        reportBox.addView(Ui.body(ctx, "吻合 " + ok + " 段 · 需加大 " + up
                + " 段 · 需减小 " + down + " 段 · 缺样本 " + none + " 段"));
        if (up + down > 0) {
            reportBox.addView(Ui.gap(ctx, 6));
            reportBox.addView(Ui.dim(ctx, "点上面「一键套用建议值」会把吻合度不够的段直接改成建议值"
                    + "(按 0.1 身位取整),改完可以用「换参」把新参数推到游戏目录。"));
        }

        refreshDist();
    }

    private String buildReportText() {
        StringBuilder sb = new StringBuilder();
        sb.append("飞鸟调参 · 视频分析报告\n");
        sb.append("生成时间:")
                .append(new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss",
                        java.util.Locale.US).format(new java.util.Date())).append("\n\n");
        if (last == null) {
            sb.append("(无分析数据)\n");
            return sb.toString();
        }
        sb.append("视频时长:").append(last.durationMs / 1000f).append("s\n");
        sb.append("采样帧率:").append(Math.round(last.fps)).append("fps\n");
        sb.append("命中子弹帧:").append(last.bulletFrames).append("\n");
        sb.append("命中预判点帧:").append(last.leadFrames).append("\n");
        sb.append("有效弹道:").append(last.validBursts).append("/").append(last.bursts).append("\n");
        sb.append("平均反推距离:").append(Math.round(last.estDistance)).append("m\n");
        sb.append("像素当量:").append(Math.round(last.pxPerMeter)).append(" px/m\n");
        if (last.angleSamples > 0) {
            sb.append("交火方向角均值:").append(Physics.fmt(last.angleAvgDeg, 1)).append("°\n");
            sb.append("斜向系数:").append(Physics.fmt(last.slantAvg, 2))
                    .append("(1 = 目标正横着跑,越小越斜)\n");
            sb.append("视角偏移均值:").append(Physics.fmt(last.offsetAvgDeg, 1)).append("°\n");
            sb.append("角度样本:").append(last.angleSamples).append(" 次交火\n");
        }
        sb.append("\n");

        /* ---- 总距离概括 ---- */
        Analysis.DistSummary d = last.dist;
        sb.append("=== 总距离概括 ===\n");
        sb.append("参数总距离:").append(Segment.trim(d.total)).append(" m\n");
        sb.append("分段:").append(d.segCount).append(" 档 · ")
                .append(Segment.trim(d.segMin)).append(" ~ ")
                .append(Segment.trim(d.segMax)).append(" m · 平均每 ")
                .append(Segment.trim(d.avgGap)).append(" m 一档\n");
        if (d.measured) {
            sb.append("本次实测覆盖:").append(Math.round(d.mMin)).append(" ~ ")
                    .append(Math.round(d.mMax)).append(" m\n");
            sb.append("交火次数:").append(d.volley).append(" · 打中 ")
                    .append(d.hitDist.size()).append(" 次 · 没打中 ")
                    .append(d.missDist.size()).append(" 次 · 命中率 ")
                    .append(d.rate()).append("%\n");
            if (d.hasHit) {
                sb.append("打中距离:").append(Math.round(d.hitMin)).append(" ~ ")
                        .append(Math.round(d.hitMax)).append(" m\n");
            }
            if (d.hasMiss) {
                sb.append("没打中距离:").append(Math.round(d.missMin)).append(" ~ ")
                        .append(Math.round(d.missMax)).append(" m\n");
            }
            if (!d.dead.isEmpty()) {
                sb.append("未覆盖区间:");
                for (int i = 0; i < d.dead.size(); i++) {
                    float[] g = d.dead.get(i);
                    if (i > 0) sb.append(" 、 ");
                    sb.append(Math.round(g[0])).append("~").append(Math.round(g[1])).append("m");
                }
                sb.append("\n");
            }
        } else {
            sb.append("(本次没有实测交火样本)\n");
        }
        sb.append("\n");

        /* ---- 命中统计明细 ---- */
        sb.append("=== 命中统计(按 人物速度 × 子弹速度)===\n");
        if (d.groups.isEmpty()) {
            sb.append("(无数据)\n");
        } else {
            for (Analysis.HitGroup g : d.groups) {
                sb.append("人物速度 ").append(Segment.trim(g.charSpeed))
                        .append(" · 子弹速度 ").append(Segment.trim(g.bulletSpeed))
                        .append(" · 交火 ").append(g.volley())
                        .append(" 次 · 命中率 ").append(g.rate()).append("%\n");
                sb.append("  打中:").append(g.hitDist.isEmpty() ? "—" : distList(g.hitDist)).append(" m\n");
                sb.append("  没打中:").append(g.missDist.isEmpty() ? "—" : distList(g.missDist)).append(" m\n");
            }
        }
        sb.append("\n");

        sb.append("距离\t人物速度\t子弹速度\t实测预判\t参数预判\t偏差\t建议\n");
        for (Analysis.SegRow row : last.rows) {
            sb.append(Segment.trim(row.distance)).append("\t")
                    .append(Physics.fmt(row.charSpeed, 1)).append("\t")
                    .append(Segment.trim(row.bulletSpeed)).append("\t")
                    .append(row.samples == 0 ? "-" : Physics.fmt(row.need, 2)).append("\t")
                    .append(Physics.fmt(row.cur, 2)).append("\t")
                    .append(Physics.fmt(row.diff, 2)).append("\t")
                    .append(Physics.fmt(row.suggest, 2)).append("\n");
        }
        sb.append("\n横向衰减判定:人物速度在 19/20 档(打顶飞)才需要动,其余档位不动。\n");
        WeaponPreset w = WeaponPreset.byId(weaponId);
        sb.append("武器思路:").append(w.name).append(" —— ").append(w.idea).append("\n");
        sb.append("当前参数内存大小:").append(AutoTune.sizeText(
                AutoTune.iniSize(ps, Prefs.getStr("ini_tpl", IniBuilder.DEFAULT_TEMPLATE)))).append("\n");
        sb.append("横向衰减值:").append(AutoTune.decayText(ps)).append("\n");
        sb.append("\n口径版本:").append(WeaponPreset.VERSION).append(" —— ")
                .append(WeaponPreset.VERSION_NOTE).append("\n");
        return sb.toString();
    }

    /* ---------------- 视频调参:参数体积 / 横向衰减 / 预判命中表 ---------------- */

    private void refreshWeaponTip() {
        if (weaponTip == null) return;
        WeaponPreset w = WeaponPreset.byId(weaponId);
        weaponTip.setText("【" + w.name + "】" + w.idea);
    }

    /** 参数内存大小 + 横向衰减 */
    private void refreshMeta() {
        if (sizeLine == null || ctx == null) return;
        ps = ParamStore.loadCurrent(ctx);
        String tpl = Prefs.getStr("ini_tpl", IniBuilder.DEFAULT_TEMPLATE);
        int bytes = AutoTune.iniSize(ps, tpl);
        sizeLine.setText("参数内存大小 " + AutoTune.sizeText(bytes)
                + " · " + ps.segments.size() + " 段 · 方案 " + ps.name);
        WeaponPreset w = WeaponPreset.byId(weaponId);
        decayLine.setText("横向衰减 · " + w.name + " 口径:" + AutoTune.decayText(ps));
        refreshPredictHit();
    }

    /** 预判命中表:逐档列出预判值 / 打中 / 没打中 / 命中率 / 横向衰减 */
    private void refreshPredictHit() {
        if (predictHitBox == null || ctx == null) return;
        predictHitBox.removeAllViews();
        ps = ParamStore.loadCurrent(ctx);

        if (ps.segments.isEmpty()) {
            predictHitBox.addView(Ui.dim(ctx, "参数表还是空的,先去「参数」页生成或新增分段。"));
            return;
        }

        LinearLayout h = Ui.row(ctx);
        h.addView(cell("距离", 0.78f, true));
        h.addView(cell("预判", 0.78f, true));
        h.addView(cell("打中", 0.72f, true));
        h.addView(cell("没中", 0.72f, true));
        h.addView(cell("命中率", 0.9f, true));
        h.addView(cell("横向衰减", 1.05f, true));
        predictHitBox.addView(h);

        int hitAll = 0, missAll = 0, emptyCnt = 0;

        for (int i = 0; i < ps.segments.size(); i++) {
            final Segment s = ps.segments.get(i);
            int hit = 0, miss = 0;

            if (last != null && last.burstList != null) {
                float half = 0.5f * segGap(ps, i);
                for (Analysis.Burst b : last.burstList) {
                    if (b == null) continue;
                    if (Math.abs(b.estDistance - s.distance) <= half) {
                        if (b.hit) hit++; else miss++;
                    }
                }
            }
            hitAll += hit;
            missAll += miss;
            if (hit + miss == 0) emptyCnt++;

            predictHitBox.addView(hline());

            LinearLayout line = Ui.row(ctx);
            line.addView(cell(Segment.trim(s.distance) + "m", 0.78f, false));
            line.addView(cell(Segment.trim(s.predict), 0.78f, true));

            TextView ht = cell(String.valueOf(hit), 0.72f, hit > 0);
            ht.setTextColor(hit > 0 ? Ui.GREEN : Ui.TEXT_DIM);
            line.addView(ht);

            TextView mt = cell(String.valueOf(miss), 0.72f, miss > 0);
            mt.setTextColor(miss > 0 ? Ui.RED : Ui.TEXT_DIM);
            line.addView(mt);

            int n = hit + miss;
            int rate = n == 0 ? -1 : Math.round(hit * 100f / n);
            TextView rt = cell(rate < 0 ? "—" : rate + "%", 0.9f, true);
            if (rate >= 0) {
                rt.setTextColor(rate >= 80 ? Ui.GREEN : (rate >= 50 ? Ui.AMBER : Ui.RED));
            }
            line.addView(rt);

            boolean tf = Physics.hitSpeedBracket(s.charSpeed);
            TextView dt = cell(tf ? (Segment.trim(s.hDecay) + " · 顶飞") : "0", 1.05f, tf);
            dt.setTextColor(tf ? Ui.PURPLE : Ui.TEXT_DIM);
            line.addView(dt);

            predictHitBox.addView(line);
        }

        predictHitBox.addView(Ui.gap(ctx, 12));
        predictHitBox.addView(Ui.kv(ctx, "交火合计",
                "打中 " + hitAll + " · 没中 " + missAll,
                hitAll >= missAll ? Ui.GREEN : Ui.AMBER));
        predictHitBox.addView(Ui.gap(ctx, 7));
        predictHitBox.addView(Ui.kv(ctx, "还没样本的档", emptyCnt + " 档 / 共 "
                + ps.segments.size() + " 档", emptyCnt == 0 ? Ui.GREEN : Ui.AMBER));
        predictHitBox.addView(Ui.gap(ctx, 10));
        predictHitBox.addView(Ui.dim(ctx,
                "打中 = 这档距离的交火里测到了紫色预判点;没中 = 只有红外弹轨迹。"
                        + "横向衰减只有人物速度 19 / 20(打顶飞)档才给值,其余档位一律 0。"));
    }

    private static float segGap(ParamSet p, int idx) {
        int n = p.segments.size();
        if (n < 2) return p.totalDistance > 0 ? p.totalDistance : 400f;
        if (idx == 0) {
            return Math.max(5f, p.segments.get(1).distance - p.segments.get(0).distance);
        }
        if (idx == n - 1) {
            return Math.max(5f, p.segments.get(idx).distance - p.segments.get(idx - 1).distance);
        }
        return Math.max(5f, (p.segments.get(idx + 1).distance
                - p.segments.get(idx - 1).distance) * 0.5f);
    }

    /* ---------------- 总距离 / 命中统计 ---------------- */

    /** 刷新「当前参数 · 总距离」卡片(与是否有分析数据无关) */
    private void refreshDist() {
        if (distBox == null || ctx == null) return;
        ps = ParamStore.loadCurrent(ctx);

        float total = ps.totalDistance > 0 ? ps.totalDistance : 400f;
        totalBig.setText(Segment.trim(total) + " m");

        int n = ps.segments.size();
        float lo = 0, hi = 0, gap = 0;
        if (n > 0) {
            lo = Float.MAX_VALUE;
            for (Segment s : ps.segments) {
                if (s.distance < lo) lo = s.distance;
                if (s.distance > hi) hi = s.distance;
            }
            gap = n > 1 ? (hi - lo) / (n - 1) : 0f;
        }

        StringBuilder info = new StringBuilder();
        info.append("方案 ").append(ps.name).append(" · 分 ").append(n).append(" 档");
        if (n > 0) {
            info.append(" · ").append(Segment.trim(lo)).append(" ~ ")
                    .append(Segment.trim(hi)).append(" m");
        }
        if (gap > 0) info.append(" · 平均每 ").append(Segment.trim(gap)).append(" m 一档");
        info.append("\n最远射击距离 ").append(Segment.trim(total)).append(" 米");
        distInfo.setText(info.toString());

        Analysis.DistSummary d = (last != null) ? last.dist : null;
        distBar.setData(d);

        distBox.removeAllViews();

        if (d == null || !d.measured) {
            distSummary.setText("总距离概括:覆盖 0 → " + Segment.trim(total) + " 米,共 "
                    + n + " 个距离档"
                    + (gap > 0 ? ",每档约 " + Segment.trim(gap) + " 米" : "")
                    + "。跑一次视频分析,上面这条距离条会按实测填上打中/没打中的分布。");
            distBox.addView(Ui.dim(ctx, "还没有实测数据。"));
            renderHitStats(null);
            refreshMeta();
            return;
        }

        /* 概括句 */
        StringBuilder sb = new StringBuilder();
        sb.append("总距离概括:参数覆盖 0 → ").append(Segment.trim(total)).append(" 米,共 ")
                .append(n).append(" 档");
        sb.append("\n本次实测 ").append(Math.round(d.mMin)).append(" ~ ")
                .append(Math.round(d.mMax)).append(" 米(跨度 ")
                .append(Math.round(d.mMax - d.mMin)).append(" 米)· 交火 ")
                .append(d.volley).append(" 次");
        sb.append("\n打中 ").append(d.hitDist.size()).append(" 次");
        if (d.hasHit) {
            sb.append("(").append(Math.round(d.hitMin)).append("~")
                    .append(Math.round(d.hitMax)).append(" m)");
        }
        sb.append(" · 没打中 ").append(d.missDist.size()).append(" 次");
        if (d.hasMiss) {
            sb.append("(").append(Math.round(d.missMin)).append("~")
                    .append(Math.round(d.missMax)).append(" m)");
        }
        sb.append(" · 命中率 ").append(d.rate()).append("%");
        distSummary.setText(sb.toString());

        /* 覆盖情况 */
        int covered = 0;
        for (int i = 0; i < d.cells; i++) if (d.cellTotal[i] > 0) covered++;
        int coverPct = d.cells > 0 ? Math.round(covered * 100f / d.cells) : 0;

        distBox.addView(Ui.kv(ctx, "距离覆盖率", coverPct + "%", coverPct >= 60 ? Ui.GREEN : Ui.AMBER));
        distBox.addView(Ui.gap(ctx, 7));
        distBox.addView(Ui.kv(ctx, "打中距离均值",
                d.hitDist.isEmpty() ? "—" : Math.round(avg(d.hitDist)) + " m", Ui.GREEN));
        distBox.addView(Ui.gap(ctx, 7));
        distBox.addView(Ui.kv(ctx, "没打中距离均值",
                d.missDist.isEmpty() ? "—" : Math.round(avg(d.missDist)) + " m", Ui.RED));

        if (!d.dead.isEmpty()) {
            StringBuilder db = new StringBuilder();
            int show = Math.min(5, d.dead.size());
            for (int i = 0; i < show; i++) {
                float[] seg = d.dead.get(i);
                if (i > 0) db.append("、");
                db.append(Math.round(seg[0])).append("~").append(Math.round(seg[1])).append("m");
            }
            if (d.dead.size() > show) db.append(" 等 ").append(d.dead.size()).append(" 段");
            distBox.addView(Ui.gap(ctx, 7));
            distBox.addView(Ui.kv(ctx, "空白距离段(没样本)", db.toString(), Ui.AMBER));
        }

        renderHitStats(d);
        refreshMeta();
    }

    /** 按 人物速度 × 子弹速度 分组展示打中/没打中的具体距离 */
    private void renderHitStats(Analysis.DistSummary d) {
        if (hitBox == null || ctx == null) return;
        hitBox.removeAllViews();

        if (d == null || !d.measured || d.groups.isEmpty()) {
            hitBox.addView(Ui.dim(ctx, "还没有实测数据。跑一次视频分析,这里会按速度档列出打中与没打中的距离。"));
            return;
        }

        LinearLayout h = Ui.row(ctx);
        h.addView(cell("人物速度", 1f, true));
        h.addView(cell("子弹速度", 1f, true));
        h.addView(cell("打中", 0.85f, true));
        h.addView(cell("没打中", 0.95f, true));
        h.addView(cell("命中率", 0.95f, true));
        hitBox.addView(h);

        for (Analysis.HitGroup g : d.groups) {
            hitBox.addView(hline());

            LinearLayout line = Ui.row(ctx);
            line.addView(cell(Segment.trim(g.charSpeed), 1f, false));
            line.addView(cell(Segment.trim(g.bulletSpeed), 1f, false));
            line.addView(cell(g.hitDist.size() + " 次", 0.85f, true));
            line.addView(cell(g.missDist.size() + " 次", 0.95f, true));
            int rate = g.rate();
            TextView rt = cell(rate + "%", 0.95f, true);
            rt.setTextColor(rate >= 80 ? Ui.GREEN : (rate >= 50 ? Ui.AMBER : Ui.RED));
            line.addView(rt);
            hitBox.addView(line);

            if (!g.hitDist.isEmpty()) {
                hitBox.addView(Ui.gap(ctx, 4));
                hitBox.addView(Ui.text(ctx, "打中:" + distList(g.hitDist) + " m",
                        11.5f, Ui.GREEN, false));
            }
            if (!g.missDist.isEmpty()) {
                hitBox.addView(Ui.gap(ctx, 3));
                hitBox.addView(Ui.text(ctx, "没打中:" + distList(g.missDist) + " m",
                        11.5f, Ui.RED, false));
            }
        }

        hitBox.addView(Ui.gap(ctx, 12));
        hitBox.addView(Ui.dim(ctx, "人物速度落在 19 / 20 档的,横向衰减才需要动;其余档位一律不用动。"));
    }

    private View legendDot(Context c, int color, String label) {
        LinearLayout r = Ui.row(c);
        View dot = new View(c);
        android.graphics.drawable.GradientDrawable g =
                new android.graphics.drawable.GradientDrawable();
        g.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        g.setColor(color);
        dot.setBackground(g);
        r.addView(dot, new LinearLayout.LayoutParams(Ui.dp(c, 8), Ui.dp(c, 8)));
        TextView tx = Ui.text(c, label, 11f, Ui.TEXT_DIM, false);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.leftMargin = Ui.dp(c, 4);
        r.addView(tx, tlp);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rlp.rightMargin = Ui.dp(c, 16);
        r.setLayoutParams(rlp);
        return r;
    }

    private static String distList(List<Float> src) {
        List<Float> c = new java.util.ArrayList<Float>(src);
        java.util.Collections.sort(c);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < c.size(); i++) {
            if (i > 0) sb.append(" ");
            sb.append(Math.round(c.get(i)));
        }
        return sb.toString();
    }

    private static float avg(List<Float> l) {
        if (l == null || l.isEmpty()) return 0f;
        float s = 0;
        for (float v : l) s += v;
        return s / l.size();
    }

    /* ---------------- 小工具 ---------------- */

    private View hline() {
        View v = new View(ctx);
        v.setBackgroundColor(Ui.OUTLINE_SOFT);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, Ui.dp(ctx, 0.8f)));
        lp.topMargin = Ui.dp(ctx, 7);
        lp.bottomMargin = Ui.dp(ctx, 7);
        v.setLayoutParams(lp);
        return v;
    }

    private TextView cell(String s, float weight, boolean strong) {
        TextView t = Ui.text(ctx, s, 11.5f, strong ? Ui.TEXT : Ui.TEXT_SUB, strong);
        t.setGravity(android.view.Gravity.CENTER);
        t.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, weight));
        return t;
    }

    private EditText num() {
        return Ui.numInput(ctx, "");
    }

    private void addWeight(LinearLayout parent, View v, float weight, int rightMarginDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, weight);
        lp.rightMargin = Ui.dp(ctx, rightMarginDp);
        parent.addView(v, lp);
    }

    private static float numOf(EditText e, float def) {
        try {
            String s = e.getText().toString().trim();
            if (s.isEmpty()) return def;
            return Float.parseFloat(s);
        } catch (Throwable t) {
            return def;
        }
    }
}

package com.feiniao.tuner.page;

import android.content.Intent;
import android.view.View;

/** 页面宿主接口,由 MainActivity 实现 */
public interface Host {
    void pickDocument(int req, String mime, String title, Page owner);

    void pickTree(int req, String title, Page owner);

    /** 选择保存位置(导出文件) */
    void pickCreate(int req, String mime, String suggestedName, Page owner);

    void toast(String s);

    /** 申请悬浮窗权限;已授权直接回调 */
    void ensureOverlay(Runnable after);

    /** 请求屏幕采集授权并启动识别引擎 */
    void startProjection();

    void openUrl(String url);

    /** 切换底部导航 */
    void switchTo(int index);
}

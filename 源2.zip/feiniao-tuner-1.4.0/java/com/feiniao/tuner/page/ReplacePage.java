package com.feiniao.tuner.page;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.feiniao.tuner.Prefs;
import com.feiniao.tuner.Ui;
import com.feiniao.tuner.core.IniBuilder;
import com.feiniao.tuner.model.ParamSet;
import com.feiniao.tuner.model.ParamStore;
import com.feiniao.tuner.model.Segment;
import com.feiniao.tuner.net.Net;
import com.feiniao.tuner.root.ParamReplacer;
import com.feiniao.tuner.root.Shell;
import com.feiniao.tuner.util.Saf;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** 更换参数:直链打包 preference.ini 并替换自定义目录里的文件 */
public class ReplacePage extends Page {

    private static final int REQ_TREE = 2301;
    private static final int REQ_INI = 2302;

    private ParamSet ps;
    private EditText fUrl, fName, fTarget;
    private TextView rootState, preview, logBox, pathHint, curInfo;
    private LinearLayout recentBox;
    private String lastTreeUri = "";

    @Override
    public String title() {
        return "更换参数";
    }

    @Override
    public View build(Context c, final Host host) {
        this.ctx = c;
        this.host = host;
        ps = ParamStore.loadCurrent(c);

        LinearLayout page = Ui.page(c);
        ScrollView sc = Ui.scroll(c);
        sc.addView(page);

        Ui.stack(page, Ui.body(c,
                "把参数推到游戏目录就靠这一页。直链拉回来的内容会自动打包成 preference.ini,"
                        + "然后原地替换你指定的目标文件;替换前会自动留一份备份。"));

        /* ---------- 运行环境 ---------- */
        LinearLayout env = Ui.card(c);
        env.addView(Ui.h2(c, "运行环境"));
        env.addView(Ui.gap(c, 8));
        env.addView(Ui.kv(c, "Root 权限", "检测中…", Ui.TEXT_SUB));
        rootState = (TextView) ((LinearLayout) env.getChildAt(env.getChildCount() - 1)).getChildAt(1);
        env.addView(Ui.gap(c, 6));
        curInfo = Ui.dim(c, "");
        env.addView(curInfo);
        env.addView(Ui.gap(c, 10));
        TextView recheck = Ui.button(c, "重新检测 Root", 1);
        env.addView(recheck);
        recheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { checkRoot(); }
        });
        Ui.stack(page, env);

        /* ---------- 目标路径 ---------- */
        LinearLayout tgt = Ui.card(c);
        tgt.addView(Ui.h2(c, "自定义目标路径"));
        tgt.addView(Ui.gap(c, 6));
        tgt.addView(Ui.dim(c, "填游戏参数文件 preference.ini 的完整路径,或者用下面的按钮选目录自动换算。"));
        tgt.addView(Ui.gap(c, 10));

        fTarget = Ui.input(c, "/sdcard/Android/data/…/preference.ini");
        fTarget.setText(Prefs.getStr("target_path", ""));
        tgt.addView(fTarget);
        tgt.addView(Ui.gap(c, 8));
        pathHint = Ui.dim(c, "");
        tgt.addView(pathHint);
        tgt.addView(Ui.gap(c, 10));

        LinearLayout tb = Ui.row(c);
        TextView pickDir = Ui.button(c, "选择目录", 1);
        TextView pickFile = Ui.button(c, "选择目标文件", 2);
        addW(tb, pickDir, 1f, 8);
        addW(tb, pickFile, 1.2f, 0);
        tgt.addView(tb);

        pickDir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                host.pickTree(REQ_TREE, "选择参数所在目录", ReplacePage.this);
            }
        });
        pickFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                host.pickDocument(REQ_INI, "*/*", "选择 preference.ini", ReplacePage.this);
            }
        });

        tgt.addView(Ui.gap(c, 10));
        tgt.addView(Ui.section(c, "常用路径"));
        recentBox = Ui.col(c);
        tgt.addView(recentBox);
        Ui.stack(page, tgt);

        /* ---------- 直链 ---------- */
        LinearLayout dl = Ui.card(c);
        dl.addView(Ui.h2(c, "直链拉取"));
        dl.addView(Ui.gap(c, 6));
        dl.addView(Ui.dim(c, "支持原始 ini、gzip 压缩、zip 压缩包三种直链。压缩包里会优先找 preference.ini。"));
        dl.addView(Ui.gap(c, 10));

        fUrl = Ui.input(c, "https://…/params.ini");
        fUrl.setText(Prefs.getStr("last_url", ""));
        dl.addView(fUrl);
        dl.addView(Ui.gap(c, 8));
        fName = Ui.input(c, "preference.ini");
        fName.setText(Prefs.getStr("last_name", "preference.ini"));
        dl.addView(Ui.field(c, "保存文件名", fName));
        dl.addView(Ui.gap(c, 10));

        LinearLayout db = Ui.row(c);
        TextView fetch = Ui.button(c, "拉取并预览", 1);
        TextView pack = Ui.button(c, "打包并替换", 0);
        addW(db, fetch, 1f, 8);
        addW(db, pack, 1.2f, 0);
        dl.addView(db);

        dl.addView(Ui.gap(c, 12));
        preview = Ui.dim(c, "还没有拉取内容。");
        preview.setTextIsSelectable(true);
        dl.addView(preview);

        fetch.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { doFetch(); }
        });
        pack.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { doReplaceFromUrl(); }
        });
        Ui.stack(page, dl);

        /* ---------- 本地方案直接推 ---------- */
        LinearLayout loc = Ui.card(c);
        loc.addView(Ui.h2(c, "用当前工作方案替换"));
        loc.addView(Ui.gap(c, 6));
        loc.addView(Ui.dim(c, "不经过直链,直接把「参数与预判表」里这套方案打包成 preference.ini 推过去。"));
        loc.addView(Ui.gap(c, 10));

        LinearLayout lb = Ui.row(c);
        TextView showIni = Ui.button(c, "预览 ini", 2);
        TextView push = Ui.button(c, "打包并替换", 0);
        addW(lb, showIni, 1f, 8);
        addW(lb, push, 1.2f, 0);
        loc.addView(lb);

        showIni.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ps = ParamStore.loadCurrent(ctx);
                preview.setText(IniBuilder.build(ps, Prefs.getStr("ini_tpl", IniBuilder.DEFAULT_TEMPLATE)));
                toast("下面就是当前方案打包出来的 ini");
            }
        });
        push.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { doReplaceLocal(); }
        });

        loc.addView(Ui.gap(c, 14));
        loc.addView(Ui.section(c, "ini 模板"));
        loc.addView(Ui.dim(c, "占位符:{{NAME}} {{TOTAL}} {{COUNT}} {{BODY}},"
                + "循环块 {{#SEG}}…{{/SEG}} 内可用 {{D}} {{CS}} {{BS}} {{P}} {{H}} {{I}}。"
                + "改了模板再点上面的预览或替换即可生效。"));
        loc.addView(Ui.gap(c, 8));
        final EditText tpl = Ui.input(c, "");
        tpl.setSingleLine(false);
        tpl.setMinLines(6);
        tpl.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        tpl.setText(Prefs.getStr("ini_tpl", IniBuilder.DEFAULT_TEMPLATE));
        loc.addView(tpl);
        loc.addView(Ui.gap(c, 8));
        LinearLayout tRow = Ui.row(c);
        TextView tSave = Ui.button(c, "保存模板", 1);
        TextView tDef = Ui.button(c, "用默认模板", 2);
        addW(tRow, tSave, 1f, 8);
        addW(tRow, tDef, 1f, 0);
        loc.addView(tRow);
        tSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Prefs.setStr("ini_tpl", tpl.getText().toString());
                toast("模板已保存");
            }
        });
        tDef.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tpl.setText(IniBuilder.DEFAULT_TEMPLATE);
                Prefs.setStr("ini_tpl", IniBuilder.DEFAULT_TEMPLATE);
                toast("已恢复默认模板");
            }
        });

        Ui.stack(page, loc);

        /* ---------- 日志 ---------- */
        LinearLayout lg = Ui.card(c);
        lg.addView(Ui.h2(c, "执行日志"));
        lg.addView(Ui.gap(c, 8));
        logBox = Ui.dim(c, "等待操作。");
        logBox.setTextIsSelectable(true);
        lg.addView(logBox);
        Ui.stack(page, lg);

        root = sc;
        refreshTarget();
        refreshRecent();
        checkRoot();
        return root;
    }

    @Override
    public void onShow() {
        if (root == null) return;
        ps = ParamStore.loadCurrent(ctx);
        refreshTarget();
    }

    /* ---------------- 环境 ---------------- */

    private void checkRoot() {
        if (rootState != null) rootState.setText("检测中…");
        new Thread(new Runnable() {
            @Override
            public void run() {
                final boolean root = Shell.hasRoot();
                final String info = root ? Shell.su("id").all() : Shell.rootInfo();
                if (rootState != null) {
                    rootState.post(new Runnable() {
                        @Override
                        public void run() {
                            if (rootState == null) return;
                            rootState.setText(root ? "已授权" : "未授权");
                            rootState.setTextColor(root ? Ui.GREEN : Ui.RED);
                        }
                    });
                }
                if (curInfo != null) {
                    curInfo.post(new Runnable() {
                        @Override
                        public void run() {
                            if (curInfo != null) curInfo.setText("root 通道:" + info.replace("\n", " "));
                        }
                    });
                }
            }
        }).start();

        if (curInfo != null) {
            curInfo.setText("当前工作方案:" + ps.name + " · " + ps.segments.size()
                    + " 段 · 总距离 " + Segment.trim(ps.totalDistance) + "m");
        }
    }

    /* ---------------- 路径 ---------------- */

    private void refreshTarget() {
        String p = fTarget.getText().toString().trim();
        if (p.isEmpty()) {
            pathHint.setText("尚未设置目标路径。");
            return;
        }
        String dir = new File(p).getParent();
        pathHint.setText("目录:" + (dir == null ? "-" : dir)
                + "\n文件名:" + new File(p).getName()
                + "\n替换前会自动备份到 " + dir + "/feiniao_backup");
    }

    private void refreshRecent() {
        if (recentBox == null) return;
        recentBox.removeAllViews();
        String raw = Prefs.getStr("recent_paths", "");
        List<String> list = new ArrayList<>();
        if (!raw.isEmpty()) {
            for (String s : raw.split("\n")) if (!s.trim().isEmpty()) list.add(s.trim());
        }
        if (list.isEmpty()) {
            recentBox.addView(Ui.dim(ctx, "选中过的目录会记在这里,下次一点就填上。"));
            return;
        }
        for (final String p : list) {
            TextView chip = Ui.chip(ctx, p, false);
            chip.setPadding(Ui.dp(ctx, 10), Ui.dp(ctx, 7), Ui.dp(ctx, 10), Ui.dp(ctx, 7));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = Ui.dp(ctx, 6);
            chip.setLayoutParams(lp);
            chip.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    fTarget.setText(p);
                    Prefs.setStr("target_path", p);
                    refreshTarget();
                }
            });
            recentBox.addView(chip);
        }
    }

    private void rememberPath(String path) {
        if (path == null || path.trim().isEmpty()) return;
        String raw = Prefs.getStr("recent_paths", "");
        List<String> list = new ArrayList<>();
        for (String s : raw.split("\n")) if (!s.trim().isEmpty()) list.add(s.trim());
        list.remove(path);
        list.add(0, path);
        while (list.size() > 6) list.remove(list.size() - 1);
        StringBuilder sb = new StringBuilder();
        for (String s : list) sb.append(s).append("\n");
        Prefs.setStr("recent_paths", sb.toString().trim());
        Prefs.setStr("target_path", path);
        refreshRecent();
    }

    /* ---------------- 拉取 ---------------- */

    private void doFetch() {
        final String url = fUrl.getText().toString().trim();
        if (url.isEmpty()) { toast("先填直链"); return; }
        Prefs.setStr("last_url", url);
        preview.setText("正在拉取…");
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Net.Res r = Net.fetch(url, new File(ctx.getCacheDir(), "net"), null);
                    final String head = head(r.text, 1200);
                    final String note = r.note + "\n大小 " + (r.text.length()) + " 字符\n\n" + head;
                    preview.post(new Runnable() {
                        @Override
                        public void run() {
                            preview.setText(note);
                            toast("拉取成功");
                        }
                    });
                } catch (final Throwable t) {
                    preview.post(new Runnable() {
                        @Override
                        public void run() {
                            preview.setText("拉取失败:" + t.getMessage());
                            toast("拉取失败");
                        }
                    });
                }
            }
        }).start();
    }

    private void doReplaceFromUrl() {
        final String url = fUrl.getText().toString().trim();
        final String target = fTarget.getText().toString().trim();
        final String name = fName.getText().toString().trim();
        if (url.isEmpty()) { toast("先填直链"); return; }
        if (target.isEmpty()) { toast("先设置目标路径"); return; }
        rememberPath(target);
        setLog("正在拉取直链…");

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Net.Res r = Net.fetch(url, new File(ctx.getCacheDir(), "net"), null);
                    File staged = ParamReplacer.stage(ctx, r.text,
                            name.isEmpty() ? "preference.ini" : name);
                    final StringBuilder sb = new StringBuilder();
                    sb.append("拉取:").append(r.note).append("\n");
                    sb.append("暂存:").append(staged.getName()).append(" (")
                            .append(r.text.length()).append(" 字符)\n");
                    ParamReplacer.Out o = ParamReplacer.replaceWithRoot(staged, target);
                    sb.append("结果:").append(o.msg).append("\n");
                    if (!o.backupPath.isEmpty()) sb.append("备份:").append(o.backupPath).append("\n");
                    if (o.detail != null && !o.detail.isEmpty())
                        sb.append(o.detail).append("\n");
                    setLog(sb.toString());
                    final boolean ok = o.ok;
                    preview.post(new Runnable() {
                        @Override
                        public void run() { toast(ok ? "替换完成" : "替换失败"); }
                    });
                } catch (final Throwable t) {
                    setLog("失败:" + t.getMessage());
                    preview.post(new Runnable() {
                        @Override
                        public void run() { toast("替换失败"); }
                    });
                }
            }
        }).start();
    }

    private void doReplaceLocal() {
        final String target = fTarget.getText().toString().trim();
        if (target.isEmpty()) { toast("先设置目标路径"); return; }
        rememberPath(target);
        ps = ParamStore.loadCurrent(ctx);
        final String ini = IniBuilder.build(ps,
                Prefs.getStr("ini_tpl", IniBuilder.DEFAULT_TEMPLATE));
        setLog("正在推送当前方案…");

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String name = new File(target).getName();
                    File staged = ParamReplacer.stage(ctx, ini, name.isEmpty() ? "preference.ini" : name);
                    ParamReplacer.Out o = ParamReplacer.replaceWithRoot(staged, target);
                    StringBuilder sb = new StringBuilder();
                    sb.append("方案:").append(ps.name).append(" · ").append(ps.segments.size()).append(" 段\n");
                    sb.append("打包:").append(ini.length()).append(" 字符\n");
                    sb.append("目标:").append(target).append("\n");
                    sb.append("结果:").append(o.msg).append("\n");
                    if (!o.backupPath.isEmpty()) sb.append("备份:").append(o.backupPath).append("\n");
                    if (o.detail != null && !o.detail.isEmpty()) sb.append(o.detail).append("\n");
                    setLog(sb.toString());
                } catch (final Throwable t) {
                    setLog("失败:" + t.getMessage());
                }
            }
        }).start();
    }

    private void setLog(final String s) {
        if (logBox == null) return;
        logBox.post(new Runnable() {
            @Override
            public void run() {
                if (logBox != null) logBox.setText(s.trim());
            }
        });
    }

    @Override
    public void onResult(int req, int result, Intent data) {
        if (result != android.app.Activity.RESULT_OK || data == null) return;
        if (req == REQ_TREE && data.getData() != null) {
            Uri tree = data.getData();
            try {
                ctx.getContentResolver().takePersistableUriPermission(tree,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            } catch (Throwable ignored) {}
            lastTreeUri = String.valueOf(tree);
            Prefs.setStr("tree_uri", lastTreeUri);
            String path = Saf.treeToPath(tree);
            if (path != null) {
                fTarget.setText(path + "/preference.ini");
                rememberPath(path + "/preference.ini");
            } else {
                List<String> kids = Saf.listChildren(ctx, tree);
                toast("这个目录换算不出文件路径,把完整路径填上去;目录里有 "
                        + kids.size() + " 个文件");
            }
            refreshTarget();
        } else if (req == REQ_INI && data.getData() != null) {
            Uri u = data.getData();
            try {
                ctx.getContentResolver().takePersistableUriPermission(u,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Throwable ignored) {}
            String path = Saf.treeToPath(u);
            if (path == null) {
                String name = Saf.displayName(ctx, u);
                toast("已选中 " + name + ",该位置换算不出真实路径,请手动补全");
            } else {
                fTarget.setText(path);
                rememberPath(path);
            }
            refreshTarget();
        }
    }

    /* ---------------- 工具 ---------------- */

    private static String head(String s, int n) {
        if (s == null) return "";
        return s.length() <= n ? s : s.substring(0, n) + "\n…(已截断)";
    }

    private void addW(LinearLayout parent, View v, float weight, int rightMarginDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, weight);
        lp.rightMargin = Ui.dp(ctx, rightMarginDp);
        parent.addView(v, lp);
    }
}

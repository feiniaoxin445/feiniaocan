package com.feiniao.tuner.page;

import android.content.Context;
import android.content.Intent;
import android.view.View;

/** 页面基类 */
public abstract class Page {

    protected Context ctx;
    protected Host host;
    protected View root;

    public abstract String title();

    public abstract View build(Context c, Host host);

    /** 每次切到该页时调用 */
    public abstract void onShow();

    /** Activity 结果回调 */
    public void onResult(int req, int result, Intent data) {}

    protected void toast(String s) {
        if (host != null) host.toast(s);
    }
}

package com.feiniao.tuner.page;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.feiniao.tuner.Prefs;
import com.feiniao.tuner.Ui;
import com.feiniao.tuner.core.AutoTune;
import com.feiniao.tuner.core.IniBuilder;
import com.feiniao.tuner.core.WeaponPreset;
import com.feiniao.tuner.model.ParamSet;
import com.feiniao.tuner.model.ParamStore;
import com.feiniao.tuner.model.Segment;
import com.feiniao.tuner.vision.ScreenEngine;

/** 说明与状态 */
public class AboutPage extends Page {

    private TextView stateBox;

    @Override
    public String title() {
        return "说明";
    }

    @Override
    public View build(Context c, final Host host) {
        this.ctx = c;
        this.host = host;

        LinearLayout page = Ui.page(c);
        ScrollView sc = Ui.scroll(c);
        sc.addView(page);

        /* ---------- 标题卡 ---------- */
        LinearLayout hero = Ui.card(c);
        TextView name = Ui.h1(c, "飞鸟调参");
        hero.addView(name);
        hero.addView(Ui.gap(c, 4));
        hero.addView(Ui.text(c, "版本 1.4.0 · 朱雀 · 思路调参 / 智能推演 / 视频调参 / 参数直推",
                13f, Ui.PRIMARY, false));
        hero.addView(Ui.gap(c, 12));
        hero.addView(Ui.body(c, "一套把「看录像调预判」这件事自动化的工具:"
                + "导入视频、逐帧识别红紫子弹标记、反推距离与人物速度、算出这段距离到底该给多少预判,"
                + "再和你的参数表逐段对齐,最后直接把 preference.ini 推到游戏目录。"
                + "这一版新增「思路调参」:把你怎么打这把枪写成一段人话,引擎解析成口径铺整张表,"
                + "再结合实测数据逐段推演该改哪几处、为什么改;识别层同时给出目标方向角、视角偏移和预判大小。"
                + "界面是液态玻璃,开场是朱雀踏步入场、站定张翼。");
        Ui.stack(page, hero);

        /* ---------- 口径版本 ---------- */
        LinearLayout ver = Ui.card(c, 0x33C58AF9);
        ver.addView(Ui.text(c, "调参口径 · " + WeaponPreset.VERSION + " 版", 15f, Ui.PURPLE, true));
        ver.addView(Ui.gap(c, 8));
        ver.addView(Ui.dim(c, "这一版的手感口径:"));
        ver.addView(Ui.gap(c, 6));
        ver.addView(Ui.body(c, "· 猎枪 —— 弹速比左轮慢,140 米往上下坠,所以这一档的子弹速度要往下压;"
                + "同距离下猎枪要多给一个半身位左右的提前量。"));
        ver.addView(Ui.gap(c, 8));
        ver.addView(Ui.body(c, "· 左轮 —— 弹速比猎枪快一点,提前量差不多差一个半身位,是三档里的基准。"));
        ver.addView(Ui.gap(c, 8));
        ver.addView(Ui.body(c, "· 横向衰减 —— 只给人物速度 19 / 20 这两档(打顶飞),其余档位一律留 0。"));
        ver.addView(Ui.gap(c, 12));
        ver.addView(Ui.text(c, "⚠ 版本提醒", 13.5f, Ui.AMBER, true));
        ver.addView(Ui.gap(c, 5));
        ver.addView(Ui.dim(c, WeaponPreset.VERSION_NOTE));
        Ui.stack(page, ver);

        /* ---------- 运行状态 ---------- */
        LinearLayout st = Ui.card(c);
        st.addView(Ui.h2(c, "运行状态"));
        st.addView(Ui.gap(c, 10));
        stateBox = Ui.body(c, "检测中…");
        st.addView(stateBox);
        st.addView(Ui.gap(c, 12));

        LinearLayout b = Ui.row(c);
        TextView perms = Ui.button(c, "权限设置", 1);
        TextView overlay = Ui.button(c, "悬浮窗设置", 2);
        addW(b, perms, 1f, 8);
        addW(b, overlay, 1f, 0);
        st.addView(b);
        perms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                    i.setData(Uri.parse("package:" + ctx.getPackageName()));
                    ctx.startActivity(i);
                } catch (Throwable t) { toast("打不开系统设置"); }
            }
        });
        overlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
                    i.setData(Uri.parse("package:" + ctx.getPackageName()));
                    ctx.startActivity(i);
                } catch (Throwable t) { toast("打不开系统设置"); }
            }
        });
        Ui.stack(page, st);

        /* ---------- 怎么用 ---------- */
        LinearLayout how = Ui.card(c);
        how.addView(Ui.h2(c, "怎么用"));
        how.addView(Ui.gap(c, 10));
        how.addView(step(c, "1", "先把参数录进「参数与预判表」",
                "总距离、身位当量、速度换算、参考子弹速度填准。身位当量是游戏里一个人物宽度折多少米,"
                        + "速度换算是人物速度那个数值换算成米/秒的系数 —— 这两个决定了理论预判的绝对值。"));
        how.addView(step(c, "2", "丢一段对枪视频进「AI 调参」",
                "选一段能看清开枪到命中全过程的录像。引擎逐帧识别红色子弹轨迹和紫色预判点,"
                        + "切出每一次交火,反推这段距离下目标到底移了多少个身位。"));
        how.addView(step(c, "3", "看逐段对比表",
                "表里会按你参数的分段,一段一段告诉你实测需要多少预判、你参数给的是多少、差了多少、建议改成多少。"
                        + "偏差为正说明参数给小了,为负说明给大了。"));
        how.addView(step(c, "4", "横向衰减单独看",
                "人物速度落在 19 / 20 这两档的时候才需要动横向衰减,其余档位不用碰。表里每段都会标出来。"));
        how.addView(step(c, "5", "套用建议值,再去「更换参数」推过去",
                "一键套用会把不吻合的段改成建议值(按 0.1 身位取整),然后直链或本地打包成 preference.ini 原地替换。"));
        how.addView(step(c, "6", "想实时看就开屏幕识别",
                "悬浮 HUD 会实时标出识别到的子弹与预判点,并把锁定分段的参数预判、理论值、偏差顶在屏幕上,"
                        + "HUD 上还会给出目标方向角、视角偏移角、斜向系数和当前的预判大小,"
                        + "控制球拖动移位,点一下收起或展开。"));
        how.addView(step(c, "7", "有自己打法思路就走「思路」页",
                "把你的理解写成一段人话(武器、距离区间、每档间隔、小距离、目标速度档、弹速取向、"
                        + "提前量加减、下坠起始、横向衰减、视角偏移),引擎先解析成口径,再按口径铺整张表;"
                        + "然后「开始推演」——它会先核口径版本、再把手上的实测样本按权重并进来,"
                        + "顺带体检横向衰减档位、预判单调性、分段覆盖,最后逐段给出改动、理由和把握度,"
                        + "按 80+ / 60+ 两档挑着套用。常写的思路可以存进思路库。"));
        Ui.stack(page, how);

        /* ---------- 识别原理 ---------- */
        LinearLayout why = Ui.card(c);
        why.addView(Ui.h2(c, "识别原理"));
        why.addView(Ui.gap(c, 10));
        why.addView(Ui.body(c, "· 子弹与预判点靠 HSV 色相分离:红色走两侧端点色相,品红/紫走 256°~326° 区间,"
                + "再按饱和度与亮度过滤,最后做连通域聚类,取块重心作为目标点。"));
        why.addView(Ui.gap(c, 8));
        why.addView(Ui.body(c, "· 距离反推有两条路。填了像素当量就直接用轨迹长度除以当量;"
                + "没填就用子弹飞行时间乘以参考弹速。后者对「出膛到首次出现在画面里」那段空档敏感,"
                + "所以留了出膛补偿帧。"));
        why.addView(Ui.gap(c, 8));
        why.addView(Ui.body(c, "· 所需预判 = 预判点在这段飞行时间里的横向位移 ÷ 身位当量。"
                + "所以同一段距离下,目标横移越猛、飞得越久,该给的预判就越大。"));
        Ui.stack(page, why);

        /* ---------- 参数速览 ---------- */
        LinearLayout quick = Ui.card(c);
        quick.addView(Ui.h2(c, "当前方案速览"));
        quick.addView(Ui.gap(c, 10));
        ParamSet ps = ParamStore.loadCurrent(c);
        quick.addView(Ui.kv(c, "方案名", ps.name, Ui.PRIMARY));
        quick.addView(Ui.gap(c, 6));
        quick.addView(Ui.kv(c, "总距离", Segment.trim(ps.totalDistance) + " m"));
        quick.addView(Ui.gap(c, 6));
        quick.addView(Ui.kv(c, "分段数", String.valueOf(ps.segments.size())));
        quick.addView(Ui.gap(c, 6));
        quick.addView(Ui.kv(c, "身位当量", Segment.trim(ps.bodyWidth) + " m"));
        quick.addView(Ui.gap(c, 6));
        quick.addView(Ui.kv(c, "速度换算", Segment.trim(ps.speedScale) + " m/s"));
        quick.addView(Ui.gap(c, 6));
        quick.addView(Ui.kv(c, "参考子弹速度", Segment.trim(ps.bulletRef)));
        quick.addView(Ui.gap(c, 6));
        quick.addView(Ui.kv(c, "像素当量",
                ps.pxPerMeter > 0 ? Segment.trim(ps.pxPerMeter) + " px/m" : "自动反推"));
        quick.addView(Ui.gap(c, 6));
        quick.addView(Ui.kv(c, "参数内存大小",
                AutoTune.sizeText(AutoTune.iniSize(ps,
                        Prefs.getStr("ini_tpl", IniBuilder.DEFAULT_TEMPLATE))), Ui.PRIMARY));
        quick.addView(Ui.gap(c, 6));
        quick.addView(Ui.kv(c, "武器思路", WeaponPreset.byId(ps.weapon).name));
        quick.addView(Ui.gap(c, 6));
        quick.addView(Ui.kv(c, "口径版本", ps.versionTag == null ? "超自然" : ps.versionTag,
                Ui.PURPLE));
        quick.addView(Ui.gap(c, 10));
        quick.addView(Ui.dim(c, "横向衰减:" + AutoTune.decayText(ps)));
        quick.addView(Ui.gap(c, 12));
        TextView preview = Ui.button(c, "看当前 ini 长什么样", 1);
        quick.addView(preview);
        final TextView iniBox = Ui.dim(c, "");
        iniBox.setTextIsSelectable(true);
        iniBox.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        preview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ParamSet p = ParamStore.loadCurrent(ctx);
                iniBox.setText(IniBuilder.build(p,
                        Prefs.getStr("ini_tpl", IniBuilder.DEFAULT_TEMPLATE)));
            }
        });
        quick.addView(Ui.gap(c, 10));
        quick.addView(iniBox);
        Ui.stack(page, quick);

        root = sc;
        return root;
    }

    @Override
    public void onShow() {
        if (stateBox == null) return;
        final TextView box = stateBox;
        new Thread(new Runnable() {
            @Override
            public void run() {
                final boolean root = com.feiniao.tuner.root.Shell.hasRoot();
                final boolean overlay = ScreenEngine.canOverlay(ctx);
                final boolean engine = ScreenEngine.RUNNING;
                box.post(new Runnable() {
                    @Override
                    public void run() {
                        if (box == null) return;
                        StringBuilder sb = new StringBuilder();
                        sb.append(root ? "Root:已授权" : "Root:未授权(换参 / 备份需要)").append("\n");
                        sb.append(overlay ? "悬浮窗:已允许" : "悬浮窗:未允许(实时识别需要)").append("\n");
                        sb.append(engine ? "识别引擎:运行中" : "识别引擎:未启动");
                        box.setText(sb.toString());
                        box.setTextColor(root ? Ui.TEXT_SUB : Ui.AMBER);
                    }
                });
            }
        }).start();
    }

    private View step(Context c, String no, String title, String desc) {
        LinearLayout row = Ui.row(c);
        row.setGravity(android.view.Gravity.TOP);
        TextView n = Ui.text(c, no, 13f, Ui.ON_PRIMARY, true);
        n.setGravity(android.view.Gravity.CENTER);
        int s = Ui.dp(c, 22);
        n.setLayoutParams(new LinearLayout.LayoutParams(s, s));
        n.setBackground(Ui.round(Ui.PRIMARY, 11f, c));
        LinearLayout col = Ui.col(c);
        col.addView(Ui.text(c, title, 14f, Ui.TEXT, true));
        col.addView(Ui.gap(c, 3));
        col.addView(Ui.text(c, desc, 12.5f, Ui.TEXT_DIM, false));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.leftMargin = Ui.dp(c, 10);
        LinearLayout.LayoutParams wrap = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        wrap.bottomMargin = Ui.dp(c, 14);
        row.setLayoutParams(wrap);
        row.addView(n);
        row.addView(col, lp);
        return row;
    }

    private void addW(LinearLayout parent, View v, float weight, int rightMarginDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, weight);
        lp.rightMargin = Ui.dp(ctx, rightMarginDp);
        parent.addView(v, lp);
    }
}

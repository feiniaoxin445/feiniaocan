package com.feiniao.tuner.page;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.feiniao.tuner.Prefs;
import com.feiniao.tuner.Ui;
import com.feiniao.tuner.core.Analysis;
import com.feiniao.tuner.core.AutoTune;
import com.feiniao.tuner.core.IniBuilder;
import com.feiniao.tuner.core.Physics;
import com.feiniao.tuner.core.Reports;
import com.feiniao.tuner.core.Strategy;
import com.feiniao.tuner.core.Thinker;
import com.feiniao.tuner.core.WeaponPreset;
import com.feiniao.tuner.model.ParamSet;
import com.feiniao.tuner.model.ParamStore;
import com.feiniao.tuner.model.Segment;

import java.io.File;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

/**
 * 思路调参 —— 把「你怎么想」直接变成参数表。
 *
 *   ① 写 / 贴一段思路(人话),引擎解析成口径
 *   ② 按口径把整张表铺出来
 *   ③ 智能推演:结合实测视频数据 + 结构体检,逐段给出改动、理由和把握度
 *   ④ 思路库:常写的那几套存起来,下次一键调出来
 */
public class StrategyPage extends Page {

    private static final Charset UTF8 = Charset.forName("UTF-8");

    private ParamSet ps;
    private EditText box;
    private TextView statusLine, briefOut, diagOut, pvOut, reportState, libLine;
    private Strategy.Brief brief;
    private Thinker.Diag diag;
    private int minConf = 80;

    private static final String SAMPLE =
            "猎枪打法,150 米到 600 米,每 25 米一档,小距离 5 米;"
          + "目标一般打顶飞 19 档偶尔 20 档,140 米开始下坠还是要补;"
          + "提前量整体加 10%,弹速往下压一点;"
          + "这季斜向交火多,视角偏个 12 度,预判按斜向补一下。";

    @Override
    public String title() {
        return "思路调参";
    }

    @Override
    public View build(Context c, Host host) {
        this.ctx = c;
        this.host = host;
        ps = ParamStore.loadCurrent(c);
        minConf = Prefs.getI("think_conf", 80);

        LinearLayout page = Ui.page(c);
        ScrollView sc = Ui.scroll(c);
        sc.addView(page);

        Ui.stack(page, Ui.body(c,
                "这一页是给「心里有套打法,懒得一格一格抠」用的:把你对这把枪的理解写成一段人话,"
                        + "引擎先把话拆成口径(武器 / 距离区间 / 间隔 / 小距离 / 速度档 / 弹速取向 / 提前量 / 下坠 / "
                        + "横向衰减 / 视角偏移),再按这套口径把整张表铺出来;"
                        + "配合跑过的视频数据,还能逐段推演该改哪几处、为什么改、把握度多少。"));

        /* ================= ① 写思路 ================= */
        LinearLayout c1 = Ui.card(c);
        c1.addView(Ui.h2(c, "① 写思路 / 贴思路"));
        c1.addView(Ui.gap(c, 6));
        c1.addView(Ui.dim(c, "想到什么写什么,不用讲格式。能识别的说法:武器(猎枪/左轮/通用)、"
                + "距离(150到600米)、每 25 米一档、小距离 5 米、打顶飞 19 档、"
                + "弹速往上提/往下压、提前量加 10%、140 米起下坠、横向衰减加大、视角偏移 12 度。"));
        c1.addView(Ui.gap(c, 10));

        box = multi(c, "例:猎枪,150 到 600 米,每 25 米一档,小距离 5 米,目标打顶飞 19 档,"
                + "提前量整体加 10%,140 米起下坠,斜向交火多按 12 度补视角", 7);
        box.setText(Prefs.getStr("strategy_text", ""));
        c1.addView(box);
        c1.addView(Ui.gap(c, 10));

        LinearLayout row1 = Ui.row(c);
        TextView parseBtn = Ui.button(c, "解析思路", 0);
        TextView sampleBtn = Ui.button(c, "填个示例", 2);
        TextView clearBtn = Ui.button(c, "清空", 4);
        addWeight(row1, parseBtn, 1.2f, 8);
        addWeight(row1, sampleBtn, 1f, 8);
        addWeight(row1, clearBtn, 0.7f, 0);
        c1.addView(row1);
        c1.addView(Ui.gap(c, 10));
        statusLine = Ui.dim(c, "写下思路 → 解析 → 铺表,三步。");
        c1.addView(statusLine);
        Ui.stack(page, c1);

        /* ================= ② 解析结果 ================= */
        LinearLayout c2 = Ui.card(c);
        c2.addView(Ui.h2(c, "② 解析结果"));
        c2.addView(Ui.gap(c, 8));
        briefOut = Ui.body(c, "还没解析。");
        c2.addView(briefOut);
        c2.addView(Ui.gap(c, 12));

        LinearLayout row2 = Ui.row(c);
        TextView planBtn = Ui.button(c, "按思路铺整张表", 0);
        TextView envBtn = Ui.button(c, "只落全局项", 2);
        addWeight(row2, planBtn, 1.4f, 8);
        addWeight(row2, envBtn, 1f, 0);
        c2.addView(row2);
        c2.addView(Ui.gap(c, 8));
        c2.addView(Ui.dim(c, "「铺整张表」会按解析出的口径重算每一档的距离 / 人物速度 / 子弹速度 / "
                + "预判 / 横向衰减 / 小距离,原有分段会被替换掉;「只落全局项」只改武器、参考弹速、"
                + "身位当量、速度换算,表不动。"));
        Ui.stack(page, c2);

        /* ================= ③ 智能推演 ================= */
        LinearLayout c3 = Ui.card(c);
        c3.addView(Ui.h2(c, "③ 智能推演 · 改哪几处、为什么"));
        c3.addView(Ui.gap(c, 8));
        reportState = Ui.dim(c, Reports.status());
        c3.addView(reportState);
        c3.addView(Ui.gap(c, 12));

        TextView thinkBtn = Ui.button(c, "开始推演", 0);
        c3.addView(thinkBtn);
        c3.addView(Ui.gap(c, 10));

        LinearLayout row3 = Ui.row(c);
        TextView applyHi = Ui.button(c, "套用高把握(80+)", 1);
        TextView applyAll = Ui.button(c, "套用全部(60+)", 2);
        addWeight(row3, applyHi, 1.3f, 8);
        addWeight(row3, applyAll, 1f, 0);
        c3.addView(row3);
        c3.addView(Ui.gap(c, 8));

        LinearLayout row4 = Ui.row(c);
        TextView decayBtn = Ui.button(c, "只修横向衰减", 2);
        TextView smoothBtn = Ui.button(c, "拉平预判曲线", 2);
        addWeight(row4, decayBtn, 1f, 8);
        addWeight(row4, smoothBtn, 1f, 0);
        c3.addView(row4);
        c3.addView(Ui.gap(c, 8));
        c3.addView(Ui.dim(c, "把握度口径:实测样本给的 88+、结构问题(衰减档位/曲线倒挂)80、"
                + "纯理论推算 62。样本越多把握度越高。"));
        c3.addView(Ui.gap(c, 10));
        diagOut = Ui.body(c, "还没推演。");
        c3.addView(diagOut);
        Ui.stack(page, c3);

        /* ================= ④ 思路库 ================= */
        LinearLayout c4 = Ui.card(c);
        c4.addView(Ui.h2(c, "④ 思路库"));
        c4.addView(Ui.gap(c, 8));
        c4.addView(Ui.dim(c, "常写的那几套思路存起来,换枪的时候一键调出来改两个词就能用。"));
        c4.addView(Ui.gap(c, 10));

        LinearLayout row5 = Ui.row(c);
        TextView saveBtn = Ui.button(c, "存这套思路", 2);
        TextView loadBtn = Ui.button(c, "调出来", 2);
        addWeight(row5, saveBtn, 1f, 8);
        addWeight(row5, loadBtn, 1f, 0);
        c4.addView(row5);
        c4.addView(Ui.gap(c, 10));
        libLine = Ui.dim(c, "");
        c4.addView(libLine);
        Ui.stack(page, c4);

        /* ================= ⑤ 当前表速览 ================= */
        LinearLayout c5 = Ui.card(c);
        c5.addView(Ui.h2(c, "⑤ 当前参数表"));
        c5.addView(Ui.gap(c, 8));
        pvOut = Ui.body(c, "");
        c5.addView(pvOut);
        Ui.stack(page, c5);

        /* ================= 事件 ================= */
        parseBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { doParse(true); }
        });
        sampleBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { box.setText(SAMPLE); doParse(true); }
        });
        clearBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                box.setText("");
                brief = null;
                briefOut.setText("还没解析。");
                statusLine.setText("已清空。");
            }
        });
        planBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { doPlan(); }
        });
        envBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { doEnv(); }
        });
        thinkBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { doThink(); }
        });
        applyHi.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { doApply(80); }
        });
        applyAll.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { doApply(60); }
        });
        decayBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                int n = Thinker.decayOnly(ps);
                ParamStore.saveCurrent(ctx, ps);
                refresh("横向衰减重算完成 · 改了 " + n + " 处");
            }
        });
        smoothBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                int n = Thinker.smooth(ps);
                ParamStore.saveCurrent(ctx, ps);
                refresh("预判曲线拉平 · 修了 " + n + " 处倒挂");
            }
        });
        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { saveLib(); }
        });
        loadBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { loadLib(); }
        });

        refresh("写下思路 → 解析 → 铺表,三步。");
        return sc;
    }

    @Override
    public void onShow() {
        ps = ParamStore.loadCurrent(ctx);
        if (reportState != null) reportState.setText(Reports.status());
        refresh(null);
    }

    /* ==================== 动作 ==================== */

    private void doParse(boolean echo) {
        String txt = box.getText().toString();
        Prefs.setStr("strategy_text", txt);
        brief = Strategy.parse(txt, ps);
        briefOut.setText(Strategy.summary(brief));
        if (echo) {
            statusLine.setText(brief.empty()
                    ? "没读到口径项 —— 换个说法再试,或点「填个示例」。"
                    : "解析完成 · 识别 " + brief.hits.size() + " 项 · 把握度 " + brief.confidence + "%");
        }
    }

    private void doPlan() {
        if (brief == null) doParse(false);
        if (brief == null || brief.empty()) { toast("先把思路解析出来"); return; }
        Strategy.applyEnv(brief, ps);
        WeaponPreset w = WeaponPreset.byId(ps.weapon);
        List<Segment> segs = Strategy.plan(brief, ps, w);
        if (segs.isEmpty()) { toast("没铺出分段,检查一下距离区间"); return; }
        AutoTune.apply(ps, segs);
        ps.versionTag = WeaponPreset.VERSION;
        ParamStore.saveCurrent(ctx, ps);
        refresh("按思路铺表完成 · " + segs.size() + " 档 · 武器 "
                + w.name + " · 小距离 " + Strategy.trim(brief.sub) + "m");
    }

    private void doEnv() {
        if (brief == null) doParse(false);
        if (brief == null || brief.empty()) { toast("先把思路解析出来"); return; }
        Strategy.applyEnv(brief, ps);
        ParamStore.saveCurrent(ctx, ps);
        refresh("全局项已落表(表没动)");
    }

    private void doThink() {
        if (brief == null || brief.empty()) doParse(false);
        boolean slot = Prefs.getB("use_slot_gap", true);
        diag = Thinker.think(ps, WeaponPreset.byId(ps.weapon), slot, Reports.last, brief);
        diagOut.setText(Thinker.text(diag, minConf));
        statusLine.setText("推演完成 · " + diag.items.size() + " 条改动建议");
    }

    private void doApply(int conf) {
        if (diag == null) { toast("先推演一次"); return; }
        minConf = conf;
        Prefs.setI("think_conf", conf);
        int n = Thinker.apply(ps, diag, conf);
        ParamStore.saveCurrent(ctx, ps);
        diagOut.setText(Thinker.text(diag, conf));
        refresh("套用完成 · 改了 " + n + " 处(门槛 " + conf + "+)");
    }

    /* ==================== 思路库 ==================== */

    private File libDir() {
        File d = new File(ctx.getFilesDir(), "strategies");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    private void saveLib() {
        final String txt = box.getText().toString().trim();
        if (txt.isEmpty()) { toast("先写点东西再存"); return; }
        final EditText name = Ui.input(ctx, "给这套思路起个名字,比如 猎枪·斜向");
        LinearLayout wrap = Ui.col(ctx);
        int p = Ui.dp(ctx, 16);
        wrap.setPadding(p, Ui.dp(ctx, 8), p, 0);
        wrap.addView(name);
        new AlertDialog.Builder(ctx, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("存进思路库")
                .setView(wrap)
                .setPositiveButton("保存", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        String n = name.getText().toString().trim();
                        if (n.isEmpty()) n = "思路" + System.currentTimeMillis() % 10000;
                        n = n.replace("/", "_").replace("\\", "_");
                        try {
                            ParamStore.writeText(new File(libDir(), n + ".txt"), txt);
                            toast("已存:" + n);
                        } catch (Throwable t) {
                            toast("存失败,换个名字试试");
                        }
                        refreshLib();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void loadLib() {
        final File[] fs = libDir().listFiles();
        final List<File> items = new ArrayList<File>();
        if (fs != null) {
            for (File f : fs) {
                if (f != null && f.isFile() && f.getName().endsWith(".txt")) items.add(f);
            }
        }
        if (items.isEmpty()) { toast("思路库是空的,先存一套"); return; }
        final String[] names = new String[items.size()];
        for (int i = 0; i < items.size(); i++) {
            names[i] = items.get(i).getName().replace(".txt", "");
        }
        new AlertDialog.Builder(ctx, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("调出思路")
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        try {
                            String s = ParamStore.readText(items.get(which));
                            box.setText(s);
                            doParse(true);
                        } catch (Throwable t) {
                            toast("读不出来,文件可能被删了");
                        }
                    }
                })
                .setNeutralButton("删掉一套", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { deleteLib(names, items); }
                })
                .setNegativeButton("关闭", null)
                .show();
    }

    private void deleteLib(final String[] names, final List<File> items) {
        new AlertDialog.Builder(ctx, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("删掉哪套")
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        boolean ok = items.get(which).delete();
                        toast(ok ? "已删:" + names[which] : "删不掉");
                        refreshLib();
                    }
                })
                .setNegativeButton("返回", null)
                .show();
    }

    private void refreshLib() {
        if (libLine == null) return;
        File[] fs = libDir().listFiles();
        int n = 0;
        StringBuilder sb = new StringBuilder();
        if (fs != null) {
            for (File f : fs) {
                if (f == null || !f.isFile() || !f.getName().endsWith(".txt")) continue;
                if (n > 0) sb.append(" · ");
                sb.append(f.getName().replace(".txt", ""));
                n++;
            }
        }
        libLine.setText(n == 0 ? "思路库空的。" : "库里 " + n + " 套:" + sb.toString());
    }

    /* ==================== 刷新 ==================== */

    private void refresh(String msg) {
        if (ps == null) ps = ParamStore.loadCurrent(ctx);
        if (msg != null) statusLine.setText(msg);
        refreshLib();

        if (ps.segments.isEmpty()) {
            pvOut.setText("当前表是空的,先在「参数」页铺一张,或者直接按思路铺表。");
            return;
        }
        ps.sortByDistance();
        Segment lo = ps.segments.get(0);
        Segment hi = ps.segments.get(ps.segments.size() - 1);
        int subCount = 0;
        for (Segment s : ps.segments) if (s.sub > 0f) subCount++;
        int bytes = AutoTune.iniSize(ps, Prefs.getStr("ini_tpl", IniBuilder.DEFAULT_TEMPLATE));

        StringBuilder sb = new StringBuilder();
        sb.append("武器 ").append(WeaponPreset.byId(ps.weapon).name)
                .append(" · 口径 ").append(ps.versionTag).append("\n")
                .append("分段 ").append(ps.segments.size()).append(" 档,共 ")
                .append(Segment.trim(lo.distance)).append("~").append(Segment.trim(hi.distance))
                .append("m,总距离 ").append(Segment.trim(ps.totalDistance)).append("m\n")
                .append("身位当量 ").append(Segment.trim(ps.bodyWidth)).append("m · 参考弹速 ")
                .append(Segment.trim(ps.bulletRef)).append(" m/s · 速度换算 ")
                .append(Segment.trim(ps.speedScale)).append("\n")
                .append("小距离已设 ").append(subCount).append("/").append(ps.segments.size())
                .append(" 档 · 参数内存 ").append(AutoTune.sizeText(bytes)).append("\n")
                .append("横向衰减:").append(AutoTune.decayText(ps));

        if (Reports.last != null && Reports.last.angleSamples > 0) {
            sb.append("\n镜头角度均值 ").append(Physics.fmt(Reports.last.angleAvgDeg, 1))
                    .append("° · 斜向系数 ").append(Physics.fmt(Reports.last.slantAvg, 2))
                    .append(" → 预判建议 ×")
                    .append(Physics.fmt(Strategy.angleFactor(Reports.last.angleAvgDeg), 3));
        }

        pvOut.setText(sb.toString());
        if (reportState != null) reportState.setText(Reports.status());
    }

    /* ==================== 小工具 ==================== */

    private EditText multi(Context c, String hint, int lines) {
        EditText e = Ui.input(c, hint);
        e.setSingleLine(false);
        e.setMinLines(lines);
        e.setGravity(Gravity.TOP | Gravity.START);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        e.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return e;
    }

    private static void addWeight(LinearLayout row, View v, float weight, int rightMarginDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, weight);
        lp.rightMargin = Ui.dp(row.getContext(), rightMarginDp);
        v.setLayoutParams(lp);
        row.addView(v);
    }
}

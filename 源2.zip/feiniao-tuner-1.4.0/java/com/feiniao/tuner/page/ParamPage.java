package com.feiniao.tuner.page;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.feiniao.tuner.Ui;
import com.feiniao.tuner.core.AutoTune;
import com.feiniao.tuner.core.IniBuilder;
import com.feiniao.tuner.core.Physics;
import com.feiniao.tuner.core.WeaponPreset;
import com.feiniao.tuner.model.ParamSet;
import com.feiniao.tuner.model.ParamStore;
import com.feiniao.tuner.model.Segment;
import com.feiniao.tuner.root.ParamReplacer;
import com.feiniao.tuner.util.Saf;

import java.io.File;
import java.util.List;

/** 参数与预判表 */
public class ParamPage extends Page {

    private static final int REQ_IMPORT = 2101;
    private static final int REQ_EXPORT = 2102;

    private ParamSet ps;
    private LinearLayout tableBox;
    private LinearLayout presetBox;
    private TextView tableHead;
    private EditText fName, fTotal, fBody, fScale, fBullet, fPpm;

    /* 自动生成参数 */
    private EditText fGenFrom, fGenTo, fGenStep, fGenSpeed, fGenBullet;
    private TextView genInfo, genTip;
    private String weaponId;
    private boolean useSlotGap;

    @Override
    public String title() {
        return "参数与预判表";
    }

    @Override
    public View build(Context c, Host host) {
        this.ctx = c;
        this.host = host;
        ps = ParamStore.loadCurrent(c);
        weaponId = Prefs.getStr("weapon_id",
                ps.weapon != null ? ps.weapon : WeaponPreset.ID_REVOLVER);
        useSlotGap = Prefs.getB("use_slot_gap", true);

        LinearLayout page = Ui.page(c);
        ScrollView sc = Ui.scroll(c);
        sc.addView(page);

        /* ---------- 概览 ---------- */
        TextView intro = Ui.body(c, "这里管的是整套弹道参数。总距离、身位当量、速度换算决定了每一段的预判是怎么算出来的,"
                + "预判表逐段列给你看,并实时给出理论值对比。");
        Ui.stack(page, intro);

        LinearLayout card = Ui.card(c);
        TextView t1 = Ui.h2(c, "方案概览");
        card.addView(t1);
        card.addView(Ui.gap(c, 10));

        fName = Ui.input(c, "方案名");
        card.addView(Ui.field(c, "方案名", fName));
        card.addView(Ui.gap(c, 8));

        fTotal = num();
        fBody = num();
        fScale = num();
        fBullet = num();
        fPpm = num();

        card.addView(Ui.field(c, "总距离 (米)", fTotal));
        card.addView(Ui.gap(c, 8));
        card.addView(Ui.field(c, "一个身位 (米)", fBody));
        card.addView(Ui.gap(c, 8));
        card.addView(Ui.field(c, "速度换算 (米/秒)", fScale));
        card.addView(Ui.gap(c, 8));
        card.addView(Ui.field(c, "参考子弹速度", fBullet));
        card.addView(Ui.gap(c, 8));
        card.addView(Ui.field(c, "像素当量 px/m", fPpm));
        card.addView(Ui.gap(c, 4));
        card.addView(Ui.dim(c, "像素当量填 0 = 由弹道飞行时间自动反推距离。"));
        card.addView(Ui.gap(c, 12));

        LinearLayout btns = Ui.row(c);
        TextView save = Ui.button(c, "保存方案", 0);
        TextView reset = Ui.button(c, "重置默认", 2);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        bp.rightMargin = Ui.dp(c, 8);
        save.setLayoutParams(bp);
        reset.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        btns.addView(save);
        btns.addView(reset);
        card.addView(btns);

        save.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { applyGlobals(); toast("方案已保存"); }
        });
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(ctx, android.R.style.Theme_Material_Dialog_Alert)
                        .setTitle("重置为默认?")
                        .setMessage("当前所有分段参数会被默认值覆盖,原方案建议先另存为预设。")
                        .setPositiveButton("重置", (d, w) -> {
                            ps = ParamSet.defaults();
                            fillGlobals();
                            save();
                        })
                        .setNegativeButton("算了", null)
                        .show();
            }
        });

        Ui.stack(page, card);

        /* ---------- 自动生成参数 ---------- */
        LinearLayout gen = Ui.card(c);
        gen.addView(Ui.h2(c, "自动生成参数"));
        gen.addView(Ui.gap(c, 6));
        gen.addView(Ui.dim(c, "距离自己填 —— 起始、结束、每档间隔随你改;人物速度也能调。"
                + "19 / 20 就是打顶飞那两档,只有这两档才给横向衰减。"
                + "选好武器思路,一键把整张预判表铺出来。"));
        gen.addView(Ui.gap(c, 12));

        fGenFrom = num();
        fGenTo = num();
        fGenStep = num();
        fGenSpeed = num();
        fGenBullet = num();
        fGenFrom.setText(Segment.trim(Prefs.getF("gen_from", 50f)));
        fGenTo.setText(Segment.trim(Prefs.getF("gen_to", 400f)));
        fGenStep.setText(Segment.trim(Prefs.getF("gen_step", 50f)));
        fGenSpeed.setText(Segment.trim(Prefs.getF("gen_speed", 20f)));
        fGenBullet.setText(Segment.trim(Prefs.getF("gen_bullet", ps.bulletRef)));

        gen.addView(Ui.field(c, "起始距离 (米)", fGenFrom));
        gen.addView(Ui.gap(c, 8));
        gen.addView(Ui.field(c, "结束距离 (米)", fGenTo));
        gen.addView(Ui.gap(c, 8));
        gen.addView(Ui.field(c, "每档间隔 (米)", fGenStep));
        gen.addView(Ui.gap(c, 8));
        gen.addView(Ui.field(c, "人物速度", fGenSpeed));
        gen.addView(Ui.gap(c, 8));
        gen.addView(Ui.field(c, "基准子弹速度", fGenBullet));
        gen.addView(Ui.gap(c, 6));
        gen.addView(Ui.dim(c, "人物速度 19 / 20 = 打顶飞档,横向衰减只给这两档,其余档位留 0。"
                + "基准弹速填方案的参考弹速就行,武器思路会在这个基准上压。"));
        gen.addView(Ui.gap(c, 12));

        gen.addView(Ui.text(c, "武器调参思路", 13f, Ui.PRIMARY, true));
        gen.addView(Ui.gap(c, 8));

        final WeaponPreset[] wps = WeaponPreset.all();
        final TextView[] wc = new TextView[wps.length];
        LinearLayout wrow = Ui.row(c);
        for (int i = 0; i < wps.length; i++) {
            final WeaponPreset wp = wps[i];
            TextView chip = Ui.chip(c, wp.name, wp.id.equals(weaponId));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.rightMargin = Ui.dp(c, 8);
            chip.setLayoutParams(lp);
            chip.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    weaponId = wp.id;
                    ps.weapon = weaponId;
                    Prefs.setStr("weapon_id", weaponId);
                    for (int k = 0; k < wc.length; k++) {
                        boolean on = wps[k].id.equals(weaponId);
                        wc[k].setBackground(on ? Ui.pressable(Ui.PRIMARY, Ui.R_PILL, ctx)
                                : Ui.pressable(Ui.SURFACE_2, Ui.R_PILL, ctx));
                        wc[k].setTextColor(on ? Ui.ON_PRIMARY : Ui.TEXT_SUB);
                    }
                    genTip.setText(wp.idea);
                }
            });
            wc[i] = chip;
            wrow.addView(chip);
        }
        gen.addView(wrow);
        gen.addView(Ui.gap(c, 10));

        genTip = Ui.dim(c, WeaponPreset.byId(weaponId).idea);
        gen.addView(genTip);
        gen.addView(Ui.gap(c, 10));

        LinearLayout spRow = Ui.row(c);
        final TextView sp19 = Ui.chip(c, "打顶飞 19", false);
        final TextView sp20 = Ui.chip(c, "打顶飞 20", true);
        LinearLayout.LayoutParams spl = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        spl.rightMargin = Ui.dp(c, 8);
        sp19.setLayoutParams(spl);
        sp20.setLayoutParams(spl);
        View.OnClickListener spe = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean is19 = v == sp19;
                fGenSpeed.setText(is19 ? "19" : "20");
                sp19.setBackground(Ui.pressable(is19 ? Ui.PRIMARY : Ui.SURFACE_2, Ui.R_PILL, ctx));
                sp19.setTextColor(is19 ? Ui.ON_PRIMARY : Ui.TEXT_SUB);
                sp20.setBackground(Ui.pressable(!is19 ? Ui.PRIMARY : Ui.SURFACE_2, Ui.R_PILL, ctx));
                sp20.setTextColor(!is19 ? Ui.ON_PRIMARY : Ui.TEXT_SUB);
            }
        };
        sp19.setOnClickListener(spe);
        sp20.setOnClickListener(spe);
        spRow.addView(sp19);
        spRow.addView(sp20);
        gen.addView(spRow);
        gen.addView(Ui.gap(c, 12));

        LinearLayout gb = Ui.row(c);
        TextView doGen = Ui.button(c, "生成参数表", 0);
        TextView doTheory = Ui.button(c, "一键调节 · 理论对齐", 1);
        addWeight(gb, doGen, 1f, 8);
        addWeight(gb, doTheory, 1.35f, 0);
        gen.addView(gb);
        gen.addView(Ui.gap(c, 10));

        genInfo = Ui.dim(c, "");
        gen.addView(genInfo);

        doGen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveGen();
                applyGlobals();
                WeaponPreset w = WeaponPreset.byId(weaponId);
                List<Segment> segs = AutoTune.generate(numOf(fGenBullet, ps.bulletRef),
                        numOf(fGenFrom, 50f), numOf(fGenTo, 400f), numOf(fGenStep, 50f),
                        numOf(fGenSpeed, 20f), w, useSlotGap, ps);
                if (segs.isEmpty()) {
                    toast("距离区间填得不对,检查一下起止和间隔");
                    return;
                }
                AutoTune.apply(ps, segs);
                ps.weapon = weaponId;
                ParamStore.saveCurrent(ctx, ps);
                fillGlobals();
                refreshAll();
                toast("已生成 " + segs.size() + " 段参数");
            }
        });

        doTheory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveGen();
                applyGlobals();
                WeaponPreset w = WeaponPreset.byId(weaponId);
                int n = AutoTune.oneKey(ps, w, useSlotGap, null, false);
                ps.weapon = weaponId;
                ParamStore.saveCurrent(ctx, ps);
                refreshAll();
                toast(n > 0 ? ("整表已按理论重算,动了 " + n + " 处") : "整表本来就对齐");
            }
        });

        Ui.stack(page, gen);

        /* ---------- 当前口径版本 ---------- */
        LinearLayout ver = Ui.card(c, 0x33C58AF9);
        ver.addView(Ui.text(c, "当前口径 · " + WeaponPreset.VERSION, 13f, Ui.PURPLE, true));
        ver.addView(Ui.gap(c, 6));
        ver.addView(Ui.dim(c, WeaponPreset.VERSION_NOTE));
        Ui.stack(page, ver);

        /* ---------- 方案库 ---------- */
        LinearLayout lib = Ui.card(c);
        lib.addView(Ui.h2(c, "方案库"));
        lib.addView(Ui.gap(c, 6));
        lib.addView(Ui.dim(c, "预设可随时切换,换参时直接推当前工作方案的 preference.ini。"));
        lib.addView(Ui.gap(c, 10));
        presetBox = Ui.col(c);
        lib.addView(presetBox);
        lib.addView(Ui.gap(c, 12));

        LinearLayout libBtns = Ui.row(c);
        TextView saveAs = Ui.button(c, "另存为预设", 1);
        TextView imp = Ui.button(c, "导入 json", 2);
        TextView exp = Ui.button(c, "导出 json", 2);
        addWeight(libBtns, saveAs, 1.1f, 8);
        addWeight(libBtns, imp, 1f, 8);
        addWeight(libBtns, exp, 1f, 0);
        lib.addView(libBtns);

        saveAs.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { dialogSaveAs(); }
        });
        imp.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                host.pickDocument(REQ_IMPORT, "application/json", "选择参数 json", ParamPage.this);
            }
        });
        exp.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                applyGlobals();
                host.pickCreate(REQ_EXPORT, "application/json",
                        ps.name + ".json", ParamPage.this);
            }
        });

        Ui.stack(page, lib);

        /* ---------- 预判表 ---------- */
        LinearLayout table = Ui.card(c);
        table.addView(Ui.h2(c, "预判表"));
        table.addView(Ui.gap(c, 6));
        tableHead = Ui.dim(c, "");
        table.addView(tableHead);
        table.addView(Ui.gap(c, 10));
        tableBox = Ui.col(c);
        table.addView(tableBox);
        table.addView(Ui.gap(c, 12));

        LinearLayout tBtns = Ui.row(c);
        TextView addSeg = Ui.button(c, "+ 新增分段", 1);
        TextView allUp = Ui.button(c, "整体 +0.1", 2);
        TextView allDown = Ui.button(c, "整体 -0.1", 2);
        addWeight(tBtns, addSeg, 1.2f, 8);
        addWeight(tBtns, allUp, 1f, 8);
        addWeight(tBtns, allDown, 1f, 0);
        table.addView(tBtns);

        addSeg.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { dialogAddSegment(); }
        });
        allUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (Segment s : ps.segments) s.predict = Math.max(0, s.predict + 0.1f);
                save();
                toast("全段 +0.1 身位");
            }
        });
        allDown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (Segment s : ps.segments) s.predict = Math.max(0, s.predict - 0.1f);
                save();
                toast("全段 -0.1 身位");
            }
        });

        Ui.stack(page, table);
        Ui.stack(page, Ui.dim(c, "提示:预判按 0.1 身位为最小步进。+1 就是一个身位,"
                + "-1 就是减一个身位,+0.1 是十分之一个身位。"
                + "横向衰减只有人物速度 19 / 20(打顶飞)那两档才需要给值。"));

        root = sc;
        fillGlobals();
        refreshAll();
        return root;
    }

    @Override
    public void onShow() {
        if (root == null) return;
        ps = ParamStore.loadCurrent(ctx);
        fillGlobals();
        refreshAll();
    }

    /* ---------------- 数据同步 ---------------- */

    private void applyGlobals() {
        ps.name = text(fName, ps.name);
        ps.totalDistance = numOf(fTotal, ps.totalDistance);
        ps.bodyWidth = numOf(fBody, ps.bodyWidth);
        ps.speedScale = numOf(fScale, ps.speedScale);
        ps.bulletRef = numOf(fBullet, ps.bulletRef);
        ps.pxPerMeter = numOf(fPpm, ps.pxPerMeter);
        save();
    }

    private void fillGlobals() {
        fName.setText(ps.name);
        fTotal.setText(Segment.trim(ps.totalDistance));
        fBody.setText(Segment.trim(ps.bodyWidth));
        fScale.setText(Segment.trim(ps.speedScale));
        fBullet.setText(Segment.trim(ps.bulletRef));
        fPpm.setText(Segment.trim(ps.pxPerMeter));
    }

    private void save() {
        ps.sortByDistance();
        ParamStore.saveCurrent(ctx, ps);
        refreshAll();
    }

    private void refreshAll() {
        refreshTable();
        refreshPresets();
        refreshGenInfo();
    }

    private void saveGen() {
        Prefs.setF("gen_from", numOf(fGenFrom, 50f));
        Prefs.setF("gen_to", numOf(fGenTo, 400f));
        Prefs.setF("gen_step", numOf(fGenStep, 50f));
        Prefs.setF("gen_speed", numOf(fGenSpeed, 20f));
        Prefs.setF("gen_bullet", numOf(fGenBullet, ps.bulletRef));
        Prefs.setB("use_slot_gap", useSlotGap);
    }

    private void refreshGenInfo() {
        if (genInfo == null || ctx == null) return;
        String tpl = Prefs.getStr("ini_tpl", IniBuilder.DEFAULT_TEMPLATE);
        int bytes = AutoTune.iniSize(ps, tpl);
        genInfo.setText("当前 " + ps.segments.size() + " 段 · 总距离 "
                + Segment.trim(ps.totalDistance) + " m · 参数内存大小 " + AutoTune.sizeText(bytes)
                + "\n横向衰减:" + AutoTune.decayText(ps)
                + "\n口径版本:" + WeaponPreset.VERSION
                + " · 武器:" + WeaponPreset.byId(weaponId).name);
    }

    private void refreshPresets() {
        if (presetBox == null) return;
        presetBox.removeAllViews();
        List<String> names = ParamStore.listPresets(ctx);
        if (names.isEmpty()) {
            presetBox.addView(Ui.dim(ctx, "还没有预设。把常用方案另存为预设,一键来回切。"));
            return;
        }
        LinearLayout wrapRow = null;
        int perRow = 3;
        for (int i = 0; i < names.size(); i++) {
            if (i % perRow == 0) {
                wrapRow = Ui.row(ctx);
                wrapRow.setPadding(0, Ui.dp(ctx, 3), 0, Ui.dp(ctx, 3));
                presetBox.addView(wrapRow);
            }
            final String nm = names.get(i);
            TextView chip = Ui.chip(ctx, nm, nm.equals(ps.name));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.rightMargin = Ui.dp(ctx, 8);
            chip.setLayoutParams(lp);
            chip.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { dialogPreset(nm); }
            });
            wrapRow.addView(chip);
        }
    }

    private void refreshTable() {
        if (tableBox == null) return;
        if (tableHead != null) {
            tableHead.setText("总距离 " + Segment.trim(ps.totalDistance) + "m · 共 "
                    + ps.segments.size() + " 段 · 身位当量 " + Segment.trim(ps.bodyWidth)
                    + "m · 参考弹速 " + Segment.trim(ps.bulletRef)
                    + "\n参数内存大小 "
                    + AutoTune.sizeText(AutoTune.iniSize(ps,
                            Prefs.getStr("ini_tpl", IniBuilder.DEFAULT_TEMPLATE)))
                    + " · 口径 " + WeaponPreset.VERSION
                    + " · 武器 " + WeaponPreset.byId(weaponId).name);
        }
        tableBox.removeAllViews();

        // 表头
        LinearLayout h = Ui.row(ctx);
        h.setPadding(0, 0, 0, Ui.dp(ctx, 4));
        h.addView(cell("距离", 1f, true));
        h.addView(cell("人物速度", 1f, true));
        h.addView(cell("子弹速度", 1f, true));
        h.addView(cell("预判", 0.9f, true));
        h.addView(cell("横向衰减", 1f, true));
        tableBox.addView(h);

        for (int i = 0; i < ps.segments.size(); i++) {
            final Segment s = ps.segments.get(i);
            final int idx = i;
            tableBox.addView(divider());

            LinearLayout row = Ui.row(ctx);
            row.addView(cell(Segment.trim(s.distance) + "m", 1f, false));

            boolean tf = Physics.hitSpeedBracket(s.charSpeed);
            TextView csCell = cell(tf ? Segment.trim(s.charSpeed) + " 顶飞" : Segment.trim(s.charSpeed),
                    1f, tf);
            if (tf) csCell.setTextColor(Ui.PURPLE);
            row.addView(csCell);

            row.addView(cell(Segment.trim(s.bulletSpeed), 1f, false));
            row.addView(cell(Segment.trim(s.predict), 0.9f, true));

            TextView hdCell = cell(Segment.trim(s.hDecay), 1f, tf);
            if (tf) hdCell.setTextColor(Ui.PURPLE);
            row.addView(hdCell);
            tableBox.addView(row);

            // 理论对比
            float need = Physics.requiredPredict(ps, s);
            int v = Physics.verdict(need, s.predict);
            int col = v == 0 ? Ui.GREEN : (v > 0 ? Ui.AMBER : Ui.PRIMARY);
            LinearLayout cmp = Ui.row(ctx);
            TextView cmpT = Ui.text(ctx, "理论 " + Physics.fmt(need, 2)
                    + " 身位 · " + Physics.verdictText(v)
                    + (v == 0 ? "" : " " + Physics.fmt(Math.abs(need - s.predict), 2))
                    + (s.sub > 0f ? " · 小距离 " + Segment.trim(s.sub) + "m" : " · 小距离未设"),
                    12f, col, false);
            cmp.addView(cmpT);
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            cmpT.setLayoutParams(clp);
            cmp.setPadding(0, Ui.dp(ctx, 4), 0, Ui.dp(ctx, 6));
            tableBox.addView(cmp);

            // 操作按钮
            LinearLayout ops = Ui.row(ctx);
            ops.addView(op("+1", new Runnable() { public void run() { bump(idx, 1f); } }), w(1, 6));
            ops.addView(op("-1", new Runnable() { public void run() { bump(idx, -1f); } }), w(1, 6));
            ops.addView(op("+0.1", new Runnable() { public void run() { bump(idx, 0.1f); } }), w(1, 6));
            ops.addView(op("-0.1", new Runnable() { public void run() { bump(idx, -0.1f); } }), w(1, 6));
            ops.addView(op("理论值", new Runnable() {
                public void run() {
                    s.predict = Physics.quantize(Physics.requiredPredict(ps, s));
                    save();
                    toast("该段已套用理论值");
                }
            }), w(1, 6));
            ops.addView(op("编辑", new Runnable() { public void run() { dialogEdit(idx); } }), w(1, 6));
            ops.addView(op("删", new Runnable() { public void run() { dialogDelete(idx); } }), w(0.7f, 0));
            tableBox.addView(ops);
        }
    }

    private void bump(int idx, float delta) {
        if (idx < 0 || idx >= ps.segments.size()) return;
        Segment s = ps.segments.get(idx);
        s.predict = Math.max(0, Physics.round2(s.predict + delta));
        save();
    }

    /* ---------------- 弹窗 ---------------- */

    private void dialogEdit(final int idx) {
        final Segment s = ps.segments.get(idx);
        LinearLayout box = Ui.col(ctx);
        int p = Ui.dp(ctx, 18);
        box.setPadding(p, p, p, 0);
        final EditText d = num(), cs = num(), bs = num(), pr = num(), hd = num(), sb = num();
        d.setText(Segment.trim(s.distance));
        cs.setText(Segment.trim(s.charSpeed));
        bs.setText(Segment.trim(s.bulletSpeed));
        pr.setText(Segment.trim(s.predict));
        hd.setText(Segment.trim(s.hDecay));
        sb.setText(Segment.trim(s.sub));

        box.addView(Ui.field(ctx, "距离 (米)", d));
        box.addView(Ui.gap(ctx, 8));
        box.addView(Ui.field(ctx, "人物速度", cs));
        box.addView(Ui.gap(ctx, 8));
        box.addView(Ui.field(ctx, "子弹速度", bs));
        box.addView(Ui.gap(ctx, 8));
        box.addView(Ui.field(ctx, "预判 (身位)", pr));
        box.addView(Ui.gap(ctx, 8));
        box.addView(Ui.field(ctx, "横向衰减", hd));
        box.addView(Ui.gap(ctx, 8));
        box.addView(Ui.field(ctx, "小距离 (米)", sb));
        box.addView(Ui.gap(ctx, 4));
        box.addView(Ui.dim(ctx, "小距离 = 这一档内部的微调步长,填 5 就是这个距离附近按 5 米一档抠;"
                + "填 0 = 不设。"));
        box.addView(Ui.gap(ctx, 12));

        LinearLayout quick = Ui.row(ctx);
        quick.addView(op("预判 +1", new Runnable() {
            public void run() { setNum(pr, numOf(pr, 0) + 1f); }
        }), w(1, 8));
        quick.addView(op("预判 -1", new Runnable() {
            public void run() { setNum(pr, Math.max(0, numOf(pr, 0) - 1f)); }
        }), w(1, 8));
        quick.addView(op("预判 +0.1", new Runnable() {
            public void run() { setNum(pr, numOf(pr, 0) + 0.1f); }
        }), w(1, 0));
        box.addView(quick);

        new AlertDialog.Builder(ctx, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("编辑第 " + (idx + 1) + " 段")
                .setView(box)
                .setPositiveButton("保存", (dg, w) -> {
                    s.distance = numOf(d, s.distance);
                    s.charSpeed = numOf(cs, s.charSpeed);
                    s.bulletSpeed = numOf(bs, s.bulletSpeed);
                    s.predict = Math.max(0, numOf(pr, s.predict));
                    s.hDecay = numOf(hd, s.hDecay);
                    s.sub = Math.max(0, numOf(sb, s.sub));
                    save();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void dialogAddSegment() {
        Segment last = ps.segments.isEmpty() ? null : ps.segments.get(ps.segments.size() - 1);
        float nd = last != null ? last.distance + 50f : 50f;
        float nbs = last != null ? Math.max(200f, last.bulletSpeed - 10f) : 780f;
        Segment s = new Segment(nd, 19f, nbs, 0.5f, 0f, last != null ? last.sub : 0f);
        ps.segments.add(s);
        save();
        dialogEdit(ps.segments.size() - 1);
    }

    private void dialogDelete(final int idx) {
        new AlertDialog.Builder(ctx, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("删除该分段?")
                .setMessage("第 " + (idx + 1) + " 段 将被移除,不影响其它分段。")
                .setPositiveButton("删除", (d, w) -> {
                    if (idx >= 0 && idx < ps.segments.size()) ps.segments.remove(idx);
                    save();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void dialogSaveAs() {
        final EditText e = Ui.input(ctx, "预设名,例如 夏季赛 M4");
        LinearLayout box = Ui.col(ctx);
        int p = Ui.dp(ctx, 18);
        box.setPadding(p, p, p, 0);
        box.addView(e);
        new AlertDialog.Builder(ctx, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("另存为预设")
                .setView(box)
                .setPositiveButton("保存", (d, w) -> {
                    applyGlobals();
                    String n = e.getText().toString().trim();
                    if (n.isEmpty()) n = "预设" + System.currentTimeMillis() % 10000;
                    ParamStore.savePreset(ctx, n, ps);
                    ps.name = n;
                    ParamStore.saveCurrent(ctx, ps);
                    fillGlobals();
                    refreshAll();
                    toast("已存为预设:" + n);
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void dialogPreset(final String name) {
        new AlertDialog.Builder(ctx, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle(name)
                .setItems(new String[]{"载入为当前方案", "删除该预设"}, (d, w) -> {
                    if (w == 0) {
                        ParamSet p = ParamStore.loadPreset(ctx, name);
                        if (p == null) { toast("该预设读不出来"); return; }
                        ps = p;
                        ps.name = name;
                        ParamStore.saveCurrent(ctx, ps);
                        fillGlobals();
                        refreshAll();
                        toast("已载入:" + name);
                    } else {
                        ParamStore.deletePreset(ctx, name);
                        refreshAll();
                        toast("已删除:" + name);
                    }
                })
                .show();
    }

    /* ---------------- 导入导出 ---------------- */

    @Override
    public void onResult(int req, int result, Intent data) {
        if (result != android.app.Activity.RESULT_OK || data == null || data.getData() == null) return;
        if (req == REQ_IMPORT) {
            try {
                String txt = Saf.readText(ctx, data.getData(), 4 * 1024 * 1024);
                ParamSet p = ParamStore.fromJsonText(txt);
                if (p == null) { toast("这个文件不是有效的参数 json"); return; }
                ps = p;
                ParamStore.saveCurrent(ctx, ps);
                fillGlobals();
                refreshAll();
                toast("导入成功:" + ps.segments.size() + " 段");
            } catch (Throwable t) {
                toast("导入失败");
            }
        } else if (req == REQ_EXPORT) {
            try {
                java.io.OutputStream os = ctx.getContentResolver().openOutputStream(data.getData());
                if (os == null) { toast("导出失败"); return; }
                os.write(ParamStore.toJsonText(ps).getBytes("UTF-8"));
                os.flush();
                os.close();
                toast("已导出");
            } catch (Throwable t) {
                toast("导出失败");
            }
        }
    }

    /* ---------------- 小工具 ---------------- */

    private EditText num() {
        EditText e = Ui.numInput(ctx, "");
        e.setTextSize(14f);
        return e;
    }

    private TextView cell(String s, float weight, boolean strong) {
        TextView t = Ui.text(ctx, s, 12f, strong ? Ui.TEXT : Ui.TEXT_SUB, strong);
        t.setGravity(Gravity.CENTER);
        t.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, weight));
        return t;
    }

    private TextView op(String label, final Runnable r) {
        TextView t = Ui.text(ctx, label, 12.5f, Ui.PRIMARY, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(Ui.dp(ctx, 6), Ui.dp(ctx, 8), Ui.dp(ctx, 6), Ui.dp(ctx, 8));
        t.setBackground(Ui.pressable(Ui.PRIMARY_CONT, Ui.R_ITEM, ctx));
        t.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { r.run(); }
        });
        return t;
    }

    private LinearLayout.LayoutParams w(float weight, int rightMarginDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, weight);
        lp.rightMargin = Ui.dp(ctx, rightMarginDp);
        return lp;
    }

    private void addWeight(LinearLayout parent, View v, float weight, int rightMarginDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, weight);
        lp.rightMargin = Ui.dp(ctx, rightMarginDp);
        parent.addView(v, lp);
    }

    private View divider() {
        View v = new View(ctx);
        v.setBackgroundColor(Ui.OUTLINE_SOFT);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, Ui.dp(ctx, 0.8f)));
        lp.topMargin = Ui.dp(ctx, 8);
        lp.bottomMargin = Ui.dp(ctx, 8);
        v.setLayoutParams(lp);
        return v;
    }

    private static String text(EditText e, String def) {
        String s = e.getText().toString().trim();
        return s.isEmpty() ? def : s;
    }

    private static float numOf(EditText e, float def) {
        try {
            String s = e.getText().toString().trim();
            if (s.isEmpty()) return def;
            return Float.parseFloat(s);
        } catch (Throwable t) {
            return def;
        }
    }

    private static void setNum(EditText e, float v) {
        e.setText(Segment.trim(v));
    }
}

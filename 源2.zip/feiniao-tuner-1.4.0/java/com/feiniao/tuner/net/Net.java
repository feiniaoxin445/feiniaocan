package com.feiniao.tuner.net;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CodingErrorAction;
import java.util.zip.GZIPInputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** 直链拉取:自动处理 原始 ini / gzip / zip 三种载荷 */
public final class Net {

    public interface Progress {
        void onBytes(int read, int total);
    }

    public static class Res {
        public String text;          // 解析后的 ini 文本
        public File raw;             // 原始下载文件
        public String note = "";     // 处理说明
        public String url;
    }

    private static final int MAX_BYTES = 24 * 1024 * 1024;

    private Net() {}

    public static Res fetch(String url, File workDir, Progress cb) throws Exception {
        Res res = new Res();
        res.url = url;
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) {
            throw new IllegalArgumentException("直链要以 http:// 或 https:// 开头");
        }
        if (!workDir.exists()) workDir.mkdirs();

        HttpURLConnection conn = null;
        byte[] data;
        try {
            conn = open(url);
            int total = conn.getContentLength();
            InputStream in = conn.getInputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n, read = 0;
            while ((n = in.read(buf)) > 0) {
                bo.write(buf, 0, n);
                read += n;
                if (cb != null) cb.onBytes(read, total);
                if (read > MAX_BYTES) throw new IllegalStateException("文件过大,已中止");
            }
            try { in.close(); } catch (Throwable ignored) {}
            data = bo.toByteArray();
        } finally {
            if (conn != null) {
                try { conn.disconnect(); } catch (Throwable ignored) {}
            }
        }

        if (data.length == 0) throw new IllegalStateException("拉回来的内容是空的");

        File raw = new File(workDir, "download_" + System.currentTimeMillis() + ".bin");
        FileOutputStream fo = new FileOutputStream(raw);
        try { fo.write(data); fo.flush(); } finally { try { fo.close(); } catch (Throwable ignored) {} }
        res.raw = raw;

        if (isZip(data)) {
            String inner = null;
            ZipInputStream zis = new ZipInputStream(new ByteArrayInputStream(data));
            try {
                ZipEntry e;
                byte[] fallback = null;
                while ((e = zis.getNextEntry()) != null) {
                    if (e.isDirectory()) continue;
                    byte[] b = readAll(zis);
                    String low = e.getName().toLowerCase();
                    if (low.endsWith("preference.ini") || low.contains("preference")) {
                        inner = decode(b);
                        res.note = "从压缩包取出 " + e.getName();
                        break;
                    }
                    if (fallback == null) fallback = b;
                }
                if (inner == null && fallback != null) {
                    inner = decode(fallback);
                    res.note = "压缩包内未找到 preference.ini,已取首个文件";
                }
            } finally {
                try { zis.close(); } catch (Throwable ignored) {}
            }
            res.text = inner;
        } else if (isGzip(data)) {
            byte[] out = readAll(new GZIPInputStream(new ByteArrayInputStream(data)));
            res.text = decode(out);
            res.note = "已解压 gzip";
        } else {
            res.text = decode(data);
            res.note = "直接使用原始文本";
        }

        if (res.text != null) res.text = res.text.replace("\uFEFF", "").trim();
        if (res.text == null || res.text.isEmpty()) {
            throw new IllegalStateException("拉回来的内容不是有效的参数文本");
        }
        return res;
    }

    private static HttpURLConnection open(String url) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setInstanceFollowRedirects(true);
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(25000);
        conn.setRequestProperty("User-Agent",
                "Mozilla/5.0 (Linux; Android 13) FeiniaoTuner/1.0");
        conn.setRequestProperty("Accept", "*/*");
        conn.connect();
        int code = conn.getResponseCode();
        if (code >= 400) throw new IllegalStateException("直链返回 " + code);
        return conn;
    }

    private static boolean isZip(byte[] d) {
        return d.length > 4 && (d[0] & 0xFF) == 0x50 && (d[1] & 0xFF) == 0x4B;
    }

    private static boolean isGzip(byte[] d) {
        return d.length > 2 && (d[0] & 0xFF) == 0x1F && (d[1] & 0xFF) == 0x8B;
    }

    private static byte[] readAll(InputStream in) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] b = new byte[8192];
        int n;
        while ((n = in.read(b)) > 0) bo.write(b, 0, n);
        return bo.toByteArray();
    }

    /** UTF-8 优先,失败退 GBK */
    private static String decode(byte[] b) {
        try {
            CharsetDecoder d = Charset.forName("UTF-8").newDecoder()
                    .onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT);
            return d.decode(ByteBuffer.wrap(b)).toString();
        } catch (CharacterCodingException e) {
            try {
                return new String(b, Charset.forName("GBK"));
            } catch (Throwable t) {
                return new String(b, Charset.forName("UTF-8"));
            }
        } catch (Throwable t) {
            return new String(b, Charset.forName("UTF-8"));
        }
    }
}

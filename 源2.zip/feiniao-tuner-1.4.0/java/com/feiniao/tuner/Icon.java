package com.feiniao.tuner;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/**
 * 代码手绘图标(无资源依赖),风格对齐 KernelSU 的线性图标。
 */
public final class Icon {

    public static final int SLIDERS = 0;   // 参数
    public static final int CROSSHAIR = 1; // 调参
    public static final int SWAP = 2;      // 换参
    public static final int BACKUP = 3;    // 备份
    public static final int INFO = 4;      // 关于
    public static final int BOLT = 5;      // 运行
    public static final int FOLDER = 6;
    public static final int LINK = 7;
    public static final int SHIELD = 8;
    public static final int PLAY = 9;
    public static final int ALBATROSS = 10; // 信天翁
    public static final int VIDEO = 11;      // 视频导入
    public static final int BRAIN = 12;      // 思路 / 推演

    private Icon() {}

    public static void draw(Canvas cv, int type, int color, float size) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(color);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        float w = size;
        float cx = w / 2f, cy = w / 2f;
        float s = w / 24f;              // 以 24 为设计网格
        float sw = 1.85f * s;
        p.setStrokeWidth(sw);

        switch (type) {
            case SLIDERS: {
                float[] ys = {6.5f, 12f, 17.5f};
                for (float y : ys) {
                    cv.drawLine(4 * s, y * s, 20 * s, y * s, p);
                }
                p.setStyle(Paint.Style.FILL);
                cv.drawCircle(9 * s, 6.5f * s, 1.95f * s, p);
                cv.drawCircle(15 * s, 12f * s, 1.95f * s, p);
                cv.drawCircle(7.5f * s, 17.5f * s, 1.95f * s, p);
                break;
            }
            case CROSSHAIR: {
                cv.drawCircle(cx, cy, 6.6f * s, p);
                cv.drawCircle(cx, cy, 1.5f * s, p);
                cv.drawLine(cx, 2.4f * s, cx, 6.2f * s, p);
                cv.drawLine(cx, 17.8f * s, cx, 21.6f * s, p);
                cv.drawLine(2.4f * s, cy, 6.2f * s, cy, p);
                cv.drawLine(17.8f * s, cy, 21.6f * s, cy, p);
                break;
            }
            case SWAP: {
                Path a = new Path();
                a.moveTo(4 * s, 8.5f * s);
                a.lineTo(18 * s, 8.5f * s);
                a.moveTo(14.8f * s, 5.4f * s);
                a.lineTo(18 * s, 8.5f * s);
                a.lineTo(14.8f * s, 11.6f * s);
                Path b = new Path();
                b.moveTo(20 * s, 15.5f * s);
                b.lineTo(6 * s, 15.5f * s);
                b.moveTo(9.2f * s, 12.4f * s);
                b.lineTo(6 * s, 15.5f * s);
                b.lineTo(9.2f * s, 18.6f * s);
                cv.drawPath(a, p);
                cv.drawPath(b, p);
                break;
            }
            case BACKUP: {
                // 盾牌 + 勾
                Path sh = new Path();
                sh.moveTo(cx, 3.2f * s);
                sh.lineTo(19.2f * s, 6.4f * s);
                sh.lineTo(19.2f * s, 12.4f * s);
                sh.cubicTo(19.2f * s, 17.2f * s, 15.6f * s, 19.8f * s, cx, 21.2f * s);
                sh.cubicTo(8.4f * s, 19.8f * s, 4.8f * s, 17.2f * s, 4.8f * s, 12.4f * s);
                sh.lineTo(4.8f * s, 6.4f * s);
                sh.close();
                cv.drawPath(sh, p);
                Path ck = new Path();
                ck.moveTo(8.6f * s, 12.1f * s);
                ck.lineTo(11.2f * s, 14.7f * s);
                ck.lineTo(15.6f * s, 9.6f * s);
                cv.drawPath(ck, p);
                break;
            }
            case INFO: {
                cv.drawCircle(cx, cy, 9.2f * s, p);
                cv.drawLine(cx, 10.6f * s, cx, 17f * s, p);
                p.setStyle(Paint.Style.FILL);
                cv.drawCircle(cx, 7.2f * s, 1.25f * s, p);
                break;
            }
            case BOLT: {
                Path b = new Path();
                b.moveTo(13.2f * s, 2.6f * s);
                b.lineTo(5.6f * s, 13.4f * s);
                b.lineTo(10.8f * s, 13.4f * s);
                b.lineTo(9.8f * s, 21.4f * s);
                b.lineTo(18.4f * s, 10.2f * s);
                b.lineTo(12.8f * s, 10.2f * s);
                b.close();
                cv.drawPath(b, p);
                break;
            }
            case FOLDER: {
                Path f = new Path();
                f.moveTo(3.4f * s, 7.4f * s);
                f.lineTo(9.4f * s, 7.4f * s);
                f.lineTo(11.2f * s, 9.6f * s);
                f.lineTo(20.6f * s, 9.6f * s);
                f.lineTo(20.6f * s, 18.6f * s);
                f.lineTo(3.4f * s, 18.6f * s);
                f.close();
                cv.drawPath(f, p);
                break;
            }
            case LINK: {
                p.setStyle(Paint.Style.STROKE);
                RectF r1 = new RectF(2.8f * s, 9.4f * s, 12.2f * s, 15.4f * s);
                cv.drawRoundRect(r1, 3f * s, 3f * s, p);
                RectF r2 = new RectF(11.8f * s, 8.6f * s, 21.2f * s, 14.6f * s);
                cv.drawRoundRect(r2, 3f * s, 3f * s, p);
                break;
            }
            case SHIELD: {
                Path sh = new Path();
                sh.moveTo(cx, 3.2f * s);
                sh.lineTo(19.2f * s, 6.4f * s);
                sh.lineTo(19.2f * s, 12.4f * s);
                sh.cubicTo(19.2f * s, 17.2f * s, 15.6f * s, 19.8f * s, cx, 21.2f * s);
                sh.cubicTo(8.4f * s, 19.8f * s, 4.8f * s, 17.2f * s, 4.8f * s, 12.4f * s);
                sh.lineTo(4.8f * s, 6.4f * s);
                sh.close();
                cv.drawPath(sh, p);
                break;
            }
            case ALBATROSS: {
                // 细长双翼 + 纺锤身:滑翔姿态的信天翁
                Path w1 = new Path();
                w1.moveTo(cx - 0.6f * s, 12.4f * s);
                w1.quadTo(7.4f * s, 8.2f * s, 11.6f * s, 10.1f * s);
                w1.quadTo(10.4f * s, 12.2f * s, 5.4f * s, 13.6f * s);
                w1.close();
                Path w2 = new Path();
                w2.moveTo(cx + 0.6f * s, 12.4f * s);
                w2.quadTo(16.6f * s, 8.2f * s, 12.4f * s, 10.1f * s);
                w2.quadTo(13.6f * s, 12.2f * s, 18.6f * s, 13.6f * s);
                w2.close();
                cv.drawPath(w1, p);
                cv.drawPath(w2, p);
                Path bd = new Path();
                bd.moveTo(cx, 5.2f * s);
                bd.quadTo(14.2f * s, 10.4f * s, 13.2f * s, 16.6f * s);
                bd.lineTo(cx, 14.8f * s);
                bd.lineTo(10.8f * s, 16.6f * s);
                bd.quadTo(9.8f * s, 10.4f * s, cx, 5.2f * s);
                bd.close();
                cv.drawPath(bd, p);
                break;
            }
            case VIDEO: {
                RectF fr = new RectF(3.2f * s, 6.2f * s, 20.8f * s, 17.8f * s);
                cv.drawRoundRect(fr, 2.6f * s, 2.6f * s, p);
                Path tri = new Path();
                tri.moveTo(10.2f * s, 9.4f * s);
                tri.lineTo(15.6f * s, 12f * s);
                tri.lineTo(10.2f * s, 14.6f * s);
                tri.close();
                p.setStyle(Paint.Style.FILL);
                cv.drawPath(tri, p);
                p.setStyle(Paint.Style.STROKE);
                break;
            }
            case BRAIN: {
                // 思路树:一个起点分出去两条线,末端各落一个点
                cv.drawCircle(12f * s, 5.4f * s, 2.1f * s, p);
                cv.drawCircle(5.8f * s, 18.2f * s, 2.1f * s, p);
                cv.drawCircle(18.2f * s, 18.2f * s, 2.1f * s, p);
                Path lb = new Path();
                lb.moveTo(11.2f * s, 7.2f * s);
                lb.lineTo(6.7f * s, 16.2f * s);
                Path rb = new Path();
                rb.moveTo(12.8f * s, 7.2f * s);
                rb.lineTo(17.3f * s, 16.2f * s);
                cv.drawPath(lb, p);
                cv.drawPath(rb, p);
                p.setStyle(Paint.Style.FILL);
                cv.drawCircle(12f * s, 12.4f * s, 1.15f * s, p);
                p.setStyle(Paint.Style.STROKE);
                break;
            }
            case PLAY:
            default: {
                Path t = new Path();
                t.moveTo(7.6f * s, 4.8f * s);
                t.lineTo(19f * s, 12f * s);
                t.lineTo(7.6f * s, 19.2f * s);
                t.close();
                p.setStyle(Paint.Style.FILL);
                cv.drawPath(t, p);
                break;
            }
        }
    }

    /** 可嵌入布局的图标 View */
    public static class IconView extends View {
        private int type;
        private int color;

        public IconView(Context c, int type, int color) {
            super(c);
            this.type = type;
            this.color = color;
        }

        public void setType(int t) { this.type = t; invalidate(); }

        public void setColor(int c) { this.color = c; invalidate(); }

        @Override
        protected void onMeasure(int w, int h) {
            int size = Ui.dp(getContext(), 22);
            setMeasuredDimension(size, size);
        }

        @Override
        protected void onDraw(Canvas cv) {
            Icon.draw(cv, type, color, Math.min(getWidth(), getHeight()));
        }
    }
}

package com.feiniao.tuner;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.feiniao.tuner.glass.LiquidGlass;

/**
 * Zaka · 飞鸟调参 — 轻量 Material 3 暗色 UI 工具箱
 * 全部组件由代码绘制,无任何第三方依赖,观感对齐 KernelSU。
 * 卡片 / 按钮走液态玻璃绘制层(见 glass/LiquidGlass)。
 */
public final class Ui {

    /* ============ 主题色板 (Material3 Dark / KSU 风) ============ */
    public static final int BG          = 0xFF0E0F12;
    public static final int SURFACE     = 0xFF191B20;
    public static final int SURFACE_2   = 0xFF23262C;
    public static final int SURFACE_3   = 0xFF2D3138;
    public static final int OUTLINE     = 0xFF373C44;
    public static final int OUTLINE_SOFT= 0xFF2A2E35;
    public static final int PRIMARY     = 0xFFA8C7FA;
    public static final int ON_PRIMARY  = 0xFF0B2E5C;
    public static final int PRIMARY_CONT= 0xFF2B3F5C;
    public static final int PURPLE      = 0xFFC58AF9;
    public static final int PURPLE_CONT = 0xFF3D2E52;
    public static final int RED         = 0xFFF87171;
    public static final int RED_CONT    = 0xFF4A2A2C;
    public static final int GREEN       = 0xFF4ADE80;
    public static final int GREEN_CONT  = 0xFF1F3A2A;
    public static final int AMBER       = 0xFFFBBF24;
    public static final int AMBER_CONT  = 0xFF41341A;
    public static final int TEXT        = 0xFFE6E8EC;
    public static final int TEXT_SUB    = 0xFFAEB4BC;
    public static final int TEXT_DIM    = 0xFF7C838C;

    public static final float R_CARD = 20f;
    public static final float R_ITEM = 14f;
    public static final float R_BTN  = 22f;
    public static final float R_PILL = 999f;

    private Ui() {}

    public static float density(Context c) {
        return c.getResources().getDisplayMetrics().density;
    }

    public static int dp(Context c, float v) {
        return (int) (v * density(c) + 0.5f);
    }

    public static int sp(Context c, float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v,
                c.getResources().getDisplayMetrics());
    }

    /* ============ 背景绘制 ============ */

    public static GradientDrawable round(int fill, float radiusDp, Context c) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.RECTANGLE);
        d.setColor(fill);
        d.setCornerRadius(dp(c, radiusDp));
        return d;
    }

    public static GradientDrawable round(int fill, float radiusDp,
                                         int strokeColor, float strokeDp, Context c) {
        GradientDrawable d = round(fill, radiusDp, c);
        if (strokeDp > 0) {
            d.setStroke(Math.max(1, dp(c, strokeDp)), strokeColor);
        }
        return d;
    }

    public static Drawable ripple(Drawable content, int rippleColor) {
        return new RippleDrawable(ColorStateList.valueOf(rippleColor), content, null);
    }

    public static Drawable pressable(int fill, float radiusDp, Context c) {
        return ripple(round(fill, radiusDp, c), 0x33FFFFFF);
    }

    /* ============ 文本 ============ */

    public static TextView text(Context c, CharSequence s, float sizeSp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sizeSp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        t.setIncludeFontPadding(false);
        return t;
    }

    public static TextView h1(Context c, CharSequence s) { return text(c, s, 22, TEXT, true); }
    public static TextView h2(Context c, CharSequence s) { return text(c, s, 17, TEXT, true); }
    public static TextView body(Context c, CharSequence s) { return text(c, s, 14, TEXT_SUB, false); }
    public static TextView dim(Context c, CharSequence s) { return text(c, s, 12.5f, TEXT_DIM, false); }

    /** 区块小标题 */
    public static TextView section(Context c, CharSequence s) {
        TextView t = text(c, s, 13, PRIMARY, true);
        t.setLetterSpacing(0.06f);
        t.setPadding(dp(c, 4), dp(c, 2), 0, dp(c, 6));
        return t;
    }

    /* ============ 容器 ============ */

    public static LinearLayout card(Context c) {
        return card(c, 0);
    }

    /** 带染色的玻璃卡:强调区块用(比如当前口径提醒) */
    public static LinearLayout card(Context c, int tint) {
        LiquidGlass.Card l = new LiquidGlass.Card(c, R_CARD, tint);
        l.setOrientation(LinearLayout.VERTICAL);
        int p = dp(c, 15);
        l.setPadding(p, p, p, p);
        return l;
    }

    /** 把任意 View 变成玻璃面 */
    public static void glass(View v, float radiusDp, int tint) {
        LiquidGlass.setBackgroundOf(v, radiusDp, tint);
    }

    /** 玻璃胶囊按钮(导航 / 顶栏小件用) */
    public static TextView glassPill(Context c, String label, int fg) {
        TextView t = text(c, label, 11f, fg, true);
        t.setPadding(dp(c, 10), dp(c, 5), dp(c, 10), dp(c, 5));
        LiquidGlass.setBackgroundOf(t, R_PILL, 0);
        return t;
    }

    public static LinearLayout col(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    public static LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    public static ScrollView scroll(Context c) {
        ScrollView s = new ScrollView(c);
        s.setFillViewport(true);
        s.setClipToPadding(false);
        s.setVerticalScrollBarEnabled(false);
        s.setOverScrollMode(View.OVER_SCROLL_NEVER);
        return s;
    }

    public static View gap(Context c, float dpHeight) {
        View v = new View(c);
        v.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(c, dpHeight)));
        return v;
    }

    public static View divider(Context c) {
        View v = new View(c);
        v.setBackgroundColor(OUTLINE_SOFT);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, dp(c, 0.8f)));
        lp.topMargin = dp(c, 10);
        lp.bottomMargin = dp(c, 10);
        v.setLayoutParams(lp);
        return v;
    }

    /** 卡片之间的固定间距 */
    public static void stack(LinearLayout parent, View child) {
        Context c = parent.getContext();
        LinearLayout.LayoutParams lp;
        if (child.getLayoutParams() instanceof LinearLayout.LayoutParams) {
            lp = (LinearLayout.LayoutParams) child.getLayoutParams();
        } else {
            lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        lp.bottomMargin = dp(c, 12);
        parent.addView(child, lp);
    }

    /* ============ 按钮 ============ */

    public static TextView button(Context c, String label, int style) {
        // style: 0=filled 1=tonal 2=outlined 3=danger 4=ghost
        TextView b = new TextView(c);
        b.setText(label);
        b.setTextSize(14.5f);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(c, 18), dp(c, 11), dp(c, 18), dp(c, 11));
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        switch (style) {
            case 0:
                b.setTextColor(ON_PRIMARY);
                b.setBackground(pressable(PRIMARY, R_BTN, c));
                break;
            case 1:
                b.setTextColor(PRIMARY);
                LiquidGlass.setGlassRipple(b, R_BTN, 0x2EA8C7FA);
                break;
            case 2:
                b.setTextColor(TEXT);
                LiquidGlass.setGlassRipple(b, R_BTN, 0);
                break;
            case 3:
                b.setTextColor(RED);
                b.setBackground(pressable(RED_CONT, R_BTN, c));
                break;
            default:
                b.setTextColor(PRIMARY);
                b.setBackground(ripple(round(0x00000000, R_BTN, c), 0x22FFFFFF));
                break;
        }
        b.setClickable(true);
        b.setFocusable(true);
        return b;
    }

    public static TextView chip(Context c, String label, boolean active) {
        TextView t = text(c, label, 12.5f, active ? ON_PRIMARY : TEXT_SUB, true);
        t.setPadding(dp(c, 12), dp(c, 6), dp(c, 12), dp(c, 6));
        t.setBackground(active ? pressable(PRIMARY, R_PILL, c) : pressable(SURFACE_2, R_PILL, c));
        return t;
    }

    /* ============ 输入框 ============ */

    public static EditText input(Context c, String hint) {
        EditText e = new EditText(c);
        e.setHint(hint);
        e.setTextSize(14f);
        e.setTextColor(TEXT);
        e.setHintTextColor(TEXT_DIM);
        e.setBackground(round(SURFACE_2, R_ITEM, OUTLINE_SOFT, 1, c));
        e.setPadding(dp(c, 13), dp(c, 10), dp(c, 13), dp(c, 10));
        e.setInputType(InputType.TYPE_CLASS_TEXT);
        e.setSingleLine(true);
        return e;
    }

    public static EditText numInput(Context c, String hint) {
        EditText e = input(c, hint);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL
                | InputType.TYPE_NUMBER_FLAG_SIGNED);
        return e;
    }

    /** 标签 + 输入框 一行 */
    public static LinearLayout field(Context c, String label, EditText input) {
        LinearLayout r = row(c);
        TextView l = text(c, label, 13.5f, TEXT_SUB, false);
        l.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        input.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1.35f));
        r.addView(l);
        r.addView(input);
        return r;
    }

    /** 键值展示行 */
    public static LinearLayout kv(Context c, String k, String v, int valueColor) {
        LinearLayout r = row(c);
        TextView a = text(c, k, 13.5f, TEXT_SUB, false);
        a.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView b = text(c, v, 13.5f, valueColor, true);
        b.setGravity(Gravity.END);
        r.addView(a);
        r.addView(b);
        return r;
    }

    public static LinearLayout kv(Context c, String k, String v) {
        return kv(c, k, v, TEXT);
    }

    /* ============ 徽标 ============ */

    public static TextView badge(Context c, String label, int fg, int bg) {
        TextView t = text(c, label, 11.5f, fg, true);
        t.setPadding(dp(c, 9), dp(c, 4), dp(c, 9), dp(c, 4));
        t.setBackground(round(bg, R_PILL, c));
        return t;
    }

    /** 页面统一内边距容器 */
    public static LinearLayout page(Context c) {
        LinearLayout l = col(c);
        int p = dp(c, 14);
        l.setPadding(p, dp(c, 8), p, dp(c, 28));
        return l;
    }
}

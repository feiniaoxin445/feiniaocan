package com.feiniao.tuner.glass;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.view.View;

/**
 * 液态玻璃绘制层。
 *
 * 零图片资源,靠四层叠出来:
 *   ① 染色层   —— 可选,给这片玻璃定个色调
 *   ② 玻璃本体 —— 斜向的半透明白渐层,越往右下越薄,透出底下流动的光斑
 *   ③ 液态高光 —— 斜扫的高光带 + 左上角一滴"液珠"散射亮斑
 *   ④ 边缘折射 —— 上亮下暗的细描边 + 顶面液面亮线
 *
 * 玻璃卡 / 顶栏 / 底栏 / 按钮都能直接用,给任意 View 设成背景即可。
 */
public final class LiquidGlass {

    private LiquidGlass() {}

    public static float density(Resources r) {
        return r == null ? 2.75f : r.getDisplayMetrics().density;
    }

    /** 玻璃背景,给任意 View 当背景用 */
    public static class GlassDrawable extends Drawable {

        private final float radiusDp;
        private final int tint;
        private final float density;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path clip = new Path();
        private final RectF rr = new RectF();

        private Shader base, sheen, drop, edge, topLine;

        public GlassDrawable(float radiusDp, int tint, float density) {
            this.radiusDp = radiusDp;
            this.tint = tint;
            this.density = density <= 0f ? 2.75f : density;
        }

        private float dp(float v) { return v * density; }

        @Override
        protected void onBoundsChange(Rect b) {
            super.onBoundsChange(b);
            build(b.width(), b.height());
        }

        private void build(float w, float h) {
            if (w <= 0 || h <= 0) return;
            base = new LinearGradient(0f, 0f, w, h,
                    new int[]{0x32FFFFFF, 0x18FFFFFF, 0x0CFFFFFF, 0x1CFFFFFF},
                    new float[]{0f, 0.34f, 0.72f, 1f}, Shader.TileMode.CLAMP);
            sheen = new LinearGradient(-w * 0.25f, h * 0.95f, w * 0.75f, -h * 0.15f,
                    new int[]{0x00FFFFFF, 0x00FFFFFF, 0x1EFFFFFF, 0x00FFFFFF, 0x00FFFFFF},
                    new float[]{0f, 0.34f, 0.5f, 0.66f, 1f}, Shader.TileMode.CLAMP);
            drop = new RadialGradient(w * 0.18f, h * 0.06f, Math.max(w, h) * 0.6f,
                    new int[]{0x26FFFFFF, 0x0AFFFFFF, 0x00FFFFFF},
                    new float[]{0f, 0.4f, 1f}, Shader.TileMode.CLAMP);
            edge = new LinearGradient(0f, 0f, 0f, h,
                    new int[]{0x52FFFFFF, 0x1CFFFFFF, 0x0EFFFFFF, 0x26FFFFFF},
                    new float[]{0f, 0.3f, 0.75f, 1f}, Shader.TileMode.CLAMP);
            topLine = new LinearGradient(0f, 0f, w, 0f,
                    new int[]{0x00FFFFFF, 0x55FFFFFF, 0x00FFFFFF},
                    new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP);
        }

        @Override
        public void draw(Canvas cv) {
            final Rect b = getBounds();
            final float w = b.width(), h = b.height();
            if (w <= 0 || h <= 0) return;
            if (base == null) build(w, h);

            final float r = radiusDp > 900f ? h / 2f : dp(radiusDp);

            rr.set(b.left, b.top, b.right, b.bottom);
            clip.reset();
            clip.addRoundRect(rr, r, r, Path.Direction.CW);

            cv.save();
            cv.clipPath(clip);

            p.setStyle(Paint.Style.FILL);
            p.setShader(null);

            /* ① 染色层(可选) */
            if ((tint >>> 24) != 0) {
                p.setColor(tint);
                cv.drawRect(rr, p);
            }

            /* ② 玻璃本体 + 液态高光 + 液珠散射 */
            p.setShader(base);
            cv.drawRect(rr, p);
            p.setShader(sheen);
            cv.drawRect(rr, p);
            p.setShader(drop);
            cv.drawRect(rr, p);
            p.setShader(null);

            cv.restore();

            /* ③ 边缘折射描边 */
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(1f, dp(1.1f)));
            p.setShader(edge);
            float inset = p.getStrokeWidth() * 0.5f;
            rr.set(b.left + inset, b.top + inset, b.right - inset, b.bottom - inset);
            cv.drawRoundRect(rr, r, r, p);
            p.setShader(null);

            /* ④ 顶面液面亮线 */
            float ty = b.top + Math.max(1f, dp(1.3f));
            p.setStrokeWidth(Math.max(1f, dp(1f)));
            p.setShader(topLine);
            cv.drawLine(b.left + r * 0.6f, ty, b.right - r * 0.6f, ty, p);
            p.setShader(null);
            p.setStyle(Paint.Style.FILL);
        }

        @Override
        public void setAlpha(int alpha) { p.setAlpha(alpha); }

        @Override
        public void setColorFilter(ColorFilter cf) { p.setColorFilter(cf); }

        @Override
        public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    /** 玻璃卡:给 LinearLayout 用 */
    public static class Card extends android.widget.LinearLayout {
        public Card(Context c) { this(c, 20f, 0); }

        public Card(Context c, float radiusDp, int tint) {
            super(c);
            setOrientation(VERTICAL);
            setBackgroundOf(this, radiusDp, tint);
        }
    }

    /** 短手:把任意 View 变成玻璃面 */
    public static void setBackgroundOf(View v, float radiusDp, int tint) {
        v.setBackground(new GlassDrawable(radiusDp, tint, density(v.getResources())));
    }

    /** 玻璃面 + 点按涟漪 */
    public static void setGlassRipple(View v, float radiusDp, int tint) {
        Drawable g = new GlassDrawable(radiusDp, tint, density(v.getResources()));
        v.setBackground(new android.graphics.drawable.RippleDrawable(
                android.content.res.ColorStateList.valueOf(0x33FFFFFF), g, null));
    }
}

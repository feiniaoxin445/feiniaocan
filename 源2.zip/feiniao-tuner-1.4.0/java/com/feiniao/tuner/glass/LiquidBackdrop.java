package com.feiniao.tuner.glass;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

/**
 * 背景液态玻璃底:
 *
 *   · 底色是深空灰,上面漂三团慢慢游动的色雾(蓝 / 紫 / 青)
 *   · 再浮几片半透明的玻璃薄片,缓缓平移转动
 *   · 底部一条液态液面,随时间起伏
 *
 * 上面盖着的玻璃卡会把这三层透出来,玻璃才有"活"的感觉。
 */
public class LiquidBackdrop extends View {

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rr = new RectF();
    private final Path wave = new Path();

    private Shader blobA, blobB, blobC, veil, sheen;
    private float t;
    private float w, h;
    private ValueAnimator anim;
    private boolean built;

    public LiquidBackdrop(Context c) {
        super(c);
        setLayerType(View.LAYER_TYPE_HARDWARE, null);
    }

    /* ================= 生命周期 ================= */

    @Override
    protected void onSizeChanged(int nw, int nh, int ow, int oh) {
        super.onSizeChanged(nw, nh, ow, oh);
        w = nw;
        h = nh;
        build();
    }

    private void build() {
        if (w <= 0 || h <= 0) return;
        float r = Math.max(w, h) * 0.62f;
        blobA = new RadialGradient(0, 0, r,
                new int[]{0x3C4E7BC8, 0x144E7BC8, 0x004E7BC8},
                new float[]{0f, 0.46f, 1f}, Shader.TileMode.CLAMP);
        blobB = new RadialGradient(0, 0, r * 0.88f,
                new int[]{0x33A06BD6, 0x12A06BD6, 0x00A06BD6},
                new float[]{0f, 0.44f, 1f}, Shader.TileMode.CLAMP);
        blobC = new RadialGradient(0, 0, r * 0.72f,
                new int[]{0x2E37B5A8, 0x1037B5A8, 0x0037B5A8},
                new float[]{0f, 0.42f, 1f}, Shader.TileMode.CLAMP);
        veil = new LinearGradient(0, 0, 0, h,
                new int[]{0x000E0F12, 0x000E0F12, 0x6607080A},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP);
        sheen = new LinearGradient(0, 0, w, h * 0.4f,
                new int[]{0x0AFFFFFF, 0x00FFFFFF},
                new float[]{0f, 1f}, Shader.TileMode.CLAMP);
        built = true;
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (anim == null) {
            anim = ValueAnimator.ofFloat(0f, 1f);
            anim.setDuration(14000L);
            anim.setRepeatCount(ValueAnimator.INFINITE);
            anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator a) {
                    t = (Float) a.getAnimatedValue();
                    invalidate();
                }
            });
            anim.start();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        if (anim != null) {
            anim.removeAllUpdateListeners();
            anim.cancel();
            anim = null;
        }
        super.onDetachedFromWindow();
    }

    /* ================= 绘制 ================= */

    @Override
    protected void onDraw(Canvas cv) {
        if (w <= 0 || h <= 0) return;
        if (!built) build();

        cv.drawColor(0xFF0E0F12);

        final double a = t * Math.PI * 2.0;

        /* ---- 三团色雾 ---- */
        blob(cv, blobA,
                w * 0.22f + (float) Math.sin(a) * w * 0.30f,
                h * 0.16f + (float) Math.cos(a * 0.8) * h * 0.10f,
                1f);

        blob(cv, blobB,
                w * 0.80f + (float) Math.cos(a * 0.85 + 1.2) * w * 0.26f,
                h * 0.34f + (float) Math.sin(a * 1.1) * h * 0.14f,
                1f);

        blob(cv, blobC,
                w * 0.40f + (float) Math.sin(a * 0.65 + 2.4) * w * 0.34f,
                h * 0.82f + (float) Math.cos(a * 0.9 + 0.6) * h * 0.12f,
                1f);

        /* ---- 玻璃薄片 ---- */
        p.setShader(null);
        for (int i = 0; i < 3; i++) {
            float ph = i * 2.4f;
            float sx = w * (0.18f + 0.32f * i)
                    + (float) Math.sin(a * (0.5 + i * 0.17) + ph) * w * 0.16f;
            float sy = h * (0.22f + 0.26f * i)
                    + (float) Math.cos(a * (0.42 + i * 0.13) + ph) * h * 0.10f;
            float sw = w * (0.34f + 0.08f * i);
            float sh = h * (0.055f + 0.012f * i);
            float rot = (float) Math.sin(a * 0.4 + ph) * 14f;

            cv.save();
            cv.translate(sx, sy);
            cv.rotate(rot);
            rr.set(-sw * 0.5f, -sh * 0.5f, sw * 0.5f, sh * 0.5f);
            p.setColor(0x0EFFFFFF);
            cv.drawRoundRect(rr, sh * 0.5f, sh * 0.5f, p);
            p.setColor(0x16FFFFFF);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(1f, LiquidGlass.density(getResources())));
            cv.drawRoundRect(rr, sh * 0.5f, sh * 0.5f, p);
            p.setStyle(Paint.Style.FILL);
            cv.restore();
        }

        /* ---- 顶部微光 ---- */
        p.setShader(sheen);
        cv.drawRect(0, 0, w, h * 0.4f, p);

        /* ---- 底部液面 ---- */
        p.setShader(null);
        float baseY = h - h * 0.06f;
        wave.reset();
        wave.moveTo(0, baseY);
        int steps = 8;
        for (int i = 0; i <= steps; i++) {
            float k = i / (float) steps;
            float y = baseY + (float) Math.sin(a * 0.9 + k * 5.2) * h * 0.012f;
            wave.lineTo(w * k, y);
        }
        wave.lineTo(w, h);
        wave.lineTo(0, h);
        wave.close();
        p.setColor(0x1A6E8FCB);
        cv.drawPath(wave, p);

        /* ---- 底部压暗,让底栏压得住 ---- */
        p.setShader(veil);
        cv.drawRect(0, 0, w, h, p);
        p.setShader(null);
    }

    private void blob(Canvas cv, Shader s, float x, float y, float k) {
        if (s == null) return;
        cv.save();
        cv.translate(x, y);
        p.setShader(s);
        cv.drawCircle(0, 0, Math.max(w, h) * 0.62f * k, p);
        p.setShader(null);
        cv.restore();
    }
}

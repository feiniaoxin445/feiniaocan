package com.feiniao.tuner.model;

import org.json.JSONObject;

/** 单个距离分段的调参单元 */
public class Segment {

    public float distance;     // 该段距离(米)
    public float charSpeed;    // 人物速度
    public float bulletSpeed;  // 子弹速度
    public float predict;      // 预判大小(身位)
    public float hDecay;       // 横向衰减
    public float sub;          // 小距离:这一档内部的微调步长(米),0 = 没设

    public Segment() {}

    public Segment(float distance, float charSpeed, float bulletSpeed, float predict, float hDecay) {
        this(distance, charSpeed, bulletSpeed, predict, hDecay, 0f);
    }

    public Segment(float distance, float charSpeed, float bulletSpeed, float predict,
                   float hDecay, float sub) {
        this.distance = distance;
        this.charSpeed = charSpeed;
        this.bulletSpeed = bulletSpeed;
        this.predict = predict;
        this.hDecay = hDecay;
        this.sub = sub;
    }

    public Segment copy() {
        return new Segment(distance, charSpeed, bulletSpeed, predict, hDecay, sub);
    }

    public JSONObject toJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("d", f(distance));
            o.put("cs", f(charSpeed));
            o.put("bs", f(bulletSpeed));
            o.put("p", f(predict));
            o.put("h", f(hDecay));
            o.put("sub", f(sub));
        } catch (Throwable ignored) {}
        return o;
    }

    public static Segment fromJson(JSONObject o) {
        Segment s = new Segment();
        s.distance = (float) o.optDouble("d", 0);
        s.charSpeed = (float) o.optDouble("cs", 0);
        s.bulletSpeed = (float) o.optDouble("bs", 0);
        s.predict = (float) o.optDouble("p", 0);
        s.hDecay = (float) o.optDouble("h", 0);
        s.sub = (float) o.optDouble("sub", 0);
        return s;
    }

    private static double f(float v) {
        return Math.round(v * 1000.0) / 1000.0;
    }

    public String label() {
        return trim(distance) + "m";
    }

    public static String trim(float v) {
        if (Math.abs(v - Math.round(v)) < 0.001f) return String.valueOf(Math.round(v));
        return String.valueOf(Math.round(v * 100f) / 100f);
    }
}

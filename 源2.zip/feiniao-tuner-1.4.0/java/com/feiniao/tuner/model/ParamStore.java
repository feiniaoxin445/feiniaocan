package com.feiniao.tuner.model;

import android.content.Context;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

/** 方案持久化:当前工作方案 + 预设库 */
public final class ParamStore {

    private static final Charset UTF8 = Charset.forName("UTF-8");

    private ParamStore() {}

    private static File dir(Context c) {
        File d = new File(c.getFilesDir(), "params");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    private static File currentFile(Context c) {
        return new File(dir(c), "__current.json");
    }

    /* ---------- 当前方案 ---------- */

    public static ParamSet loadCurrent(Context c) {
        try {
            File f = currentFile(c);
            if (!f.exists()) {
                ParamSet d = ParamSet.defaults();
                saveCurrent(c, d);
                return d;
            }
            ParamSet p = ParamSet.fromJson(new JSONObject(readText(f)));
            if (p.segments.isEmpty()) return ParamSet.defaults();
            return p;
        } catch (Throwable t) {
            return ParamSet.defaults();
        }
    }

    public static void saveCurrent(Context c, ParamSet p) {
        try {
            writeText(currentFile(c), p.toJson().toString(2));
        } catch (Throwable ignored) {}
    }

    /* ---------- 预设库 ---------- */

    public static List<String> listPresets(Context c) {
        List<String> out = new ArrayList<>();
        File[] fs = dir(c).listFiles();
        if (fs == null) return out;
        for (File f : fs) {
            String n = f.getName();
            if (n.endsWith(".json") && !n.startsWith("__")) out.add(n.substring(0, n.length() - 5));
        }
        java.util.Collections.sort(out);
        return out;
    }

    public static ParamSet loadPreset(Context c, String name) {
        try {
            File f = new File(dir(c), name + ".json");
            if (!f.exists()) return null;
            return ParamSet.fromJson(new JSONObject(readText(f)));
        } catch (Throwable t) {
            return null;
        }
    }

    public static boolean savePreset(Context c, String name, ParamSet p) {
        try {
            ParamSet cp = p.copy();
            cp.name = name;
            writeText(new File(dir(c), name + ".json"), cp.toJson().toString(2));
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    public static boolean deletePreset(Context c, String name) {
        return new File(dir(c), name + ".json").delete();
    }

    /* ---------- 文本导入导出 ---------- */

    public static String toJsonText(ParamSet p) {
        try { return p.toJson().toString(2); } catch (Throwable t) { return "{}"; }
    }

    public static ParamSet fromJsonText(String s) {
        try { return ParamSet.fromJson(new JSONObject(s)); } catch (Throwable t) { return null; }
    }

    /* ---------- 工具 ---------- */

    public static String readText(File f) throws Exception {
        FileInputStream in = new FileInputStream(f);
        try {
            byte[] buf = new byte[(int) f.length()];
            int off = 0;
            while (off < buf.length) {
                int r = in.read(buf, off, buf.length - off);
                if (r < 0) break;
                off += r;
            }
            return new String(buf, 0, off, UTF8);
        } finally {
            try { in.close(); } catch (Throwable ignored) {}
        }
    }

    public static String readStream(InputStream in) throws Exception {
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int r;
        while ((r = in.read(buf)) > 0) bo.write(buf, 0, r);
        return new String(bo.toByteArray(), UTF8);
    }

    public static void writeText(File f, String s) throws Exception {
        File p = f.getParentFile();
        if (p != null && !p.exists()) p.mkdirs();
        FileOutputStream out = new FileOutputStream(f);
        try {
            out.write(s.getBytes(UTF8));
            out.flush();
        } finally {
            try { out.close(); } catch (Throwable ignored) {}
        }
    }
}

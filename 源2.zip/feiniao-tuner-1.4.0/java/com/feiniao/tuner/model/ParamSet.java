package com.feiniao.tuner.model;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** 一整套调参方案 */
public class ParamSet {

    public String name = "默认方案";
    public float totalDistance = 400f;   // 总距离(米)
    public float bodyWidth = 0.75f;      // 一个身位当量(米)
    public float speedScale = 0.33f;     // 人物速度(游戏值) → 米/秒 的换算系数
    public float bulletRef = 780f;       // 参考子弹速度(米/秒),用于距离反推
    public float pxPerMeter = 0f;        // 像素当量(px/米),0 = 自动推算
    public String weapon = "revolver";   // 当前武器思路:左轮 / 猎枪 / 通用
    public String versionTag = "超自然"; // 这套数值对应的版本口径

    public final List<Segment> segments = new ArrayList<>();

    public static ParamSet defaults() {
        ParamSet p = new ParamSet();
        p.name = "默认方案";
        p.totalDistance = 400f;
        p.bodyWidth = 0.75f;
        p.speedScale = 0.33f;
        p.bulletRef = 780f;
        float[] d  = {50, 100, 150, 200, 250, 300, 350, 400};
        float[] cs = {19, 19, 19, 20, 20, 20, 20, 20};
        float[] bs = {800, 790, 780, 770, 760, 750, 740, 730};
        float[] pr = {0.5f, 0.8f, 1.1f, 1.4f, 1.7f, 2.0f, 2.4f, 2.8f};
        for (int i = 0; i < d.length; i++) {
            p.segments.add(new Segment(d[i], cs[i], bs[i], pr[i], 0f));
        }
        return p;
    }

    public ParamSet copy() {
        ParamSet p = new ParamSet();
        p.name = name;
        p.totalDistance = totalDistance;
        p.bodyWidth = bodyWidth;
        p.speedScale = speedScale;
        p.bulletRef = bulletRef;
        p.pxPerMeter = pxPerMeter;
        p.weapon = weapon;
        p.versionTag = versionTag;
        for (Segment s : segments) p.segments.add(s.copy());
        return p;
    }

    public void sortByDistance() {
        java.util.Collections.sort(segments, new java.util.Comparator<Segment>() {
            @Override
            public int compare(Segment a, Segment b) {
                return Float.compare(a.distance, b.distance);
            }
        });
    }

    /** 找到距离落在的分段(就近) */
    public Segment nearest(float dist) {
        Segment best = null;
        float bestGap = Float.MAX_VALUE;
        for (Segment s : segments) {
            float g = Math.abs(s.distance - dist);
            if (g < bestGap) { bestGap = g; best = s; }
        }
        return best;
    }

    public int indexOf(Segment s) {
        return segments.indexOf(s);
    }

    public JSONObject toJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("name", name);
            o.put("totalDistance", totalDistance);
            o.put("bodyWidth", bodyWidth);
            o.put("speedScale", speedScale);
            o.put("bulletRef", bulletRef);
            o.put("pxPerMeter", pxPerMeter);
            o.put("weapon", weapon);
            o.put("versionTag", versionTag);
            JSONArray arr = new JSONArray();
            for (Segment s : segments) arr.put(s.toJson());
            o.put("segments", arr);
        } catch (Throwable ignored) {}
        return o;
    }

    public static ParamSet fromJson(JSONObject o) {
        ParamSet p = new ParamSet();
        p.name = o.optString("name", "方案");
        p.totalDistance = (float) o.optDouble("totalDistance", 400);
        p.bodyWidth = (float) o.optDouble("bodyWidth", 0.75);
        p.speedScale = (float) o.optDouble("speedScale", 0.33);
        p.bulletRef = (float) o.optDouble("bulletRef", 780);
        p.pxPerMeter = (float) o.optDouble("pxPerMeter", 0);
        p.weapon = o.optString("weapon", "revolver");
        p.versionTag = o.optString("versionTag", "超自然");
        JSONArray arr = o.optJSONArray("segments");
        if (arr != null) {
            for (int i = 0; i < arr.length(); i++) {
                JSONObject so = arr.optJSONObject(i);
                if (so != null) p.segments.add(Segment.fromJson(so));
            }
        }
        if (p.segments.isEmpty()) p.segments.addAll(defaults().segments);
        p.sortByDistance();
        return p;
    }
}

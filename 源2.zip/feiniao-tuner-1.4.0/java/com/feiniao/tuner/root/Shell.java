package com.feiniao.tuner.root;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/** Root / Shell 通道 */
public final class Shell {

    public static class Result {
        public int code = -1;
        public String out = "";
        public String err = "";

        public boolean ok() { return code == 0; }

        public String all() {
            String s = (out == null ? "" : out).trim();
            String e = (err == null ? "" : err).trim();
            if (s.isEmpty()) return e;
            if (e.isEmpty()) return s;
            return s + "\n" + e;
        }
    }

    private Shell() {}

    /** 普通 shell */
    public static Result sh(String cmd) {
        return exec(new String[]{"sh", "-c", cmd}, 20000);
    }

    /** root shell,自动适配 su 的两种调用形态 */
    public static Result su(String cmd) {
        Result r = exec(new String[]{"su", "-c", cmd}, 45000);
        if (r.code == -1 && r.err != null && r.err.toLowerCase().contains("no such file")) {
            r = exec(new String[]{"su", "0", "sh", "-c", cmd}, 45000);
        }
        return r;
    }

    /** 是否具备 root */
    public static boolean hasRoot() {
        try {
            Result r = exec(new String[]{"su", "-c", "id"}, 15000);
            String s = r.all();
            if (s.contains("uid=0")) return true;
            Result r2 = exec(new String[]{"su", "0", "id"}, 15000);
            return r2.all().contains("uid=0");
        } catch (Throwable t) {
            return false;
        }
    }

    /** root 是否可用 + 简要信息 */
    public static String rootInfo() {
        Result r = su("id; echo ---; getprop ro.build.version.release 2>/dev/null");
        String s = r.all();
        if (s.contains("uid=0")) return "已授权 root";
        return s.isEmpty() ? "未检测到 root" : s;
    }

    /* ---------- 底层执行 ---------- */

    private static Result exec(String[] argv, long timeoutMs) {
        Result r = new Result();
        Process p = null;
        Thread watch = null;
        try {
            ProcessBuilder pb = new ProcessBuilder(argv);
            pb.redirectErrorStream(false);
            p = pb.start();

            final Process fp = p;
            final boolean[] killed = {false};
            watch = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Thread.sleep(45000);
                        killed[0] = true;
                        fp.destroy();
                    } catch (Throwable ignored) {}
                }
            });
            watch.setDaemon(true);
            watch.start();

            Gob o = new Gob(p.getInputStream());
            Gob e = new Gob(p.getErrorStream());
            o.start();
            e.start();
            r.code = p.waitFor();
            o.join(1500);
            e.join(1500);
            r.out = o.text();
            r.err = e.text();
            if (killed[0]) {
                r.code = -1;
                r.err = (r.err == null ? "" : r.err) + "\n[超时]";
            }
        } catch (Throwable t) {
            r.code = -1;
            r.err = String.valueOf(t.getMessage());
        } finally {
            if (watch != null) {
                try { watch.interrupt(); } catch (Throwable ignored) {}
            }
            if (p != null) {
                try { p.destroy(); } catch (Throwable ignored) {}
            }
        }
        return r;
    }

    private static class Gob extends Thread {
        private final InputStream in;
        private final ByteArrayOutputStream buf = new ByteArrayOutputStream();

        Gob(InputStream in) { this.in = in; setDaemon(true); }

        @Override
        public void run() {
            try {
                byte[] b = new byte[4096];
                int n;
                while ((n = in.read(b)) > 0) buf.write(b, 0, n);
            } catch (Throwable ignored) {}
            try { in.close(); } catch (Throwable ignored) {}
        }

        String text() {
            try { return new String(buf.toByteArray(), "UTF-8"); } catch (Throwable t) { return ""; }
        }
    }

    /** 单引号安全包裹 */
    public static String q(String s) {
        if (s == null) return "''";
        return "'" + s.replace("'", "'\\''") + "'";
    }
}

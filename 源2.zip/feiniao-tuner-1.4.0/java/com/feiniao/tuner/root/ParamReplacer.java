package com.feiniao.tuner.root;

import android.content.Context;
import android.net.Uri;

import com.feiniao.tuner.model.ParamStore;

import java.io.File;

/**
 * 参数替换 / 备份 执行器。
 * 全部走 root 通道,替换前自动留备份。
 */
public final class ParamReplacer {

    public static class Out {
        public boolean ok;
        public String msg = "";
        public String detail = "";
        public String backupPath = "";
        public String stagedPath = "";
    }

    private ParamReplacer() {}

    /* ---------- 暂存 ---------- */

    /** 把 ini 文本落成临时文件,准备推送 */
    public static File stage(Context c, String content, String fileName) throws Exception {
        if (fileName == null || fileName.trim().isEmpty()) fileName = "preference.ini";
        File dir = new File(c.getCacheDir(), "stage");
        if (!dir.exists()) dir.mkdirs();
        File f = new File(dir, fileName);
        ParamStore.writeText(f, content);
        return f;
    }

    /* ---------- root 基础操作 ---------- */

    public static boolean existsRoot(String path) {
        Shell.Result r = Shell.su("[ -e " + Shell.q(path) + " ] && echo YES || echo NO");
        return r.all().contains("YES");
    }

    public static String lsRoot(String path) {
        return Shell.su("ls -l " + Shell.q(path) + " 2>&1").all();
    }

    public static String readRoot(String path) {
        return Shell.su("cat " + Shell.q(path) + " 2>&1").all();
    }

    public static Out mkdirp(String dir) {
        Out o = new Out();
        Shell.Result r = Shell.su("mkdir -p " + Shell.q(dir) + " 2>&1 && echo __OK__");
        o.ok = r.all().contains("__OK__");
        o.msg = o.ok ? "目录就绪" : "目录创建失败";
        o.detail = r.all();
        return o;
    }

    /* ---------- 备份 ---------- */

    /** 把 src(文件或目录)复制到 dstDir 下 */
    public static Out backupTo(String src, String dstDir) {
        Out o = new Out();
        Shell.Result r = Shell.su(
                "mkdir -p " + Shell.q(dstDir) + " 2>&1"
                        + " && cp -rf " + Shell.q(src) + " " + Shell.q(dstDir) + "/ 2>&1"
                        + " && echo __OK__"
                        + " && ls -l " + Shell.q(dstDir) + " 2>&1");
        String all = r.all();
        o.ok = all.contains("__OK__");
        o.msg = o.ok ? "备份完成" : "备份失败";
        o.detail = all.replace("__OK__", "").trim();
        o.backupPath = dstDir;
        return o;
    }

    /** 带时间戳的安全备份(替换前调用) */
    public static String backupFile(String target, String backupDir) {
        if (!existsRoot(target)) return "";
        String ts = new java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US)
                .format(new java.util.Date());
        String name = new File(target).getName();
        Shell.Result r = Shell.su("mkdir -p " + Shell.q(backupDir)
                + " && cp -p " + Shell.q(target) + " " + Shell.q(backupDir + "/" + name + "." + ts)
                + " && echo " + Shell.q(backupDir + "/" + name + "." + ts));
        String all = r.all();
        for (String line : all.split("\n")) {
            String s = line.trim();
            if (s.startsWith(backupDir)) return s;
        }
        return "";
    }

    /* ---------- 替换 ---------- */

    /** 用暂存文件替换目标路径(需要 root) */
    public static Out replaceWithRoot(File staged, String target) {
        Out o = new Out();
        if (staged == null || !staged.exists()) {
            o.msg = "暂存文件不存在";
            return o;
        }
        o.stagedPath = staged.getAbsolutePath();

        String dir = new File(target).getParent();
        if (dir == null) dir = "/sdcard";

        // 1. 备份原文件
        String bk = backupFile(target, dir + "/feiniao_backup");
        o.backupPath = bk;

        // 2. 推送
        Shell.Result r = Shell.su(
                "mkdir -p " + Shell.q(dir) + " 2>&1"
                        + " && cp -f " + Shell.q(staged.getAbsolutePath()) + " " + Shell.q(target) + " 2>&1"
                        + " && chmod 666 " + Shell.q(target) + " 2>&1"
                        + " && echo __OK__");
        String all = r.all();

        if (!all.contains("__OK__")) {
            o.ok = false;
            o.msg = "替换失败(检查 root 授权与目标路径)";
            o.detail = all.trim();
            return o;
        }

        // 3. 校验 md5
        Shell.Result v = Shell.su("md5sum " + Shell.q(staged.getAbsolutePath())
                + " " + Shell.q(target) + " 2>&1");
        String md5 = v.all();
        String[] lines = md5.split("\n");
        String a = null, b = null;
        for (String line : lines) {
            String s = line.trim();
            if (s.isEmpty() || s.startsWith("md5sum") || s.contains("No such")) continue;
            String[] p = s.split("\\s+");
            if (p.length < 2) continue;
            if (p[1].equals(staged.getAbsolutePath())) a = p[0];
            else if (p[1].equals(target)) b = p[0];
        }
        boolean match = a != null && a.equals(b);

        Shell.Result ls = Shell.su("ls -l " + Shell.q(target) + " 2>&1");

        o.ok = true;
        o.msg = match ? "替换成功 · 校验一致" : "已替换 · 校验未对齐(请核对目标路径)";
        o.detail = ls.all().trim() + (match ? "" : "\nmd5: " + a + " / " + b);
        return o;
    }

    /* ---------- SAF 无 root 写入 ---------- */

    public static Out replaceWithSaf(Context c, Uri treeUri, String content, String fileName) {
        Out o = new Out();
        try {
            o.ok = com.feiniao.tuner.util.Saf.writeIntoTree(c, treeUri, fileName, content);
            o.msg = o.ok ? "已写入所选目录(免 root)" : "写入失败,确认该目录可写";
        } catch (Throwable t) {
            o.ok = false;
            o.msg = "写入失败:" + t.getClass().getSimpleName();
        }
        return o;
    }
}

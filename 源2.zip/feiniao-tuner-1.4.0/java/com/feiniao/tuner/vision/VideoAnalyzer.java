package com.feiniao.tuner.vision;

import android.content.Context;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;

import com.feiniao.tuner.core.Analysis;
import com.feiniao.tuner.core.DistStats;
import com.feiniao.tuner.core.Physics;
import com.feiniao.tuner.model.ParamSet;
import com.feiniao.tuner.model.Segment;

import java.util.ArrayList;
import java.util.List;

/**
 * 视频逐帧弹道分析。
 *
 * 1) 逐帧解码 → 红/紫目标识别 → 子弹轨迹与预判点轨迹
 * 2) 轨迹按断点切成「一次交火」
 * 3) 每次交火反推:飞行时间 → 距离 → 像素当量 → 人物速度 → 所需预判
 * 4) 结果按参数表的分段汇总,给出每段的偏差与建议值
 */
public final class VideoAnalyzer {

    public interface Callback {
        void onProgress(int percent, String msg);
        void onFinish(Analysis.Report report);
        void onFail(String msg);
    }

    public static class Config {
        public float fps = 0;            // 0 = 自动探测
        public boolean keyframesOnly = false;
        public int frameStep = 1;        // 每 N 帧取一帧
        public long startMs = 0;
        public long endMs = -1;
        public int workWidth = 480;
        public float pxPerMeter = 0;     // > 0 = 用像素当量反推距离
        public float bulletRef = 780;    // 参考子弹速度(米/秒)
        public float bodyWidth = 0.75f;
        public float speedScale = 0.33f;
        public int leadInFrames = 0;     // 出膛到首次可见的补偿帧
        public int maxFrames = 1800;     // 安全上限
        public ColorDetect.Cfg color = new ColorDetect.Cfg();

        public static Config from(ParamSet ps) {
            Config c = new Config();
            if (ps != null) {
                c.bulletRef = ps.bulletRef > 0 ? ps.bulletRef : 780;
                c.bodyWidth = ps.bodyWidth > 0 ? ps.bodyWidth : 0.75f;
                c.speedScale = ps.speedScale > 0 ? ps.speedScale : 0.33f;
                c.pxPerMeter = ps.pxPerMeter;
            }
            return c;
        }
    }

    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private VideoAnalyzer() {}

    /* ================= 入口 ================= */

    public static void run(final Context ctx, final Uri uri, final ParamSet ps,
                           final Config cfg, final Callback cb) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                final Analysis.Report report;
                try {
                    report = analyze(ctx, uri, ps, cfg, cb);
                } catch (Throwable t) {
                    MAIN.post(new Runnable() {
                        @Override
                        public void run() { cb.onFail("分析中断:" + t.getClass().getSimpleName()); }
                    });
                    return;
                }
                MAIN.post(new Runnable() {
                    @Override
                    public void run() {
                        if (report.error != null) cb.onFail(report.error);
                        else cb.onFinish(report);
                    }
                });
            }
        }, "feiniao-video-analyzer").start();
    }

    /* ================= 主流程 ================= */

    private static Analysis.Report analyze(Context ctx, Uri uri, ParamSet ps, Config cfg,
                                           Callback cb) throws Exception {
        final Analysis.Report rep = new Analysis.Report();

        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(ctx, uri);

            long durMs = parseLong(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION));
            long frameCnt = parseLong(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_FRAME_COUNT));
            int vw = (int) parseLong(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH));
            int vh = (int) parseLong(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));
            rep.durationMs = durMs;
            rep.framesTotal = (int) Math.max(0, frameCnt);

            float fps = cfg.fps;
            if (fps <= 0) {
                if (durMs > 0 && frameCnt > 0) fps = frameCnt * 1000f / durMs;
                if (fps < 8 || fps > 240) fps = 60f;
            }
            rep.fps = fps;

            long start = Math.max(0, cfg.startMs);
            long end = cfg.endMs > 0 ? Math.min(cfg.endMs, durMs) : durMs;
            if (end <= start) end = durMs;

            float stepMs = 1000f / fps * Math.max(1, cfg.frameStep);
            int option = cfg.keyframesOnly
                    ? MediaMetadataRetriever.OPTION_CLOSEST_SYNC
                    : MediaMetadataRetriever.OPTION_CLOSEST;

            rep.log("视频 " + vw + "x" + vh + " · " + (durMs / 1000f) + "s · " + Math.round(fps) + "fps");
            rep.log("采样步长 " + Math.round(stepMs) + "ms(每 " + cfg.frameStep + " 帧)");

            List<Analysis.Sample> samples = new ArrayList<>();
            float lastBx = -1, lastBy = -1;
            int idx = 0;
            long t = start;
            int lastPct = -1;

            while (t < end && idx < cfg.maxFrames) {
                Bitmap bmp = null;
                try {
                    bmp = r.getFrameAtTime(t * 1000L, option);
                } catch (Throwable ignored) {}

                if (bmp != null) {
                    List<ColorDetect.Blob> blobs = ColorDetect.detect(bmp, cfg.color);
                    Analysis.Sample s = new Analysis.Sample();
                    s.idx = idx;
                    s.tMs = t;
                    s.frameW = bmp.getWidth();
                    s.frameH = bmp.getHeight();

                    ColorDetect.Blob bullet = pickBullet(blobs, lastBx, lastBy);
                    if (bullet != null) {
                        s.hasBullet = true;
                        s.bx = bullet.cx;
                        s.by = bullet.cy;
                        s.bulletType = bullet.type;
                        lastBx = bullet.cx;
                        lastBy = bullet.cy;
                        rep.bulletFrames++;
                    }
                    ColorDetect.Blob lead = pickLargest(blobs, ColorDetect.TYPE_PURPLE);
                    if (lead != null) {
                        s.hasLead = true;
                        s.lx = lead.cx;
                        s.ly = lead.cy;
                        rep.leadFrames++;
                    }
                    samples.add(s);
                    ColorDetect.recycle(bmp);
                }

                int pct = end > start ? (int) ((t - start) * 100 / (end - start)) : 0;
                if (pct != lastPct) {
                    lastPct = pct;
                    final int fp = Math.min(99, pct);
                    final String fmsg = "逐帧识别 " + idx + " 帧 · 命中子弹 " + rep.bulletFrames;
                    MAIN.post(new Runnable() {
                        @Override public void run() { cb.onProgress(fp, fmsg); }
                    });
                }
                idx++;
                t += stepMs;
            }

            if (samples.isEmpty()) {
                rep.error = "视频没解出任何一帧,换个格式再试(建议 MP4/H.264)。";
                return rep;
            }

            buildBursts(samples, ps, cfg, rep, fps);

            if (rep.validBursts == 0) {
                rep.error = "没抓到有效的红外弹轨迹。"
                        + (rep.bulletFrames == 0
                        ? "整段视频没检测到红/紫色子弹标记 —— 到「设置」里放宽颜色阈值试试。"
                        : "子弹轨迹过短,截取一段完整的开枪画面再分析。");
                return rep;
            }

            buildRows(ps, cfg, rep);
            buildDist(ps, cfg, rep);
            MAIN.post(new Runnable() {
                @Override public void run() { cb.onProgress(100, "分析完成"); }
            });
            return rep;

        } finally {
            try { r.release(); } catch (Throwable ignored) {}
        }
    }

    /* ================= 挑选目标 ================= */

    /** 优先选最靠近上一帧位置的子弹(保证轨迹连续) */
    private static ColorDetect.Blob pickBullet(List<ColorDetect.Blob> blobs,
                                               float lastX, float lastY) {
        ColorDetect.Blob best = null;
        if (lastX >= 0) {
            float bestD = Float.MAX_VALUE;
            for (ColorDetect.Blob b : blobs) {
                float dx = b.cx - lastX, dy = b.cy - lastY;
                float d = (float) Math.sqrt(dx * dx + dy * dy);
                if (d < bestD) { bestD = d; best = b; }
            }
            // 距离上一帧太远 → 视为新一次开枪,退回取最大块
            if (best != null && bestD > 420f) best = null;
        }
        if (best == null) {
            best = pickLargest(blobs, ColorDetect.TYPE_RED);
            if (best == null) best = pickLargest(blobs, ColorDetect.TYPE_PURPLE);
        }
        return best;
    }

    private static ColorDetect.Blob pickLargest(List<ColorDetect.Blob> blobs, int type) {
        ColorDetect.Blob best = null;
        for (ColorDetect.Blob b : blobs) {
            if (b.type != type) continue;
            if (best == null || b.hits > best.hits) best = b;
        }
        return best;
    }

    /* ================= 切分交火 + 反推 ================= */

    private static void buildBursts(List<Analysis.Sample> samples, ParamSet ps, Config cfg,
                                    Analysis.Report rep, float fps) {
        float sampleSec = cfg.frameStep / fps;

        List<List<Analysis.Sample>> groups = new ArrayList<>();
        List<Analysis.Sample> cur = new ArrayList<>();
        int gap = 0;
        int prevIdx = -10;
        for (Analysis.Sample s : samples) {
            if (s.hasBullet) {
                if (!cur.isEmpty() && s.idx - prevIdx > 1 + Math.max(1, cfg.frameStep)) {
                    groups.add(cur);
                    cur = new ArrayList<>();
                }
                cur.add(s);
                prevIdx = s.idx;
                gap = 0;
            } else {
                gap++;
                if (!cur.isEmpty() && gap > 2) {
                    groups.add(cur);
                    cur = new ArrayList<>();
                }
            }
        }
        if (!cur.isEmpty()) groups.add(cur);

        rep.bursts = groups.size();

        double pxPerMeterSum = 0;
        double pxPerMeterWeight = 0;
        double distSum = 0;
        int distCount = 0;

        for (List<Analysis.Sample> g : groups) {
            Analysis.Burst b = new Analysis.Burst();
            b.startIdx = g.get(0).idx;
            b.endIdx = g.get(g.size() - 1).idx;
            b.frames = g.size();

            if (b.frames < 3) {
                b.reject = "轨迹帧数不足";
                rep.burstList.add(b);
                continue;
            }

            // 轨迹长度(过滤异常跳点)
            float len = 0;
            List<Float> deltas = new ArrayList<>();
            for (int i = 1; i < g.size(); i++) {
                float dx = g.get(i).bx - g.get(i - 1).bx;
                float dy = g.get(i).by - g.get(i - 1).by;
                float d = (float) Math.sqrt(dx * dx + dy * dy);
                if (d < 900f) {
                    len += d;
                    deltas.add(d);
                }
            }
            if (deltas.isEmpty() || len < 12f) {
                b.reject = "轨迹过短";
                rep.burstList.add(b);
                continue;
            }
            b.trackLenPx = len;

            // 飞行时间 = 可见帧数 × 采样间隔 + 补偿
            int flightFrames = (b.frames - 1) * Math.max(1, cfg.frameStep) + Math.max(0, cfg.leadInFrames);
            b.flightSec = flightFrames * (1f / fps);
            if (b.flightSec <= 0.001f) {
                b.reject = "飞行时间无效";
                rep.burstList.add(b);
                continue;
            }

            // 距离:优先像素当量,否则弹道速度反推
            if (cfg.pxPerMeter > 0) {
                b.estDistance = len / cfg.pxPerMeter;
            } else {
                b.estDistance = cfg.bulletRef * b.flightSec;
            }
            if (b.estDistance < 3f || b.estDistance > 1200f) {
                b.reject = "反推距离越界(" + Math.round(b.estDistance) + "m)";
                rep.burstList.add(b);
                continue;
            }

            // 本次交火的像素当量
            float localPPM = len / b.estDistance;

            // 预判点横向位移(只取水平分量,横向预判看的就是这个)
            float leadNet = 0;
            if (hasLeadIn(g)) {
                float firstX = 0, lastX = 0;
                boolean got = false;
                for (Analysis.Sample s : g) {
                    if (!s.hasLead) continue;
                    if (!got) { firstX = s.lx; got = true; }
                    lastX = s.lx;
                }
                leadNet = Math.abs(lastX - firstX);
            }
            b.leadMovePx = leadNet;

            b.bulletPxPerSec = (float) (len / (b.frames - 1) / sampleSec);

            b.hit = leadNet > 0.5f;

            if (b.hit) {
                float leadMeters = leadNet / localPPM;
                float charMPS = leadMeters / b.flightSec;
                b.charSpeed = charMPS / Math.max(0.001f, cfg.speedScale);
                b.needPredict = leadMeters / Math.max(0.01f, cfg.bodyWidth);
                b.valid = true;
            } else {
                // 没测到预判点 → 用该段假定人物速度做理论值
                Segment seg = ps != null ? ps.nearest(b.estDistance) : null;
                float cs = seg != null ? seg.charSpeed : 19f;
                float bs = seg != null ? seg.bulletSpeed : cfg.bulletRef;
                b.charSpeed = cs;
                b.needPredict = Physics.requiredPredict(ps, b.estDistance, cs,
                        bs > 0 ? bs : cfg.bulletRef);
                b.valid = true;
                b.reject = "无预判点·理论推算";
            }

            pxPerMeterSum += localPPM * len;
            pxPerMeterWeight += len;
            distSum += b.estDistance;
            distCount++;

            /* ── 命中统计归属:按 人物速度 × 子弹速度 归档距离 ── */
            Segment gs = ps != null ? ps.nearest(b.estDistance) : null;
            b.grpBulletSpeed = gs != null ? gs.bulletSpeed : cfg.bulletRef;
            b.grpCharSpeed = b.hit ? b.charSpeed : (gs != null ? gs.charSpeed : 19f);
            b.atMs = g.get(0).tMs;

            rep.validBursts++;
            rep.burstList.add(b);

            /* ── 角度 / 视角偏移 / 预判大小:按这条弹道自己算一遍 ── */
            AngleSolver.Result ang = AngleSolver.burst(g, sampleSec,
                    g.get(0).frameW, g.get(0).frameH);
            if (ang.valid) {
                b.angleDeg = ang.headingDeg;
                b.slant = ang.slant;
                b.offsetDeg = ang.offsetDeg;
                rep.angleSamples++;
                rep.angleSum += ang.headingDeg;
                rep.slantSum += ang.slant;
                rep.offsetSum += ang.offsetDeg;
            }
        }

        if (rep.angleSamples > 0) {
            rep.angleAvgDeg = rep.angleSum / rep.angleSamples;
            rep.slantAvg = rep.slantSum / rep.angleSamples;
            rep.offsetAvgDeg = rep.offsetSum / rep.angleSamples;
            rep.log("交火方向角均值 " + Math.round(rep.angleAvgDeg) + "° · 斜向系数 "
                    + Math.round(rep.slantAvg * 100f) / 100f + " · 视角偏移均值 "
                    + Math.round(rep.offsetAvgDeg) + "°");
        }

        if (pxPerMeterWeight > 0) rep.pxPerMeter = (float) (pxPerMeterSum / pxPerMeterWeight);
        if (distCount > 0) rep.estDistance = (float) (distSum / distCount);

        rep.log("切出 " + rep.bursts + " 段弹道,有效 " + rep.validBursts + " 段");
        rep.log("平均像素当量 " + Math.round(rep.pxPerMeter) + " px/m");
    }

    private static boolean hasLeadIn(List<Analysis.Sample> g) {
        for (Analysis.Sample s : g) if (s.hasLead) return true;
        return false;
    }

    /* ================= 按分段汇总 ================= */

    private static void buildRows(ParamSet ps, Config cfg, Analysis.Report rep) {
        rep.rows.clear();
        if (ps == null || ps.segments.isEmpty()) return;

        List<Analysis.Burst> valid = new ArrayList<>();
        for (Analysis.Burst b : rep.burstList) if (b.valid) valid.add(b);

        for (Segment seg : ps.segments) {
            Analysis.SegRow row = new Analysis.SegRow();
            row.distance = seg.distance;
            row.bulletSpeed = seg.bulletSpeed;
            row.cur = seg.predict;

            double needSum = 0, csSum = 0;
            int n = 0, theory = 0;
            for (Analysis.Burst b : valid) {
                float gap = Math.abs(b.estDistance - seg.distance);
                if (gap > 45f) continue;                 // 距离差太远,不并入该段
                needSum += b.needPredict;
                csSum += b.charSpeed;
                n++;
                if (b.reject != null && b.reject.contains("理论")) theory++;
            }
            row.samples = n;
            if (n > 0) {
                row.need = Physics.round2((float) (needSum / n));
                row.charSpeed = Physics.round2((float) (csSum / n));
                row.diff = Physics.round2(row.need - row.cur);
                row.suggest = Physics.quantize(row.cur + Physics.quantize(row.diff));
                row.hDecay = Physics.hitSpeedBracket(row.charSpeed);
                row.sumVerdict = Physics.verdict(row.need, row.cur);
                row.theory = (theory == n);
            } else {
                // 该段没数据 → 给出理论参考值,标为待测
                row.need = Physics.round2(Physics.requiredPredict(ps, seg.distance,
                        seg.charSpeed, seg.bulletSpeed));
                row.charSpeed = seg.charSpeed;
                row.diff = Physics.round2(row.need - row.cur);
                row.suggest = Physics.quantize(row.cur + Physics.quantize(row.diff));
                row.hDecay = Physics.hitSpeedBracket(seg.charSpeed);
                row.sumVerdict = Physics.verdict(row.need, row.cur);
                row.theory = true;
            }
            rep.rows.add(row);
        }
    }

    private static long parseLong(String s) {
        if (s == null) return 0;
        try { return Long.parseLong(s.trim()); } catch (Throwable t) { return 0; }
    }

    /* ================= 总距离概括 + 命中统计 ================= */

    private static void buildDist(ParamSet ps, Config cfg, Analysis.Report rep) {
        DistStats.build(
                ps != null ? ps.segments : null,
                ps != null ? ps.totalDistance : 0f,
                cfg.bulletRef,
                rep);
    }
}

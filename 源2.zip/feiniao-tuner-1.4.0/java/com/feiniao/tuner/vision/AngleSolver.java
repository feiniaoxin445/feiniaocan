package com.feiniao.tuner.vision;

import com.feiniao.tuner.core.Analysis;
import com.feiniao.tuner.core.Physics;
import com.feiniao.tuner.core.Strategy;

import java.util.List;

/**
 * 角度 / 视角偏移解算 + 预判大小判定。
 *
 * 视频逐帧分析和实时屏幕识别共用这一套:
 *   · 目标运动方向角 heading —— 目标相对画面水平轴斜了多少(0° = 正横着跑,越接近 90° 越是朝你冲)
 *   · 视角偏移角 offset      —— 交火点偏离准星(画面中心)多少度
 *   · 斜向系数 slant         —— cos(heading),横向分量还剩多少,预判要按 1/slant 补
 *   · 预判大小 predictPx / predictBodies —— 这段飞行时间里目标横移了多少(像素 / 身位)
 *   · 大小档 size             —— 小 / 中 / 大
 *
 * 摄像机视场角默认按 70°(等效手机主摄竖屏横向),可在「思路」页里改。
 */
public final class AngleSolver {

    /** 视场角(度):整个画面宽度对应的角度,用来把像素偏移换算成角度 */
    public static volatile float FOV_DEG = 70f;

    public static final int SIZE_SMALL = 0;
    public static final int SIZE_MID = 1;
    public static final int SIZE_BIG = 2;

    private AngleSolver() {}

    /* ==================== 目标运动跟踪 ==================== */

    /** 帧间位移 → 速度矢量(平滑),实时识别用 */
    public static class Motion {
        public float vx, vy;        // px/s
        public float lastX = -1f, lastY = -1f;
        public long lastAt;
        public int frames;

        public boolean ready() {
            return frames >= 3 && (Math.abs(vx) + Math.abs(vy)) > 0.5f;
        }

        public void feed(float x, float y, long nowMs) {
            if (lastX >= 0f && nowMs > lastAt) {
                float dt = (nowMs - lastAt) / 1000f;
                if (dt > 0.004f && dt < 0.6f) {
                    float nvx = (x - lastX) / dt;
                    float nvy = (y - lastY) / dt;
                    vx = vx * 0.65f + nvx * 0.35f;
                    vy = vy * 0.65f + nvy * 0.35f;
                    frames++;
                }
            }
            lastX = x;
            lastY = y;
            lastAt = nowMs;
        }

        public void reset() {
            vx = 0f; vy = 0f;
            lastX = -1f; lastY = -1f; lastAt = 0;
            frames = 0;
        }

        public float speed() {
            return (float) Math.sqrt(vx * vx + vy * vy);
        }
    }

    /* ==================== 解算结果 ==================== */

    public static class Result {
        public boolean valid;
        public float targetX, targetY;
        public float offsetPx;        // 目标相对画面中心的横向偏移(px)
        public float offsetDeg;       // 视角偏移角(度)
        public float headingDeg;      // 目标运动方向角(相对水平,0~90)
        public float slant = 1f;      // 斜向系数 cos(heading)
        public float charSpeedPx;     // 目标横向速度(px/s)
        public float charSpeedGame;   // 换算回游戏里的速度档
        public float predictPx;       // 所需横向预判(px)
        public float predictBodies;   // 所需预判(身位)
        public int size = SIZE_SMALL;
        public int conf;              // 把握度 0~100
        public String why = "";

        public String sizeText() { return sizeName(size); }
    }

    public static String sizeName(int s) {
        if (s == SIZE_BIG) return "大";
        if (s == SIZE_MID) return "中";
        return "小";
    }

    /* ==================== 实时识别(屏幕 / 弹着点) ==================== */

    /**
     * @param frameW / frameH  识别用的画面尺寸
     * @param bulletX / bulletY 弹着点(红外弹),没有给 -1
     * @param targetX / targetY 目标(预判点),没有给 -1
     * @param motion   目标运动跟踪(可为 null)
     */
    public static Result solve(float frameW, float frameH,
                               float bulletX, float bulletY, boolean hasBullet,
                               float targetX, float targetY, boolean hasTarget,
                               Motion motion, float flightSec,
                               float pxPerMeter, float bodyWidth, float speedScale) {
        Result r = new Result();
        if (!hasTarget || frameW <= 1f) {
            r.valid = false;
            r.conf = 0;
            r.why = "没抓到目标点";
            return r;
        }
        r.valid = true;
        r.targetX = targetX;
        r.targetY = targetY;

        /* 视角偏移:目标离开画面中心多少度 */
        float focal = focalPx(frameW);
        r.offsetPx = targetX - frameW / 2f;
        r.offsetDeg = (float) Math.toDegrees(Math.atan2(r.offsetPx, focal));

        /* 目标运动方向角 + 斜向系数 */
        float vx = 0f, vy = 0f;
        boolean hasMotion = motion != null && motion.ready();
        if (hasMotion) {
            vx = motion.vx;
            vy = motion.vy;
            r.charSpeedPx = Math.abs(vx);
            float ax = Math.abs(vx), ay = Math.abs(vy);
            if (ax + ay > 0.5f) {
                r.headingDeg = (float) Math.toDegrees(Math.atan2(ay, ax));
                r.slant = (float) Math.cos(Math.toRadians(r.headingDeg));
                if (r.slant < 0.2f) r.slant = 0.2f;
            }
            r.conf = motion.frames >= 8 ? 85 : 70;
            r.why = "跟踪 " + motion.frames + " 帧定出方向角";
        } else if (hasBullet) {
            r.charSpeedPx = Math.abs(targetX - bulletX);
            r.conf = 45;
            r.why = "还没跟稳,先按弹着点与目标的横向差估";
        } else {
            r.charSpeedPx = 0f;
            r.conf = 25;
            r.why = "只有目标点,没有速度也没有弹着点,只能给位置";
        }

        /* 预判大小 */
        if (hasMotion && flightSec > 0.001f) {
            r.predictPx = r.charSpeedPx * flightSec;
        } else if (hasBullet) {
            r.predictPx = Math.abs(targetX - bulletX);
        }
        boolean ppmOk = pxPerMeter > 0.01f && bodyWidth > 0.01f;
        if (ppmOk) {
            r.predictBodies = r.predictPx / pxPerMeter / bodyWidth;
        }
        r.size = sizeOf(ppmOk ? r.predictBodies * 100f : r.predictPx, ppmOk);
        if (ppmOk && speedScale > 0.0001f && flightSec > 0.001f) {
            r.charSpeedGame = (r.charSpeedPx / pxPerMeter) / speedScale;
        }
        return r;
    }

    /** 预判大小档:有身位值就按身位判,没有就退回按像素 */
    public static int sizeOf(float v, boolean byBodies) {
        if (byBodies) {
            if (v < 50f) return SIZE_SMALL;
            if (v < 120f) return SIZE_MID;
            return SIZE_BIG;
        }
        if (v < 40f) return SIZE_SMALL;
        if (v < 110f) return SIZE_MID;
        return SIZE_BIG;
    }

    /** 视场角 → 焦距(像素):f = W / (2 tan(FOV/2)) */
    public static float focalPx(float frameW) {
        double half = Math.toRadians(Math.max(20f, Math.min(120f, FOV_DEG)) / 2.0);
        double t = Math.tan(half);
        if (t < 0.05) t = 0.05;
        return (float) (frameW / (2.0 * t));
    }

    /* ==================== 视频:单次交火解算 ==================== */

    /**
     * 对一段交火(连续弹道)解算方向角与视角偏移。
     * 用的是弹道自身的走向:弹道在画面上斜着走 = 这次是斜向交火。
     */
    public static Result burst(List<Analysis.Sample> g, float sampleSec, float frameW, float frameH) {
        Result r = new Result();
        if (g == null || g.size() < 3 || sampleSec <= 0f) {
            r.why = "帧数不足";
            return r;
        }
        Analysis.Sample a = g.get(0);
        Analysis.Sample b = g.get(g.size() - 1);

        float dx = b.bx - a.bx;
        float dy = b.by - a.by;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 1f) { r.why = "轨迹太短"; return r; }

        /* 弹道方向角:跟画面水平轴的夹角,折到 0~90 */
        float deg = (float) Math.toDegrees(Math.atan2(Math.abs(dy), Math.abs(dx)));
        r.headingDeg = Math.max(0f, Math.min(90f, deg));
        r.slant = (float) Math.cos(Math.toRadians(r.headingDeg));
        if (r.slant < 0.2f) r.slant = 0.2f;

        /* 视角偏移:整段弹道中点离画面中心多少度 */
        float midX = (a.bx + b.bx) / 2f;
        float midY = (a.by + b.by) / 2f;
        float fw = frameW > 1f ? frameW : 1080f;
        float fh = frameH > 1f ? frameH : 1920f;
        r.targetX = midX;
        r.targetY = midY;
        r.offsetPx = midX - fw / 2f;
        float focal = focalPx(fw);
        r.offsetDeg = (float) Math.toDegrees(Math.atan2(r.offsetPx, focal));
        r.valid = true;

        /* 预判:有预判点就用预判点位移,否则用弹着点 */
        boolean hasLead = false;
        float firstX = 0f, lastX = 0f;
        for (Analysis.Sample s : g) {
            if (!s.hasLead) continue;
            if (!hasLead) { firstX = s.lx; hasLead = true; }
            lastX = s.lx;
        }
        float totalSec = (g.size() - 1) * sampleSec;
        if (hasLead) {
            r.predictPx = Math.abs(lastX - firstX);
            if (totalSec > 0.001f) r.charSpeedPx = r.predictPx / totalSec;
            r.conf = 85;
            r.why = "有预判点轨迹,按预判点横移算";
        } else {
            r.predictPx = 0f;
            r.charSpeedPx = len / Math.max(0.001f, totalSec);
            r.conf = 55;
            r.why = "没有预判点,只有弹道方向";
        }
        return r;
    }

    /** 角度补偿系数:斜向交火时横向分量损失,预判按 1/cos 补 */
    public static float slantComp(float headingDeg) {
        return Strategy.angleFactor(headingDeg);
    }

    /** 一行字,给 HUD / 报告用 */
    public static String line(Result r) {
        if (r == null || !r.valid) return "角度 —";
        return "方向角 " + Physics.fmt(r.headingDeg, 1) + "°   视角偏移 "
                + (r.offsetDeg >= 0 ? "+" : "") + Physics.fmt(r.offsetDeg, 1) + "°   斜向系数 "
                + Physics.fmt(r.slant, 2);
    }
}

package com.feiniao.tuner.vision;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Build;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

import com.feiniao.tuner.Icon;
import com.feiniao.tuner.Prefs;
import com.feiniao.tuner.Ui;

import java.util.ArrayList;
import java.util.List;

/** 屏幕识别悬浮层:标记框 + 遥测面板 + 拖拽控制球 */
public final class OverlayHud {

    public interface Ctrl {
        void onStop();
    }

    public static class Marker {
        public float x, y;
        public int w, h;
        public int type;   // 0 红 1 紫
    }

    private final Context ctx;
    private final WindowManager wm;
    private HudView view;
    private ControlView ctrl;

    private OverlayHud(Context c) {
        this.ctx = c;
        this.wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
    }

    public static OverlayHud create(Context c, final Ctrl cb) {
        final OverlayHud h = new OverlayHud(c);
        h.view = h.new HudView(c);
        h.ctrl = h.new ControlView(c, cb);

        WindowManager.LayoutParams lp = baseParams();
        lp.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.MATCH_PARENT;
        lp.format = PixelFormat.TRANSLUCENT;

        WindowManager.LayoutParams cl = baseParams();
        cl.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        cl.gravity = Gravity.TOP | Gravity.START;
        int size = Ui.dp(c, 46);
        cl.width = size;
        cl.height = size;
        cl.x = Ui.dp(c, 12);
        cl.y = Ui.dp(c, 120);
        cl.format = PixelFormat.TRANSLUCENT;

        try {
            h.wm.addView(h.view, lp);
            h.wm.addView(h.ctrl, cl);
        } catch (Throwable t) {
            return h;
        }
        return h;
    }

    private static WindowManager.LayoutParams baseParams() {
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        return lp;
    }

    public void update(List<Marker> marks, List<String> lines,
                       float cx, float cy, float leadX, float leadY,
                       float bulletX, float bulletY) {
        if (view == null) return;
        view.setData(marks, lines, cx, cy, leadX, leadY, bulletX, bulletY);
        try { view.postInvalidate(); } catch (Throwable ignored) {}
    }

    public void remove() {
        try { if (view != null) wm.removeView(view); } catch (Throwable ignored) {}
        try { if (ctrl != null) wm.removeView(ctrl); } catch (Throwable ignored) {}
        view = null;
        ctrl = null;
    }

    /* ==================== 遥测层 ==================== */

    private class HudView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
        private List<Marker> marks = new ArrayList<>();
        private List<String> lines = new ArrayList<>();
        private float cx, cy, leadX = -1, leadY = -1, bx = -1, by = -1;
        private final RectF panel = new RectF();

        HudView(Context c) {
            super(c);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Ui.dp(c, 2));
            tp.setTextSize(Ui.sp(c, 11.5f));
            tp.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            setLayerType(LAYER_TYPE_HARDWARE, null);
        }

        void setData(List<Marker> m, List<String> l, float cx, float cy,
                     float lx, float ly, float bx, float by) {
            marks = m == null ? new ArrayList<Marker>() : m;
            lines = l == null ? new ArrayList<String>() : l;
            this.cx = cx;
            this.cy = cy;
            this.leadX = lx;
            this.leadY = ly;
            this.bx = bx;
            this.by = by;
        }

        @Override
        protected void onDraw(Canvas cv) {
            super.onDraw(cv);
            if (!Prefs.getB("cfg_hud", true)) return;

            // 标记框
            for (Marker m : marks) {
                int col = m.type == ColorDetect.TYPE_RED ? 0xFFF87171 : 0xFFC58AF9;
                p.setColor(col);
                p.setStyle(Paint.Style.STROKE);
                float hw = m.w / 2f, hh = m.h / 2f;
                cv.drawRoundRect(new RectF(m.x - hw, m.y - hh, m.x + hw, m.y + hh),
                        Ui.dp(ctx, 3), Ui.dp(ctx, 3), p);
                // 四角加粗
                p.setStrokeWidth(Ui.dp(ctx, 3));
                float arm = Math.max(Ui.dp(ctx, 5), hw * 0.5f);
                cv.drawLine(m.x - hw, m.y - hh, m.x - hw + arm, m.y - hh, p);
                cv.drawLine(m.x - hw, m.y - hh, m.x - hw, m.y - hh + arm, p);
                cv.drawLine(m.x + hw, m.y - hh, m.x + hw - arm, m.y - hh, p);
                cv.drawLine(m.x + hw, m.y - hh, m.x + hw, m.y - hh + arm, p);
                p.setStrokeWidth(Ui.dp(ctx, 2));
            }

            // 准星
            if (Prefs.getB("cfg_cross", true)) {
                p.setColor(0x99A8C7FA);
                float r = Ui.dp(ctx, 14);
                cv.drawCircle(cx, cy, r, p);
                cv.drawLine(cx - r * 1.7f, cy, cx - r * 0.4f, cy, p);
                cv.drawLine(cx + r * 0.4f, cy, cx + r * 1.7f, cy, p);
                cv.drawLine(cx, cy - r * 1.7f, cx, cy - r * 0.4f, p);
                cv.drawLine(cx, cy + r * 0.4f, cx, cy + r * 1.7f, p);
            }

            // 预判连线
            if (leadX >= 0 && Prefs.getB("cfg_link", true)) {
                p.setColor(0xCCC58AF9);
                p.setStrokeWidth(Ui.dp(ctx, 2));
                cv.drawLine(cx, cy, leadX, leadY, p);
                p.setStyle(Paint.Style.FILL);
                cv.drawCircle(leadX, leadY, Ui.dp(ctx, 4), p);
                p.setStyle(Paint.Style.STROKE);
            }
            if (bx >= 0) {
                p.setColor(0xCCF87171);
                p.setStyle(Paint.Style.FILL);
                cv.drawCircle(bx, by, Ui.dp(ctx, 3.5f), p);
                p.setStyle(Paint.Style.STROKE);
            }

            // 遥测面板
            if (!Prefs.getB("cfg_panel", true) || lines.isEmpty()) return;
            float pad = Ui.dp(ctx, 10);
            float lh = Ui.sp(ctx, 15.5f);
            float maxW = 0;
            for (String s : lines) maxW = Math.max(maxW, tp.measureText(s));
            float pw = maxW + pad * 2;
            float ph = lines.size() * lh + pad * 1.6f;

            panel.set(Ui.dp(ctx, 10), Ui.dp(ctx, 52), Ui.dp(ctx, 10) + pw, Ui.dp(ctx, 52) + ph);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xCC0E0F12);
            cv.drawRoundRect(panel, Ui.dp(ctx, 12), Ui.dp(ctx, 12), p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Ui.dp(ctx, 1));
            p.setColor(0x55373C44);
            cv.drawRoundRect(panel, Ui.dp(ctx, 12), Ui.dp(ctx, 12), p);

            tp.setColor(Color.WHITE);
            float y = Ui.dp(ctx, 52) + pad * 0.8f + lh * 0.78f;
            for (int i = 0; i < lines.size(); i++) {
                tp.setColor(i == 0 ? 0xFFA8C7FA : 0xFFE6E8EC);
                cv.drawText(lines.get(i), Ui.dp(ctx, 10) + pad, y, tp);
                y += lh;
            }
        }
    }

    /* ==================== 控制球 ==================== */

    private class ControlView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Ctrl cb;
        private float downX, downY;
        private int startX, startY;
        private boolean moved;

        ControlView(Context c, Ctrl cb) {
            super(c);
            this.cb = cb;
            p.setStyle(Paint.Style.FILL);
        }

        @Override
        protected void onDraw(Canvas cv) {
            int w = getWidth();
            p.setColor(0xD91A1C20);
            cv.drawCircle(w / 2f, w / 2f, w / 2f, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Ui.dp(ctx, 1.5f));
            p.setColor(0xFF4ADE80);
            cv.drawCircle(w / 2f, w / 2f, w / 2f - Ui.dp(ctx, 2), p);
            p.setStyle(Paint.Style.FILL);
            Icon.draw(cv, Icon.CROSSHAIR, 0xFF4ADE80, w * 0.52f);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            WindowManager.LayoutParams lp = (WindowManager.LayoutParams) getLayoutParams();
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = e.getRawX();
                    downY = e.getRawY();
                    startX = lp.x;
                    startY = lp.y;
                    moved = false;
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    int dx = (int) (e.getRawX() - downX);
                    int dy = (int) (e.getRawY() - downY);
                    if (Math.abs(dx) > Ui.dp(ctx, 6) || Math.abs(dy) > Ui.dp(ctx, 6)) moved = true;
                    lp.x = startX + dx;
                    lp.y = startY + dy;
                    try { wm.updateViewLayout(this, lp); } catch (Throwable ignored) {}
                    return true;
                }
                case MotionEvent.ACTION_UP:
                    if (!moved) {
                        boolean on = Prefs.getB("cfg_hud", true);
                        Prefs.setB("cfg_hud", !on);
                        if (view != null) view.postInvalidate();
                    }
                    return true;
            }
            return super.onTouchEvent(e);
        }
    }
}

package com.feiniao.tuner.vision;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.widget.Toast;

import com.feiniao.tuner.MainActivity;
import com.feiniao.tuner.Prefs;
import com.feiniao.tuner.core.Physics;
import com.feiniao.tuner.core.Reports;
import com.feiniao.tuner.model.ParamSet;
import com.feiniao.tuner.model.ParamStore;
import com.feiniao.tuner.model.Segment;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

/**
 * 屏幕识别引擎(前台服务)
 * MediaProjection → VirtualDisplay → ImageReader → 颜色识别 → 悬浮 HUD
 *
 * 采集与识别全程复用同一块像素缓冲与位图,避免逐帧分配造成 GC 抖动。
 */
public class ScreenEngine extends Service {

    public static final String ACTION_START = "com.feiniao.tuner.START";
    public static final String ACTION_STOP = "com.feiniao.tuner.STOP";
    public static volatile boolean RUNNING = false;

    private static final String CH_ID = "feiniao_engine";
    private static final int CH_NOTI = 0x5F10;

    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private HandlerThread thread;
    private Handler handler;
    private OverlayHud hud;

    private int screenW, screenH, density;
    private ColorDetect.Cfg cfg = new ColorDetect.Cfg();

    /* 复用缓冲 */
    private int[] frameBuf;
    private Bitmap frameBmp;
    private int frameW, frameH;

    private long lastFrameAt = 0;
    private long fpsWindowStart = 0;
    private int fpsCounter = 0;
    private float liveFps = 0;

    private float lastLeadX = -1, lastLeadY = -1;
    private long lastLeadAt = 0;
    private float leadSpeedPx = 0;

    /** 目标运动跟踪 + 最近一帧的角度解算结果(角度 / 视角偏移 / 预判大小) */
    private final AngleSolver.Motion motion = new AngleSolver.Motion();
    private AngleSolver.Result liveAngle;

    private ParamSet params;

    @Override
    public void onCreate() {
        super.onCreate();
        Prefs.init(this);
        thread = new HandlerThread("feiniao-screen", android.os.Process.THREAD_PRIORITY_DISPLAY);
        thread.start();
        handler = new Handler(thread.getLooper());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;

        if (ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }

        startForegroundCompat();

        if (projection != null) return START_STICKY;

        int code = intent.getIntExtra("code", 0);
        Intent data = intent.getParcelableExtra("data");
        if (data == null) {
            toast("屏幕采集授权数据无效,请重新授权");
            stopSelf();
            return START_NOT_STICKY;
        }

        try {
            MediaProjectionManager mpm =
                    (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            projection = mpm.getMediaProjection(code, data);
        } catch (Throwable t) {
            toast("无法建立屏幕采集:" + t.getClass().getSimpleName());
            stopSelf();
            return START_NOT_STICKY;
        }
        if (projection == null) {
            toast("屏幕采集被系统拒绝");
            stopSelf();
            return START_NOT_STICKY;
        }

        projection.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                stopSelf();
            }
        }, handler);

        loadConfig();
        setupDisplay();
        if (hud == null) {
            hud = OverlayHud.create(this, new OverlayHud.Ctrl() {
                @Override
                public void onStop() { stopSelf(); }
            });
        }
        RUNNING = true;
        Prefs.setB("engine_on", true);
        return START_STICKY;
    }

    /* ---------------- 采集链路 ---------------- */

    private void loadConfig() {
        params = ParamStore.loadCurrent(this);
        WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        if (Build.VERSION.SDK_INT >= 30) {
            android.graphics.Rect b = wm.getCurrentWindowMetrics().getBounds();
            screenW = b.width();
            screenH = b.height();
        } else {
            DisplayMetrics dm = new DisplayMetrics();
            wm.getDefaultDisplay().getRealMetrics(dm);
            screenW = dm.widthPixels;
            screenH = dm.heightPixels;
        }
        density = getResources().getDisplayMetrics().densityDpi;

        cfg.workWidth = Prefs.getI("cfg_work", 480);
        cfg.redHueTol = Prefs.getF("cfg_redhue", 15f);
        cfg.purpleLo = Prefs.getF("cfg_plo", 256f);
        cfg.purpleHi = Prefs.getF("cfg_phi", 326f);
        cfg.minSat = Prefs.getF("cfg_sat", 0.40f);
        cfg.minVal = Prefs.getF("cfg_val", 0.38f);
        cfg.minBlobHits = Prefs.getI("cfg_minblob", 12);
        cfg.detectRed = Prefs.getB("cfg_red", true);
        cfg.detectPurple = Prefs.getB("cfg_purple", true);
    }

    private void setupDisplay() {
        reader = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 3);
        reader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
            @Override
            public void onImageAvailable(ImageReader r) {
                process(r);
            }
        }, handler);

        try {
            display = projection.createVirtualDisplay("feiniao", screenW, screenH, density,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    reader.getSurface(), null, handler);
        } catch (Throwable t) {
            toast("虚拟屏幕创建失败");
            stopSelf();
        }
    }

    private void process(ImageReader r) {
        long now = android.os.SystemClock.uptimeMillis();
        int minGap = Math.max(20, 1000 / Math.max(5, Prefs.getI("cfg_fps", 30)));
        if (now - lastFrameAt < minGap) {
            Image skip = r.acquireLatestImage();
            if (skip != null) skip.close();
            return;
        }
        lastFrameAt = now;

        Image img = null;
        try {
            img = r.acquireLatestImage();
            if (img == null) return;
            Bitmap bmp = grabFrame(img);
            if (bmp == null) return;
            List<ColorDetect.Blob> blobs = ColorDetect.detect(bmp, cfg);
            if (blobs == null) blobs = new ArrayList<>();
            render(blobs, now);
        } catch (Throwable ignored) {
        } finally {
            if (img != null) try { img.close(); } catch (Throwable ignored) {}
        }

        fpsCounter++;
        if (fpsWindowStart == 0) fpsWindowStart = now;
        if (now - fpsWindowStart >= 1000) {
            liveFps = fpsCounter * 1000f / (now - fpsWindowStart);
            fpsCounter = 0;
            fpsWindowStart = now;
        }
    }

    /** ImageReader → 复用位图(按 stride 抽样,零逐帧分配) */
    private Bitmap grabFrame(Image img) {
        int w = img.getWidth(), h = img.getHeight();
        Image.Plane[] planes = img.getPlanes();
        if (planes == null || planes.length == 0) return null;
        ByteBuffer buf = planes[0].getBuffer();
        int rowStride = planes[0].getRowStride();
        int pixelStride = planes[0].getPixelStride();

        int work = Math.max(160, cfg.workWidth);
        int step = Math.max(1, (int) Math.ceil(w / (double) work));
        int sw = Math.max(32, w / step);
        int sh = Math.max(32, h / step);

        if (frameBuf == null || frameBuf.length < sw * sh) frameBuf = new int[sw * sh];
        if (frameBmp == null || frameBmp.isRecycled()
                || frameBmp.getWidth() != sw || frameBmp.getHeight() != sh) {
            if (frameBmp != null) {
                try { frameBmp.recycle(); } catch (Throwable ignored) {}
            }
            frameBmp = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888);
        }

        int[] px = frameBuf;
        int base = buf.position();
        int limit = buf.limit();

        for (int y = 0; y < sh; y++) {
            int rowOff = base + (y * step) * rowStride;
            int outOff = y * sw;
            for (int x = 0; x < sw; x++) {
                int off = rowOff + x * step * pixelStride;
                if (off + 2 >= limit) { px[outOff + x] = 0; continue; }
                int r = buf.get(off) & 0xFF;
                int g = buf.get(off + 1) & 0xFF;
                int b = buf.get(off + 2) & 0xFF;
                px[outOff + x] = 0xFF000000 | (r << 16) | (g << 8) | b;
            }
        }
        try {
            frameBmp.setPixels(px, 0, sw, 0, 0, sw, sh);
        } catch (Throwable t) {
            return null;
        }
        frameW = sw;
        frameH = sh;
        return frameBmp;
    }

    /** 识别坐标系 → 屏幕坐标系(悬浮窗按屏幕坐标绘制) */
    private float coordScale() {
        if (frameW <= 0) return 1f;
        return screenW / (float) frameW;
    }

    /* ---------------- 结果渲染 ---------------- */

    private void render(List<ColorDetect.Blob> blobs, long now) {
        if (hud == null) return;
        float k = coordScale();

        List<OverlayHud.Marker> marks = new ArrayList<>();
        ColorDetect.Blob bullet = pick(blobs, ColorDetect.TYPE_RED);
        ColorDetect.Blob lead = pick(blobs, ColorDetect.TYPE_PURPLE);

        if (Prefs.getB("cfg_showbox", true)) {
            for (ColorDetect.Blob b : blobs) {
                OverlayHud.Marker m = new OverlayHud.Marker();
                m.x = b.cx * k;
                m.y = b.cy * k;
                m.w = Math.max(18, Math.round(b.boxW * k));
                m.h = Math.max(18, Math.round(b.boxH * k));
                m.type = b.type;
                marks.add(m);
            }
        }

        float leadScreenX = -1, leadScreenY = -1;
        if (lead != null) {
            leadScreenX = lead.cx * k;
            leadScreenY = lead.cy * k;
            if (lastLeadX >= 0 && now > lastLeadAt) {
                float dt = (now - lastLeadAt) / 1000f;
                if (dt > 0.004f && dt < 0.5f) {
                    float v = Math.abs(leadScreenX - lastLeadX) / dt;
                    leadSpeedPx = leadSpeedPx * 0.7f + v * 0.3f;
                }
            }
            lastLeadX = leadScreenX;
            lastLeadY = leadScreenY;
            lastLeadAt = now;
        }

        Segment seg = lockSegment();
        float ppm = resolvePxPerMeter();
        float liveCharSpeed = ppm > 0
                ? (leadSpeedPx / ppm) / Math.max(0.001f, params.speedScale) : 0;

        List<String> lines = new ArrayList<>();
        lines.add("飞鸟调参 · 识别中  " + Math.round(liveFps) + "fps");
        lines.add("子弹 " + (bullet == null ? "—" : "命中")
                + "   预判点 " + (lead == null ? "—" : "命中"));

        if (seg != null) {
            float need = Physics.requiredPredict(params, seg.distance, seg.charSpeed, seg.bulletSpeed);
            int verdict = Physics.verdict(need, seg.predict);
            lines.add("锁定段 " + Segment.trim(seg.distance) + "m   参数 "
                    + Physics.fmt(seg.predict, 2) + " 身位");
            lines.add("理论 " + Physics.fmt(need, 2) + " 身位   "
                    + Physics.verdictText(verdict)
                    + (verdict == 0 ? "" : " " + Physics.fmt(Math.abs(need - seg.predict), 2)));
            lines.add("人物速度 " + Physics.fmt(seg.charSpeed, 1)
                    + "   横向衰减 " + (Physics.hitSpeedBracket(seg.charSpeed) ? "需调整" : "无需动"));
        }

        if (liveCharSpeed > 0) {
            lines.add("实时人物速度 " + Physics.fmt(liveCharSpeed, 1)
                    + "   横向衰减 " + (Physics.hitSpeedBracket(liveCharSpeed) ? "需调整" : "无需动"));
        }

        if (lead != null && ppm > 0) {
            float dx = leadScreenX - screenW / 2f;
            float bodies = Math.abs(dx) / ppm / Math.max(0.01f, params.bodyWidth);
            lines.add("预判偏移 " + Math.round(Math.abs(dx)) + "px ≈ "
                    + Physics.fmt(bodies, 2) + " 身位");
        }

        /* ---- 角度 / 视角偏移 / 预判大小 ---- */
        if (lead != null) motion.feed(leadScreenX, leadScreenY, now);
        else motion.reset();

        float flightSec = 0f;
        if (seg != null) {
            flightSec = Physics.flightTime(seg.distance,
                    seg.bulletSpeed > 1f ? seg.bulletSpeed : params.bulletRef);
        }
        AngleSolver.Result ang = AngleSolver.solve(
                screenW, screenH,
                bullet != null ? bullet.cx * k : -1f,
                bullet != null ? bullet.cy * k : -1f, bullet != null,
                leadScreenX, leadScreenY, lead != null,
                motion, flightSec, ppm, params.bodyWidth, params.speedScale);
        liveAngle = ang;
        if (ang.valid) {
            lines.add(AngleSolver.line(ang));
            lines.add("预判大小 " + ang.sizeText()
                    + (ppm > 0 ? "  " + Physics.fmt(ang.predictBodies, 2) + " 身位" : "")
                    + (ang.charSpeedGame > 0 ? "   目标速度 "
                    + Physics.fmt(ang.charSpeedGame, 1) + " 档" : ""));
            if (ang.headingDeg > 8f) {
                lines.add("斜向交火 → 预判按 1/cos 补 "
                        + Physics.fmt((AngleSolver.slantComp(ang.headingDeg) - 1f) * 100f, 1) + "%");
            }
            /* 角度同步给「思路」页的推演用 */
            Reports.liveAngleDeg = ang.headingDeg;
            Reports.liveAngleSamples++;
        }

        hud.update(marks, lines, screenW / 2f, screenH / 2f,
                leadScreenX, leadScreenY,
                bullet != null ? bullet.cx * k : -1,
                bullet != null ? bullet.cy * k : -1);
    }

    private ColorDetect.Blob pick(List<ColorDetect.Blob> blobs, int type) {
        ColorDetect.Blob best = null;
        for (ColorDetect.Blob b : blobs) {
            if (b.type != type) continue;
            if (best == null || b.hits > best.hits) best = b;
        }
        return best;
    }

    private Segment lockSegment() {
        if (params == null || params.segments.isEmpty()) return null;
        float lock = Prefs.getF("lock_distance", -1f);
        if (lock > 0) return params.nearest(lock);
        return params.nearest(params.totalDistance * 0.5f);
    }

    private float resolvePxPerMeter() {
        float manual = Prefs.getF("px_per_meter", 0f);
        if (manual > 0) return manual;
        return params != null ? params.pxPerMeter : 0f;
    }

    /* ---------------- 生命周期 ---------------- */

    @Override
    public void onDestroy() {
        RUNNING = false;
        Prefs.setB("engine_on", false);
        try { if (hud != null) hud.remove(); } catch (Throwable ignored) {}
        hud = null;
        try { if (display != null) display.release(); } catch (Throwable ignored) {}
        display = null;
        try { if (reader != null) reader.close(); } catch (Throwable ignored) {}
        reader = null;
        try { if (projection != null) projection.stop(); } catch (Throwable ignored) {}
        projection = null;
        try { if (frameBmp != null) frameBmp.recycle(); } catch (Throwable ignored) {}
        frameBmp = null;
        frameBuf = null;
        try { if (thread != null) thread.quitSafely(); } catch (Throwable ignored) {}
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    /* ---------------- 通知 ---------------- */

    private void startForegroundCompat() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CH_ID, "屏幕识别引擎",
                    NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }

        PendingIntent pi = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class),
                Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CH_ID)
                : new Notification.Builder(this);
        Notification n = b.setContentTitle("飞鸟调参 · 屏幕识别运行中")
                .setContentText("正在识别红/紫子弹标记并实时推算预判")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .setContentIntent(pi)
                .build();

        if (Build.VERSION.SDK_INT >= 29) {
            try {
                startForeground(CH_NOTI, n,
                        0x00000020 /* FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION */);
            } catch (Throwable t) {
                try { startForeground(CH_NOTI, n); } catch (Throwable ignored) {}
            }
        } else {
            startForeground(CH_NOTI, n);
        }
    }

    private void toast(final String s) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    Toast.makeText(ScreenEngine.this, s, Toast.LENGTH_SHORT).show();
                } catch (Throwable ignored) {}
            }
        });
    }

    /* ---------------- 对外入口 ---------------- */

    public static void start(Context c, int code, Intent data) {
        Intent i = new Intent(c, ScreenEngine.class);
        i.setAction(ACTION_START);
        i.putExtra("code", code);
        i.putExtra("data", data);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i);
        else c.startService(i);
    }

    public static void stop(Context c) {
        Intent i = new Intent(c, ScreenEngine.class);
        i.setAction(ACTION_STOP);
        try {
            c.startService(i);
        } catch (Throwable ignored) {}
        c.stopService(new Intent(c, ScreenEngine.class));
    }

    public static boolean canOverlay(Context c) {
        return Build.VERSION.SDK_INT < 23 || android.provider.Settings.canDrawOverlays(c);
    }
}

package com.feiniao.tuner.vision;

import android.graphics.Bitmap;

import java.util.ArrayList;
import java.util.List;

/**
 * 红 / 紫 目标颜色识别引擎。
 *
 * 流程:降采样 → 一次遍历 HSV 阈值分流 → 网格聚类 → 4 邻域连通域 → 重心输出。
 * 单帧开销在毫秒级,可同时支撑逐帧视频分析与实时屏幕采集。
 */
public final class ColorDetect {

    public static final int TYPE_RED = 0;
    public static final int TYPE_PURPLE = 1;

    public static class Blob {
        public float cx, cy;   // 已换算回原图坐标
        public int hits;       // 命中像素数(降采样后)
        public int type;
        public int boxW, boxH;

        public float area() { return hits; }
    }

    /** 可调识别参数 */
    public static class Cfg {
        public float redHueTol = 15f;
        public float purpleLo = 256f;
        public float purpleHi = 326f;
        public float minSat = 0.40f;
        public float minVal = 0.38f;
        public int cell = 4;
        public int minCellHits = 3;
        public int minBlobHits = 12;
        public int maxBlobs = 24;
        public boolean detectRed = true;
        public boolean detectPurple = true;
        public int workWidth = 480;

        public Cfg copy() {
            Cfg c = new Cfg();
            c.redHueTol = redHueTol;
            c.purpleLo = purpleLo;
            c.purpleHi = purpleHi;
            c.minSat = minSat;
            c.minVal = minVal;
            c.cell = cell;
            c.minCellHits = minCellHits;
            c.minBlobHits = minBlobHits;
            c.maxBlobs = maxBlobs;
            c.detectRed = detectRed;
            c.detectPurple = detectPurple;
            c.workWidth = workWidth;
            return c;
        }
    }

    private ColorDetect() {}

    /** 对一帧做检测;src 不会被回收 */
    public static List<Blob> detect(Bitmap src, Cfg cfg) {
        List<Blob> out = new ArrayList<>();
        if (src == null || src.getWidth() <= 2 || src.getHeight() <= 2) return out;
        if (!cfg.detectRed && !cfg.detectPurple) return out;

        int W = src.getWidth(), H = src.getHeight();
        int sw = Math.max(64, Math.min(cfg.workWidth, W));
        float k = W / (float) sw;
        int sh = Math.max(8, Math.round(H / k));

        Bitmap small = null;
        int[] px;
        try {
            small = Bitmap.createScaledBitmap(src, sw, sh, false);
            px = new int[sw * sh];
            small.getPixels(px, 0, sw, 0, 0, sw, sh);
        } catch (Throwable t) {
            if (small != null && small != src) recycle(small);
            return out;
        }
        // 尺寸一致时 createScaledBitmap 会原样返回 src,不能回收调用方的位图
        if (small != src) recycle(small);

        int cell = Math.max(2, cfg.cell);
        int gw = Math.max(1, (sw + cell - 1) / cell);
        int gh = Math.max(1, (sh + cell - 1) / cell);
        int gn = gw * gh;

        int[] redCell = cfg.detectRed ? new int[gn] : null;
        int[] purCell = cfg.detectPurple ? new int[gn] : null;

        for (int y = 0; y < sh; y++) {
            int rowBase = y * sw;
            int gRow = (y / cell) * gw;
            for (int x = 0; x < sw; x++) {
                int c = px[rowBase + x];
                if (((c >>> 24) & 0xFF) < 96) continue;
                int r = (c >> 16) & 0xFF;
                int g = (c >> 8) & 0xFF;
                int b = c & 0xFF;

                int mx = r > g ? (r > b ? r : b) : (g > b ? g : b);
                int mn = r < g ? (r < b ? r : b) : (g < b ? g : b);
                int d = mx - mn;
                if (d < 24) continue;
                float v = mx / 255f;
                if (v < cfg.minVal) continue;
                float s = d / (float) mx;
                if (s < cfg.minSat) continue;

                float h;
                if (mx == r) h = 60f * (((g - b) / (float) d) % 6f);
                else if (mx == g) h = 60f * (((b - r) / (float) d) + 2f);
                else h = 60f * (((r - g) / (float) d) + 4f);
                if (h < 0) h += 360f;

                int gi = gRow + (x / cell);
                if (redCell != null && (h <= cfg.redHueTol || h >= 360f - cfg.redHueTol)) {
                    redCell[gi]++;
                } else if (purCell != null && h >= cfg.purpleLo && h <= cfg.purpleHi) {
                    purCell[gi]++;
                }
            }
        }

        if (redCell != null) components(redCell, gw, gh, cell, k, cfg, TYPE_RED, out);
        if (purCell != null) components(purCell, gw, gh, cell, k, cfg, TYPE_PURPLE, out);

        java.util.Collections.sort(out, new java.util.Comparator<Blob>() {
            @Override
            public int compare(Blob a, Blob b) { return Integer.compare(b.hits, a.hits); }
        });
        if (out.size() > cfg.maxBlobs) return new ArrayList<>(out.subList(0, cfg.maxBlobs));
        return out;
    }

    /** 网格上的 4 邻域连通域 */
    private static void components(int[] cells, int gw, int gh, int cell, float k,
                                   Cfg cfg, int type, List<Blob> out) {
        byte[] seen = new byte[gw * gh];
        int[] stack = new int[gw * gh];
        for (int i = 0; i < gw * gh; i++) {
            if (seen[i] == 1 || cells[i] < cfg.minCellHits) continue;
            int sp = 0;
            stack[sp++] = i;
            seen[i] = 1;
            long hits = 0;
            double sx = 0, sy = 0;
            int minX = gw, maxX = -1, minY = gh, maxY = -1;
            while (sp > 0) {
                int cur = stack[--sp];
                int cx = cur % gw, cy = cur / gw;
                int w = cells[cur];
                hits += w;
                sx += cx * (double) w;
                sy += cy * (double) w;
                if (cx < minX) minX = cx;
                if (cx > maxX) maxX = cx;
                if (cy < minY) minY = cy;
                if (cy > maxY) maxY = cy;

                if (cx > 0 && seen[cur - 1] == 0 && cells[cur - 1] >= cfg.minCellHits) {
                    seen[cur - 1] = 1; stack[sp++] = cur - 1;
                }
                if (cx < gw - 1 && seen[cur + 1] == 0 && cells[cur + 1] >= cfg.minCellHits) {
                    seen[cur + 1] = 1; stack[sp++] = cur + 1;
                }
                if (cy > 0 && seen[cur - gw] == 0 && cells[cur - gw] >= cfg.minCellHits) {
                    seen[cur - gw] = 1; stack[sp++] = cur - gw;
                }
                if (cy < gh - 1 && seen[cur + gw] == 0 && cells[cur + gw] >= cfg.minCellHits) {
                    seen[cur + gw] = 1; stack[sp++] = cur + gw;
                }
            }
            if (hits < cfg.minBlobHits) continue;

            float cxf = (float) (sx / hits * cell + cell / 2f);
            float cyf = (float) (sy / hits * cell + cell / 2f);

            Blob b = new Blob();
            b.type = type;
            b.hits = (int) hits;
            b.cx = cxf * k;
            b.cy = cyf * k;
            b.boxW = Math.max(1, Math.round((maxX - minX + 1) * cell * k));
            b.boxH = Math.max(1, Math.round((maxY - minY + 1) * cell * k));
            out.add(b);
        }
    }

    public static void recycle(Bitmap b) {
        try { if (b != null && !b.isRecycled()) b.recycle(); } catch (Throwable ignored) {}
    }
}

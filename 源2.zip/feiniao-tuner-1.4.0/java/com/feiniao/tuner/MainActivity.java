package com.feiniao.tuner;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.feiniao.tuner.glass.LiquidBackdrop;
import com.feiniao.tuner.glass.LiquidGlass;
import com.feiniao.tuner.page.AboutPage;
import com.feiniao.tuner.page.BackupPage;
import com.feiniao.tuner.page.Host;
import com.feiniao.tuner.page.Page;
import com.feiniao.tuner.page.ParamPage;
import com.feiniao.tuner.page.ReplacePage;
import com.feiniao.tuner.page.StrategyPage;
import com.feiniao.tuner.page.TunePage;
import com.feiniao.tuner.root.Shell;
import com.feiniao.tuner.vision.ScreenEngine;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity implements Host {

    private static final int REQ_PROJ = 9001;
    private static final int REQ_NOTI = 9002;

    private static final int[] NAV_ICONS = {
            Icon.SLIDERS, Icon.CROSSHAIR, Icon.BRAIN, Icon.SWAP, Icon.BACKUP, Icon.INFO
    };
    private static final String[] NAV_LABELS = {"参数", "调参", "思路", "换参", "备份", "说明"};

    private FrameLayout content;
    private LinearLayout navBar;
    private TextView titleView, rootChip, engineChip;

    private Page[] pages;
    private View[] views;
    private Icon.IconView[] navIcons;
    private TextView[] navLabels;
    private LinearLayout[] navPills;
    private int current = 0;

    private final Map<Integer, Page> pending = new HashMap<>();
    private Runnable pendingOverlay;

    /** 同一个进程里只播一次开场动画,切后台回来不再重播 */
    private static boolean SPLASH_PLAYED = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Prefs.init(this);

        Window w = getWindow();
        w.setStatusBarColor(Ui.BG);
        w.setNavigationBarColor(Ui.BG);
        w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);

        pages = new Page[]{new ParamPage(), new TunePage(), new StrategyPage(), new ReplacePage(),
                new BackupPage(), new AboutPage()};
        views = new View[pages.length];

        FrameLayout wrap = new FrameLayout(this);
        wrap.setBackgroundColor(Ui.BG);
        wrap.addView(new LiquidBackdrop(this), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        /* 主界面先在底下候场:等开场动画走到交接点再淡入,两屏叠着走 */
        View ui = buildUi();
        ui.setAlpha(0f);
        ui.setScaleX(1.035f);
        ui.setScaleY(1.035f);
        wrap.addView(ui, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(wrap);

        showPage(0);
        attachSplash(wrap, ui);
        askNotification();
    }

    /* ================= 开场过渡动画 ================= */

    private void attachSplash(final FrameLayout wrap, final View ui) {
        if (SPLASH_PLAYED) {
            ui.setAlpha(1f);
            ui.setScaleX(1f);
            ui.setScaleY(1f);
            return;
        }
        SPLASH_PLAYED = true;

        /* 交接点用延时对齐:开场动画淡出的同时,主界面淡入并落回原尺寸 */
        ui.postDelayed(new Runnable() {
            @Override
            public void run() {
                ui.animate()
                        .alpha(1f)
                        .scaleX(1f)
                        .scaleY(1f)
                        .setDuration(560)
                        .setInterpolator(new android.view.animation.DecelerateInterpolator(1.6f))
                        .start();
            }
        }, (long) (SplashView.DURATION * SplashView.HANDOFF_AT));

        final SplashView[] holder = new SplashView[1];
        holder[0] = new SplashView(this, new SplashView.Done() {
            @Override
            public void onDone() {
                /* 用户中途点掉开场动画时的兜底:主界面必须已经在位 */
                if (ui.getAlpha() < 1f) {
                    ui.animate().alpha(1f).scaleX(1f).scaleY(1f)
                            .setDuration(260).start();
                }
                if (holder[0] != null && holder[0].getParent() == wrap) {
                    wrap.removeView(holder[0]);
                }
            }
        });
        wrap.addView(holder[0], new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    /* ================= UI 骨架 ================= */

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0x00000000);
        root.setFitsSystemWindows(true);

        /* ---- 顶栏 ---- */
        LinearLayout top = Ui.row(this);
        int p = Ui.dp(this, 16);
        top.setPadding(p, Ui.dp(this, 12), p, Ui.dp(this, 8));
        LiquidGlass.setBackgroundOf(top, 0f, 0);

        LinearLayout titleCol = Ui.col(this);
        titleView = Ui.h1(this, "");
        titleCol.addView(titleView);
        titleCol.addView(Ui.gap(this, 2));
        titleCol.addView(Ui.text(this, "Zaka · 飞鸟调参", 11f, Ui.TEXT_DIM, true));
        titleCol.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        top.addView(titleCol);

        LinearLayout chips = Ui.col(this);
        chips.setGravity(Gravity.END);
        rootChip = chip("ROOT ?", Ui.TEXT_DIM, Ui.SURFACE_2);
        engineChip = chip("引擎 关", Ui.TEXT_DIM, Ui.SURFACE_2);
        LinearLayout chipRow = Ui.row(this);
        chipRow.setGravity(Gravity.END);
        chipRow.addView(rootChip);
        LinearLayout.LayoutParams gap = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        gap.leftMargin = Ui.dp(this, 6);
        chipRow.addView(engineChip, gap);
        chips.addView(chipRow);
        top.addView(chips);

        root.addView(top);

        /* ---- 内容区 ---- */
        content = new FrameLayout(this);
        content.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(content);

        /* ---- 底部导航 ---- */
        navBar = Ui.row(this);
        LiquidGlass.setBackgroundOf(navBar, 0f, 0x30090B10);
        navBar.setPadding(0, Ui.dp(this, 7), 0, Ui.dp(this, 7));
        navLabels = new TextView[NAV_LABELS.length];
        navIcons = new Icon.IconView[NAV_LABELS.length];
        navPills = new LinearLayout[NAV_LABELS.length];

        for (int i = 0; i < NAV_LABELS.length; i++) {
            final int idx = i;
            LinearLayout item = Ui.col(this);
            item.setGravity(Gravity.CENTER);

            LinearLayout pill = Ui.col(this);
            pill.setGravity(Gravity.CENTER);
            int pw = Ui.dp(this, 54), ph = Ui.dp(this, 30);
            pill.setLayoutParams(new LinearLayout.LayoutParams(pw, ph));
            pill.setBackground(Ui.round(0x00000000, 15f, this));

            Icon.IconView icon = new Icon.IconView(this, NAV_ICONS[i], Ui.TEXT_DIM);
            pill.addView(icon);

            TextView label = Ui.text(this, NAV_LABELS[i], 10f, Ui.TEXT_DIM, false);
            label.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            llp.topMargin = Ui.dp(this, 2);
            label.setLayoutParams(llp);

            item.addView(pill);
            item.addView(label);

            LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            item.setLayoutParams(ilp);
            item.setPadding(0, Ui.dp(this, 3), 0, Ui.dp(this, 3));
            item.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) { showPage(idx); }
            });

            navIcons[i] = icon;
            navLabels[i] = label;
            navPills[i] = pill;
            navBar.addView(item);
        }
        root.addView(navBar);
        return root;
    }

    private TextView chip(String s, int fg, int bg) {
        TextView t = Ui.text(this, s, 11f, fg, true);
        t.setPadding(Ui.dp(this, 9), Ui.dp(this, 5), Ui.dp(this, 9), Ui.dp(this, 5));
        LiquidGlass.setBackgroundOf(t, Ui.R_PILL, (bg & 0x00FFFFFF) | 0x55000000);
        return t;
    }

    /* ================= 页面切换 ================= */

    /** 进场 300ms / 退场 220ms,两段叠着走 */
    private static final int PAGE_IN_MS = 300;
    private static final int PAGE_OUT_MS = 220;

    private void showPage(int idx) {
        if (idx < 0 || idx >= pages.length) return;

        final int from = current;
        if (views[idx] == null) {
            views[idx] = pages[idx].build(this, this);
        }
        final View nv = views[idx];

        /* 同页重进(例如授权回来刷新):只补一次 onShow,不重放过渡 */
        if (idx == from && content.getChildCount() > 0 && nv.getParent() == content) {
            pages[idx].onShow();
            paintNav();
            return;
        }

        final boolean first = content.getChildCount() == 0;
        final boolean forward = idx > from;
        current = idx;

        /* ---- 旧页退场:顺着切页方向滑走 + 淡出 ---- */
        final View ov = content.getChildCount() > 0 ? content.getChildAt(0) : null;
        for (int i = content.getChildCount() - 1; i >= 0; i--) {   // 清掉快速连点留下的残页
            View c = content.getChildAt(i);
            if (c != ov && c != nv) content.removeViewAt(i);
        }
        if (ov != null && ov != nv) {
            ov.animate().cancel();
            ov.animate()
                    .alpha(0f)
                    .translationX(forward ? -Ui.dp(this, 24) : Ui.dp(this, 24))
                    .translationY(forward ? -Ui.dp(this, 8) : Ui.dp(this, 8))
                    .setDuration(PAGE_OUT_MS)
                    .setInterpolator(new android.view.animation.AccelerateInterpolator(1.5f))
                    .withEndAction(new Runnable() {
                        @Override
                        public void run() {
                            if (ov.getParent() == content) content.removeView(ov);
                            ov.setAlpha(1f);
                            ov.setTranslationX(0f);
                            ov.setTranslationY(0f);
                            ov.setScaleX(1f);
                            ov.setScaleY(1f);
                        }
                    })
                    .start();
        }

        if (nv.getParent() != null) {
            ((ViewGroup) nv.getParent()).removeView(nv);
        }
        content.addView(nv, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        /* ---- 新页进场:从切页方向滑进来 + 上浮 + 轻微放大 ---- */
        nv.animate().cancel();
        nv.setAlpha(0f);
        nv.setTranslationX(first ? 0f : (forward ? Ui.dp(this, 28) : -Ui.dp(this, 28)));
        nv.setTranslationY(Ui.dp(this, 15));
        nv.setScaleX(0.976f);
        nv.setScaleY(0.976f);
        nv.animate()
                .alpha(1f)
                .translationX(0f)
                .translationY(0f)
                .scaleX(1f)
                .scaleY(1f)
                .setStartDelay(first ? 0 : 40)
                .setDuration(PAGE_IN_MS)
                .setInterpolator(new android.view.animation.DecelerateInterpolator(1.9f))
                .start();

        setTitleAnimated(pages[idx].title());
        pages[idx].onShow();
        paintNav();
    }

    /** 顶栏标题:先淡出上移,再淡入落位,别硬切 */
    private void setTitleAnimated(final String s) {
        if (titleView == null || s == null) return;
        if (s.contentEquals(titleView.getText())) return;
        titleView.animate().cancel();
        titleView.animate()
                .alpha(0f)
                .translationY(-Ui.dp(this, 7))
                .setDuration(110)
                .withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        if (titleView == null) return;
                        titleView.setText(s);
                        titleView.setTranslationY(Ui.dp(this, 9));
                        titleView.animate()
                                .alpha(1f)
                                .translationY(0f)
                                .setDuration(240)
                                .setInterpolator(
                                        new android.view.animation.DecelerateInterpolator(1.8f))
                                .start();
                    }
                })
                .start();
    }

    private void paintNav() {
        for (int i = 0; i < navPills.length; i++) {
            boolean on = i == current;
            if (on) {
                LiquidGlass.setBackgroundOf(navPills[i], 15f, 0x4FA8C7FA);
            } else {
                LiquidGlass.setBackgroundOf(navPills[i], 15f, 0);
            }
            navLabels[i].setTextColor(on ? Ui.PRIMARY : Ui.TEXT_DIM);
            navIcons[i].setColor(on ? Ui.PRIMARY : Ui.TEXT_DIM);

            /* 选中的胶囊弹一下(Overshoot),图标跟着轻轻抬起 */
            navPills[i].animate().cancel();
            navPills[i].animate()
                    .scaleX(on ? 1f : 0.88f)
                    .scaleY(on ? 1f : 0.88f)
                    .setDuration(on ? 340 : 200)
                    .setInterpolator(on
                            ? new android.view.animation.OvershootInterpolator(1.15f)
                            : new android.view.animation.DecelerateInterpolator(1.5f))
                    .start();

            navIcons[i].animate().cancel();
            navIcons[i].animate()
                    .translationY(on ? -Ui.dp(this, 1.5f) : 0f)
                    .setDuration(260)
                    .setInterpolator(new android.view.animation.DecelerateInterpolator(1.7f))
                    .start();
        }
    }

    @Override
    public void onBackPressed() {
        if (current != 0) { showPage(0); return; }
        super.onBackPressed();
    }

    /* ================= Host ================= */

    @Override
    public void pickDocument(int req, String mime, String title, Page owner) {
        pending.put(req, owner);
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(mime == null || mime.isEmpty() ? "*/*" : mime);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {
            startActivityForResult(i, req);
        } catch (Throwable t) {
            toast("这台设备没有可用的文件选择器");
        }
    }

    @Override
    public void pickTree(int req, String title, Page owner) {
        pending.put(req, owner);
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {
            startActivityForResult(i, req);
        } catch (Throwable t) {
            toast("这台设备不支持目录选择");
        }
    }

    @Override
    public void pickCreate(int req, String mime, String suggestedName, Page owner) {
        pending.put(req, owner);
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(mime == null || mime.isEmpty() ? "application/octet-stream" : mime);
        i.putExtra(Intent.EXTRA_TITLE, suggestedName);
        try {
            startActivityForResult(i, req);
        } catch (Throwable t) {
            toast("这台设备不支持另存为");
        }
    }

    @Override
    public void toast(String s) {
        try {
            android.widget.Toast.makeText(this, s, android.widget.Toast.LENGTH_SHORT).show();
        } catch (Throwable ignored) {}
    }

    @Override
    public void ensureOverlay(final Runnable after) {
        if (ScreenEngine.canOverlay(this)) {
            if (after != null) after.run();
            return;
        }
        pendingOverlay = after;
        toast("实时识别需要悬浮窗权限,授权后自动继续");
        try {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
            i.setData(android.net.Uri.parse("package:" + getPackageName()));
            startActivityForResult(i, 9100);
        } catch (Throwable t) {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
            startActivityForResult(i, 9100);
        }
    }

    @Override
    public void startProjection() {
        try {
            MediaProjectionManager mpm =
                    (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJ);
        } catch (Throwable t) {
            toast("屏幕采集不可用");
        }
    }

    @Override
    public void openUrl(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)));
        } catch (Throwable t) {
            toast("打不开这个链接");
        }
    }

    @Override
    public void switchTo(int index) {
        showPage(index);
    }

    /* ================= 结果 & 生命周期 ================= */

    @Override
    protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req, result, data);

        if (req == REQ_PROJ) {
            if (result == RESULT_OK && data != null) {
                ScreenEngine.start(this, result, data);
                toast("识别已启动,回到游戏即可看到 HUD");
            } else {
                toast("已取消屏幕采集授权");
            }
            if (pages != null) pages[1].onShow();
            return;
        }

        if (req == 9100) {
            if (ScreenEngine.canOverlay(this) && pendingOverlay != null) {
                Runnable r = pendingOverlay;
                pendingOverlay = null;
                r.run();
            } else {
                pendingOverlay = null;
            }
            return;
        }

        Page owner = pending.remove(req);
        if (owner != null) owner.onResult(req, result, data);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (pendingOverlay != null && ScreenEngine.canOverlay(this)) {
            Runnable r = pendingOverlay;
            pendingOverlay = null;
            r.run();
        }
        refreshChips();
    }

    private void refreshChips() {
        if (engineChip != null) {
            boolean on = ScreenEngine.RUNNING;
            engineChip.setText(on ? "引擎 开" : "引擎 关");
            engineChip.setTextColor(on ? Ui.GREEN : Ui.TEXT_DIM);
            engineChip.setBackground(Ui.round(on ? Ui.GREEN_CONT : Ui.SURFACE_2, Ui.R_PILL, this));
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                final boolean root = Shell.hasRoot();
                if (rootChip == null) return;
                rootChip.post(new Runnable() {
                    @Override
                    public void run() {
                        if (rootChip == null) return;
                        rootChip.setText(root ? "ROOT 就绪" : "ROOT 未授权");
                        rootChip.setTextColor(root ? Ui.GREEN : Ui.RED);
                        rootChip.setBackground(Ui.round(root ? Ui.GREEN_CONT : Ui.RED_CONT,
                                Ui.R_PILL, MainActivity.this));
                    }
                });
            }
        }).start();
    }

    private void askNotification() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                != PackageManager.PERMISSION_GRANTED) {
            try {
                requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, REQ_NOTI);
            } catch (Throwable ignored) {}
        }
    }
}

package com.feiniao.tuner.core;

import com.feiniao.tuner.model.ParamSet;
import com.feiniao.tuner.model.Segment;

/**
 * 弹道预判核心算式。
 *
 * 预判(身位) = (目标横向速度 × 子弹飞行时间) / 一个身位当量
 * 子弹飞行时间 = 距离 / 子弹速度
 */
public final class Physics {

    /** 预判量化步长:0.1 身位 */
    public static final float STEP = 0.1f;

    private Physics() {}

    /** 子弹飞行时间(秒) */
    public static float flightTime(float distance, float bulletSpeed) {
        if (bulletSpeed <= 1f) return 0f;
        return distance / bulletSpeed;
    }

    /** 理论所需预判(身位) */
    public static float requiredPredict(ParamSet ps, float distance, float charSpeed, float bulletSpeed) {
        if (ps == null) return 0f;
        float t = flightTime(distance, bulletSpeed);
        float targetMPS = charSpeed * ps.speedScale;      // 目标横向速度(米/秒)
        float shiftMeter = targetMPS * t;                 // 这段飞行时间里目标移动的距离
        if (ps.bodyWidth <= 0.01f) return 0f;
        return shiftMeter / ps.bodyWidth;
    }

    /** 按分段参数算该段的理论预判 */
    public static float requiredPredict(ParamSet ps, Segment s) {
        if (s == null) return 0f;
        return requiredPredict(ps, s.distance, s.charSpeed, s.bulletSpeed);
    }

    /** 量化到 0.1 步长 */
    public static float quantize(float v) {
        return Math.round(v / STEP) * STEP;
    }

    /** 四舍五入到两位小数,避免浮点噪声 */
    public static float round2(float v) {
        return Math.round(v * 100f) / 100f;
    }

    public static String fmt(float v, int decimals) {
        return String.format(java.util.Locale.US, "%." + decimals + "f", v);
    }

    /**
     * 人物速度是否落在 19 / 20 档。
     * 命中才需要动横向衰减,其余档位不动。
     */
    public static boolean hitSpeedBracket(float charSpeed) {
        return Math.abs(charSpeed - 19f) < 0.5f || Math.abs(charSpeed - 20f) < 0.5f;
    }

    /** 打顶飞档位:19 / 20 这两档才是打顶飞的速度 */
    public static String bracketName(float charSpeed) {
        if (Math.abs(charSpeed - 20f) < 0.5f) return "打顶飞 · 20 档";
        if (Math.abs(charSpeed - 19f) < 0.5f) return "打顶飞 · 19 档";
        return "常规档 " + fmt(charSpeed, 1) + "(横向衰减不用动)";
    }

    /**
     * 让两把武器的提前量差出指定身位所需的「慢弹速」。
     *
     * 用于复核「左轮比猎枪快一点,差不多差一个半身位」这类口径:
     * 输入快枪的弹速和想拉开的提前量,反推慢枪该给多少弹速。
     *
     * @param slotGap 想拉开的提前量(身位),正数 = 慢枪要多给这么多
     */
    public static float bulletSpeedForGap(float distance, float charSpeed, float speedScale,
                                          float bodyWidth, float fastBullet, float slotGap) {
        if (distance <= 0f || fastBullet <= 1f || bodyWidth <= 0.01f) return fastBullet;
        float mps = charSpeed * speedScale;
        if (mps <= 0.01f) return fastBullet;
        float tFast = distance / fastBullet;
        float needFast = mps * tFast / bodyWidth;
        float needSlow = needFast + slotGap;
        if (needSlow <= 0.001f) return fastBullet * 4f;
        float tSlow = needSlow * bodyWidth / mps;
        if (tSlow <= 0.0001f) return fastBullet * 4f;
        return distance / tSlow;
    }

    /** 判定偏差方向 */
    public static int verdict(float measured, float param) {
        float d = measured - param;
        if (Math.abs(d) < 0.05f) return 0;   // 准
        return d > 0 ? 1 : -1;               // 1 = 需要加大, -1 = 需要减小
    }

    public static String verdictText(int v) {
        if (v > 0) return "偏小 · 需加大";
        if (v < 0) return "偏大 · 需减小";
        return "吻合";
    }
}

package com.feiniao.tuner.core;

import com.feiniao.tuner.model.ParamSet;
import com.feiniao.tuner.model.Segment;

/**
 * 把调参方案打包成 preference.ini。
 * 支持用户自定义模板,占位符:
 *   {{TOTAL}} 总距离  {{COUNT}} 分段数  {{NAME}} 方案名  {{BODY}} 身位当量
 *   循环块 {{#SEG}} ... {{/SEG}} 内可用:
 *   {{D}} 距离  {{CS}} 人物速度  {{BS}} 子弹速度  {{P}} 预判  {{H}} 横向衰减
 *   {{SUB}} 小距离(细分步长)  {{I}} 序号
 */
public final class IniBuilder {

    public static final String DEFAULT_TEMPLATE =
            "[feiniao]\n"
          + "name={{NAME}}\n"
          + "total_distance={{TOTAL}}\n"
          + "body_width={{BODY}}\n"
          + "count={{COUNT}}\n"
          + "{{#SEG}}\n"
          + "[seg_{{I}}]\n"
          + "distance={{D}}\n"
          + "char_speed={{CS}}\n"
          + "bullet_speed={{BS}}\n"
          + "predict={{P}}\n"
          + "h_decay={{H}}\n"
          + "{{/SEG}}";

    private IniBuilder() {}

    public static String build(ParamSet ps) {
        return build(ps, DEFAULT_TEMPLATE);
    }

    public static String build(ParamSet ps, String template) {
        if (template == null || template.trim().isEmpty()) template = DEFAULT_TEMPLATE;
        ps.sortByDistance();

        String head = template;
        String loop = "";

        int a = template.indexOf("{{#SEG}}");
        int b = template.indexOf("{{/SEG}}");
        if (a >= 0 && b > a) {
            head = template.substring(0, a);
            loop = template.substring(a + "{{#SEG}}".length(), b);
            String tail = template.substring(b + "{{/SEG}}".length());
            head = head + "\u0001" + tail;
        }

        StringBuilder seg = new StringBuilder();
        int i = 0;
        for (Segment s : ps.segments) {
            seg.append(replace(loop, ps, s, i));
            i++;
        }

        StringBuilder out = new StringBuilder();
        String[] parts = head.split("\u0001", -1);
        out.append(globals(parts[0], ps));
        out.append(seg);
        if (parts.length > 1) out.append(globals(parts[1], ps));

        String txt = out.toString();
        // 压缩多余空行
        txt = txt.replaceAll("\\n{3,}", "\n\n");
        if (!txt.endsWith("\n")) txt += "\n";
        return txt;
    }

    private static String globals(String s, ParamSet ps) {
        return s.replace("{{NAME}}", ps.name)
                .replace("{{TOTAL}}", num(ps.totalDistance))
                .replace("{{BODY}}", num(ps.bodyWidth))
                .replace("{{COUNT}}", String.valueOf(ps.segments.size()));
    }

    private static String replace(String s, ParamSet ps, Segment seg, int idx) {
        return s.replace("{{D}}", num(seg.distance))
                .replace("{{CS}}", num(seg.charSpeed))
                .replace("{{BS}}", num(seg.bulletSpeed))
                .replace("{{P}}", num(seg.predict))
                .replace("{{H}}", num(seg.hDecay))
                .replace("{{SUB}}", num(seg.sub))
                .replace("{{I}}", String.valueOf(idx));
    }

    private static String num(float v) {
        if (Math.abs(v - Math.round(v)) < 0.0001f) return String.valueOf(Math.round(v));
        return String.valueOf(Math.round(v * 1000f) / 1000f);
    }
}

package com.feiniao.tuner.core;

import com.feiniao.tuner.model.ParamSet;
import com.feiniao.tuner.model.Segment;

import java.util.ArrayList;
import java.util.List;

/**
 * 智能推演 —— 会讲道理的调参。
 *
 * 不是「按公式算一遍」,而是先看数据、再看结构、最后才动手,每一步都给理由和把握度:
 *
 *   ① 校准口径   先核这份表跟当前版本口径(超自然)、当前武器曲线对不对得上
 *   ② 实测优先   有视频/实时实测的段以实测为主,权重按样本数给 —— 样本多的说话更响
 *   ③ 结构体检   横向衰减档位、预判单调性、分段覆盖、小距离是否太粗
 *   ④ 视角修正   斜向交火/视角偏移带来的横向分量损失,按 1/cos 补回去
 *   ⑤ 出方案     每条改动 = 距离 + 项目 + 原值 → 新值 + 理由 + 把握度,可挑着用
 */
public final class Thinker {

    /** 把握度基准:实测样本打底 */
    public static final int CONF_MEASURED = 88;
    /** 纯理论推算 */
    public static final int CONF_THEORY = 62;
    /** 结构性问题(衰减档位 / 破坏手感) */
    public static final int CONF_STRUCT = 80;
    /** 横向衰减:口径是死的,直接给最高把握 */
    public static final int CONF_DECAY = 95;
    /** 平滑曲线 */
    public static final int CONF_SMOOTH = 70;
    /** 补段 / 小距离细化 */
    public static final int CONF_GAP = 66;

    public static final String K_PREDICT = "预判";
    public static final String K_BULLET = "子弹速度";
    public static final String K_DECAY = "横向衰减";
    public static final String K_SUB = "小距离";
    public static final String K_ADD = "补段";

    private Thinker() {}

    /* ==================== 数据模型 ==================== */

    /** 一条改动 */
    public static class Item {
        public float distance;
        public String kind = K_PREDICT;
        public float oldV, newV;
        public String reason = "";
        public int conf = CONF_THEORY;

        public boolean changed() { return Math.abs(newV - oldV) > 0.0005f; }

        public String line() {
            return Segment.trim(distance) + "m · " + kind + ":"
                    + Segment.trim(oldV) + " → " + Segment.trim(newV);
        }
    }

    /** 一次推演的全过程 */
    public static class Diag {
        public final List<Item> items = new ArrayList<Item>();
        public final List<String> thoughts = new ArrayList<String>();
        public final List<String> warnings = new ArrayList<String>();
        public String angleNote = "";
        public int angleSamples = 0;
        public float angleAvgDeg = 0f;

        public int count(int minConf) {
            int n = 0;
            for (Item it : items) if (it.conf >= minConf && it.changed()) n++;
            return n;
        }

        public int byKind(String k) {
            int n = 0;
            for (Item it : items) if (k.equals(it.kind)) n++;
            return n;
        }
    }

    /* ==================== 推演 ==================== */

    public static Diag think(ParamSet ps, WeaponPreset w, boolean useSlotGap,
                             Analysis.Report rep, Strategy.Brief brief) {
        Diag d = new Diag();
        if (ps == null || ps.segments.isEmpty()) {
            d.warnings.add("当前方案还没有分段,先去「参数」页铺一张表。");
            return d;
        }
        ps.sortByDistance();
        final WeaponPreset wp = w != null ? w : WeaponPreset.byId(ps.weapon);

        float angleDeg = brief != null && brief.angleDeg > 0f ? brief.angleDeg : 0f;
        float angleK = Strategy.angleFactor(angleDeg);
        float gs = brief != null && brief.gapScale > 0f ? brief.gapScale : 1f;
        float gapAdd = brief != null ? brief.gapAdd : 0f;
        float bulletBias = brief != null ? brief.bulletBias : 0f;

        /* ---------- ① 口径校准 ---------- */
        d.thoughts.add("第一步先核口径:这份表标的是「" + ps.versionTag + "」,当前引擎口径是「"
                + WeaponPreset.VERSION + "」,武器曲线按 " + wp.name + " 算。");
        if (!WeaponPreset.VERSION.equals(ps.versionTag)) {
            d.warnings.add("表的版本标着「" + ps.versionTag + "」,跟当前口径「" + WeaponPreset.VERSION
                    + "」不一致 —— 换过版本的手感不能直接沿用,推演结果要跑一次视频调参复核。");
        }

        /* ---------- ② 实测数据整理 ---------- */
        int measuredSegs = 0, measuredSamples = 0;
        if (rep != null && rep.rows != null) {
            for (Analysis.SegRow row : rep.rows) {
                if (row != null && row.samples > 0 && !row.theory) {
                    measuredSegs++;
                    measuredSamples += row.samples;
                }
            }
        }
        if (measuredSegs > 0) {
            d.thoughts.add("实测部分:" + measuredSegs + " 段有真实交火数据,共 " + measuredSamples
                    + " 次采样 —— 这些段以实测为主,理论值只当参照。");
        } else if (rep != null) {
            d.thoughts.add("这次没有实测数据兜底,只能按理论模型推 —— 精度够用,但建议之后导一段视频复核。");
        } else {
            d.thoughts.add("没有视频报告,按理论模型 + 你写的思路推。");
        }

        /* ---------- ③ 视角 / 角度偏移 ---------- */
        if (rep != null && rep.angleSamples > 0) {
            d.angleSamples = rep.angleSamples;
            d.angleAvgDeg = rep.angleAvgDeg;
            d.thoughts.add("镜头上测到的交火角度:平均 " + Physics.fmt(rep.angleAvgDeg, 1)
                    + "°,斜向系数 " + Physics.fmt(rep.slantAvg, 2)
                    + " —— 斜向越明显,横向分量损失越多,预判要按 1/cos 补。");
            if (rep.angleAvgDeg > 8f && angleDeg <= 0f) {
                angleDeg = Math.min(35f, rep.angleAvgDeg);
                angleK = Strategy.angleFactor(angleDeg);
                d.angleNote = "按镜头实测角度 " + Physics.fmt(angleDeg, 1) + "° 做补偿";
            }
        }
        if (angleDeg > 0f) {
            d.angleNote = (d.angleNote.isEmpty() ? "" : d.angleNote + ";")
                    + "视角 / 角度偏移 " + Physics.fmt(angleDeg, 1) + "° → 预判 ×"
                    + Physics.fmt(angleK, 3);
            d.thoughts.add("视角修正:按 " + Physics.fmt(angleDeg, 1) + "° 斜角,横向预判放大 "
                    + Physics.fmt((angleK - 1f) * 100f, 1) + "%。");
        }

        /* ---------- ④ 逐段推演 ---------- */
        int n = ps.segments.size();
        for (int i = 0; i < n; i++) {
            Segment s = ps.segments.get(i);
            if (s == null) continue;

            /* 4.1 子弹速度:按武器曲线核 */
            float expBs = wp.bulletSpeedAt(ps.bulletRef, s.distance) * (1f + bulletBias);
            expBs = Math.max(120f, Math.round(expBs * 10f) / 10f);
            if (expBs > 1f && Math.abs(expBs - s.bulletSpeed) / expBs > 0.02f) {
                Item it = new Item();
                it.distance = s.distance;
                it.kind = K_BULLET;
                it.oldV = s.bulletSpeed;
                it.newV = expBs;
                it.reason = wp.name + " 在 " + Segment.trim(s.distance) + "m 的弹速应是 "
                        + Segment.trim(expBs) + " m/s(基准 " + Segment.trim(ps.bulletRef)
                        + " × 曲线" + (bulletBias != 0f
                        ? ",再叠你写的弹速取向 " + Physics.fmt(bulletBias * 100f, 1) + "%" : "") + ")";
                it.conf = brief != null && brief.hasWeapon ? CONF_MEASURED : CONF_THEORY;
                d.items.add(it);
            }

            /* 4.2 横向衰减 */
            float hd = brief != null && brief.decayFixed >= 0f
                    ? brief.decayFixed : AutoTune.lateralDecay(s.charSpeed, s.distance);
            if (brief != null && brief.decayFixed < 0f && brief.decayScale > 0f) {
                hd = Math.round(hd * brief.decayScale * 100f) / 100f;
            }
            if (Math.abs(hd - s.hDecay) > 0.005f) {
                Item it = new Item();
                it.distance = s.distance;
                it.kind = K_DECAY;
                it.oldV = s.hDecay;
                it.newV = hd;
                if (!Physics.hitSpeedBracket(s.charSpeed)) {
                    it.reason = Segment.trim(s.charSpeed) + " 档不是打顶飞(19/20),横向衰减按口径不给值,归零";
                } else if (hd == 0f) {
                    it.reason = "按你写的「归零」处理";
                } else {
                    it.reason = "打顶飞档:" + Segment.trim(s.charSpeed) + " 档 × 距离 "
                            + Segment.trim(s.distance) + "m 算出 " + Segment.trim(hd);
                }
                it.conf = CONF_DECAY;
                d.items.add(it);
            }

            /* 4.3 预判 */
            float theory = Physics.requiredPredict(ps, s.distance, s.charSpeed, s.bulletSpeed);
            theory += wp.dropLead(s.distance);
            if (useSlotGap) theory += wp.slotGap;
            theory = theory * gs + gapAdd;
            theory *= angleK;
            if (theory < 0f) theory = 0f;
            theory = Physics.quantize(theory);

            float target = theory;
            int conf = CONF_THEORY;
            String why = "按 " + wp.name + " 曲线重算:" + Segment.trim(s.distance) + "m ÷ "
                    + Segment.trim(s.bulletSpeed) + " m/s 得飞行时间,乘 " + Segment.trim(s.charSpeed)
                    + " 档横移,再除以身位当量 " + Segment.trim(ps.bodyWidth) + "m";

            Analysis.SegRow row = findRow(rep, s.distance);
            if (row != null && row.samples > 0 && !row.theory) {
                float wgt = Math.min(1f, row.samples / 3f);
                target = theory * (1f - wgt) + row.suggest * wgt;
                target = Physics.quantize(target);
                conf = Math.min(CONF_MEASURED + 5, 60 + row.samples * 8);
                why = "实测优先:这档有 " + row.samples + " 次真实交火,实测要 "
                        + Physics.fmt(row.need, 2) + " 身位(你现在给的是 "
                        + Physics.fmt(s.predict, 2) + "),按样本权重 " + Physics.fmt(wgt, 2)
                        + " 与理论值融合";
            } else if (row != null && row.samples > 0) {
                why = why + ";这档只有理论推算的样本,权重压到理论侧";
            }

            if (Math.abs(target - s.predict) > 0.05f) {
                Item it = new Item();
                it.distance = s.distance;
                it.kind = K_PREDICT;
                it.oldV = s.predict;
                it.newV = target;
                it.reason = why + (angleDeg > 0f ? ";已叠视角修正" : "");
                it.conf = conf;
                d.items.add(it);
            }

            /* 4.4 小距离 */
            float span = 0f;
            if (i + 1 < n) span = ps.segments.get(i + 1).distance - s.distance;
            if (span > 25f && s.sub <= 0f) {
                Item it = new Item();
                it.distance = s.distance;
                it.kind = K_SUB;
                it.oldV = s.sub;
                it.newV = Math.max(1f, Math.round(span / 5f));
                it.reason = "这段跨度 " + Segment.trim(span) + "m,小距离没设 —— 给个 "
                        + Segment.trim(it.newV) + "m 的微调步长,近了也好对着抠";
                it.conf = CONF_GAP;
                d.items.add(it);
            }
        }

        /* ---------- ⑤ 预判单调性 ---------- */
        List<Item> predicts = new ArrayList<Item>();
        for (Item it : d.items) if (K_PREDICT.equals(it.kind)) predicts.add(it);
        for (int i = 1; i < predicts.size(); i++) {
            if (predicts.get(i).newV < predicts.get(i - 1).newV - 0.05f) {
                Item it = predicts.get(i);
                it.newV = predicts.get(i - 1).newV;
                it.reason = it.reason + ";另外这段还压了前一段 —— 距离更远预判反而更小,"
                        + "打起来会断层,拉平到 " + Segment.trim(it.newV);
                it.conf = Math.max(it.conf, CONF_SMOOTH);
            }
        }
        int inv = 0;
        for (int i = 1; i < n; i++) {
            if (ps.segments.get(i).predict < ps.segments.get(i - 1).predict - 0.05f) inv++;
        }
        if (inv > 0) {
            d.warnings.add("当前表里有 " + inv + " 处预判倒挂(距离更远、预判反而更小),"
                    + "推演已经把它们拉平;不想动的话应用时取消勾选「修单调」那档把握度。");
        }

        /* ---------- ⑥ 覆盖与分段 ---------- */
        if (rep != null && rep.dist != null) {
            if (rep.dist.dead != null && !rep.dist.dead.isEmpty()) {
                d.warnings.add("实测里有 " + rep.dist.dead.size()
                        + " 段距离完全没交火样本 —— 那些段只能靠理论值,别当实测用。");
            }
            for (float[] seg : rep.dist.dead) {
                float mid = (seg[0] + seg[1]) / 2f;
                if (mid < 5f) continue;
                Item it = new Item();
                it.distance = Math.round(mid);
                it.kind = K_ADD;
                it.oldV = 0f;
                it.newV = 1f;
                it.reason = "实测 " + Segment.trim(seg[0]) + "~" + Segment.trim(seg[1])
                        + "m 是空的,这里补一档,把那一段的手感也接上";
                it.conf = CONF_GAP;
                d.items.add(it);
            }
        }
        int maxGap = 0;
        float gapAt = 0f;
        for (int i = 1; i < n; i++) {
            float g = ps.segments.get(i).distance - ps.segments.get(i - 1).distance;
            if (g > maxGap) { maxGap = (int) g; gapAt = ps.segments.get(i - 1).distance; }
        }
        if (maxGap >= 100) {
            Item it = new Item();
            it.distance = gapAt + maxGap / 2f;
            it.kind = K_ADD;
            it.oldV = 0f;
            it.newV = 1f;
            it.reason = Segment.trim(gapAt) + " 到 " + Segment.trim(gapAt + maxGap)
                    + " 之间隔了 " + maxGap + "m,是全表最疏的一段,中间插一档更稳";
            it.conf = CONF_GAP;
            d.items.add(it);
        }

        if (d.items.isEmpty()) {
            d.thoughts.add("核完了 —— 这份表跟当前口径对得上,弹速曲线、衰减档位、预判曲线都没毛病,没东西要改。");
        } else {
            d.thoughts.add("出方案:" + d.items.size() + " 条改动,其中 " + d.count(CONF_MEASURED)
                    + " 条是实测驱动、" + d.count(CONF_STRUCT) + " 条是结构问题 ——"
                    + "底下的清单可以按把握度挑着套用。");
        }
        return d;
    }

    /* ==================== 应用 ==================== */

    /**
     * 套用推演结果。
     *
     * @param minConf 把握度门槛:80 = 只套实测 + 结构问题;60 = 连理论推算一起套
     * @return 实际改了几处
     */
    public static int apply(ParamSet ps, Diag d, int minConf) {
        if (ps == null || d == null) return 0;
        int n = 0;
        for (Item it : d.items) {
            if (it.conf < minConf || !it.changed()) continue;
            if (K_ADD.equals(it.kind)) {
                if (addSegment(ps, it.distance)) n++;
                continue;
            }
            Segment s = ps.nearest(it.distance);
            if (s == null || Math.abs(s.distance - it.distance) > 0.6f) continue;
            if (K_PREDICT.equals(it.kind)) s.predict = Physics.quantize(it.newV);
            else if (K_BULLET.equals(it.kind)) s.bulletSpeed = Math.round(it.newV * 10f) / 10f;
            else if (K_DECAY.equals(it.kind)) s.hDecay = Math.round(it.newV * 100f) / 100f;
            else if (K_SUB.equals(it.kind)) s.sub = Math.round(it.newV * 10f) / 10f;
            n++;
        }
        ps.sortByDistance();
        return n;
    }

    /** 在指定距离插一档,曲线参数照邻居插值 */
    public static boolean addSegment(ParamSet ps, float distance) {
        if (ps == null) return false;
        if (ps.nearest(distance) != null
                && Math.abs(ps.nearest(distance).distance - distance) < 0.6f) return false;
        Segment left = null, right = null;
        for (Segment s : ps.segments) {
            if (s.distance <= distance) left = s;
            if (s.distance > distance && right == null) right = s;
        }
        Segment base = left != null ? left : right;
        if (base == null) return false;
        float cs = base.charSpeed;
        float bs = base.bulletSpeed;
        if (right != null) {
            bs = Math.round((base.bulletSpeed + right.bulletSpeed) / 2f * 10f) / 10f;
            cs = right.charSpeed;
        }
        float pr = Physics.quantize(Physics.requiredPredict(ps, distance, cs, bs));
        if (left != null) {
            pr = Math.max(pr, left.predict);
        }
        float hd = AutoTune.lateralDecay(cs, distance);
        ps.segments.add(new Segment(distance, cs, bs, pr, hd, base.sub));
        ps.sortByDistance();
        if (distance > ps.totalDistance) ps.totalDistance = distance;
        return true;
    }

    /** 只重算横向衰减(打顶飞档) */
    public static int decayOnly(ParamSet ps) {
        if (ps == null) return 0;
        int n = 0;
        for (Segment s : ps.segments) {
            float hd = AutoTune.lateralDecay(s.charSpeed, s.distance);
            if (Math.abs(hd - s.hDecay) > 0.0005f) { s.hDecay = hd; n++; }
        }
        return n;
    }

    /** 拉平预判曲线:距离变远,预判不许变小 */
    public static int smooth(ParamSet ps) {
        if (ps == null) return 0;
        ps.sortByDistance();
        int n = 0;
        for (int i = 1; i < ps.segments.size(); i++) {
            Segment prev = ps.segments.get(i - 1), cur = ps.segments.get(i);
            if (cur.predict < prev.predict - 0.0005f) {
                cur.predict = prev.predict;
                n++;
            }
        }
        return n;
    }

    /* ==================== 报告 ==================== */

    public static String text(Diag d, int minConf) {
        if (d == null) return "还没推演。";
        StringBuilder sb = new StringBuilder();
        sb.append("【思考过程】\n");
        for (String s : d.thoughts) sb.append("· ").append(s).append("\n");
        if (!d.warnings.isEmpty()) {
            sb.append("\n【要留意的】\n");
            for (String s : d.warnings) sb.append("! ").append(s).append("\n");
        }
        sb.append("\n【改动清单】(按把握度筛选:").append(minConf).append("+)\n");
        int n = 0;
        for (Item it : d.items) {
            if (!it.changed()) continue;
            sb.append(it.conf >= minConf ? "[√] " : "[ ] ")
                    .append(it.line()).append("  把握度 ").append(it.conf).append("%\n")
                    .append("      ").append(it.reason).append("\n");
            n++;
        }
        if (n == 0) sb.append("· 没有需要改的\n");
        return sb.toString().trim();
    }

    /* ==================== 工具 ==================== */

    private static Analysis.SegRow findRow(Analysis.Report rep, float distance) {
        if (rep == null || rep.rows == null) return null;
        for (Analysis.SegRow row : rep.rows) {
            if (row != null && Math.abs(row.distance - distance) < 0.6f) return row;
        }
        return null;
    }
}

package com.feiniao.tuner.core;

import com.feiniao.tuner.model.ParamSet;
import com.feiniao.tuner.model.Segment;

import java.util.ArrayList;
import java.util.List;

/**
 * 自动生成参数 / 一键调节 / 横向衰减。
 *
 * 生成口径:
 *   预判 = 理论预判(距离 ÷ 弹速 × 人物横移 ÷ 身位当量) + 武器下坠补偿 + 武器提前量差
 *   横向衰减 —— 只有人物速度落在 19 / 20 这两档(打顶飞那两档)才给值,其余档位一律 0。
 */
public final class AutoTune {

    private AutoTune() {}

    /* ================= 横向衰减(打顶飞专用) ================= */

    /**
     * 横向衰减:人物速度 19 / 20 档(打顶飞那两档)才需要动。
     * 其余档位返回 0 = 不用碰。
     */
    public static float lateralDecay(float charSpeed, float distance) {
        float k;
        if (Math.abs(charSpeed - 20f) < 0.5f) k = 1.25f;        // 20 档(打顶飞上限)
        else if (Math.abs(charSpeed - 19f) < 0.5f) k = 1.0f;    // 19 档(打顶飞)
        else return 0f;
        float v = 0.02f * (distance / 100f) * k;
        if (v > 0.5f) v = 0.5f;
        return Math.round(v * 100f) / 100f;
    }

    /** 该速度档是不是打顶飞档(19 / 20) */
    public static boolean topFly(float charSpeed) {
        return Physics.hitSpeedBracket(charSpeed);
    }

    /* ================= 预判计算 ================= */

    /** 单段的完整预判(理论 + 下坠 + 武器提前量差) */
    public static float predictFor(ParamSet ps, WeaponPreset w, float distance,
                                   float charSpeed, float bulletSpeed, boolean useSlotGap) {
        float base = Physics.requiredPredict(ps, distance, charSpeed, bulletSpeed);
        if (w != null) {
            base += w.dropLead(distance);
            if (useSlotGap) base += w.slotGap;
        }
        if (base < 0f) base = 0f;
        return Physics.quantize(base);
    }

    /** 按当前参数表里那一段的设置算预判 */
    public static float predictFor(ParamSet ps, WeaponPreset w, Segment s, boolean useSlotGap) {
        if (s == null) return 0f;
        return predictFor(ps, w, s.distance, s.charSpeed, s.bulletSpeed, useSlotGap);
    }

    /* ================= 自动生成 ================= */

    /**
     * 按距离区间自动铺一张参数表。
     *
     * @param baseBullet 基础参考弹速
     * @param dFrom      起始距离(米,可自己调)
     * @param dTo        结束距离(米,可自己调)
     * @param step       每档间隔(米)
     * @param charSpeed  人物速度(可自己调,19 / 20 = 打顶飞)
     */
    public static List<Segment> generate(float baseBullet, float dFrom, float dTo, float step,
                                         float charSpeed, WeaponPreset w, boolean useSlotGap,
                                         ParamSet ps) {
        List<Segment> out = new ArrayList<Segment>();
        if (step < 5f) step = 5f;
        if (dTo < dFrom) { float t = dFrom; dFrom = dTo; dTo = t; }
        if (dTo - dFrom > 4000f) dTo = dFrom + 4000f;

        int guard = 0;
        for (float d = dFrom; d <= dTo + 0.01f && guard < 400; d += step, guard++) {
            float dist = Math.round(d * 10f) / 10f;
            float bs = w != null ? w.bulletSpeedAt(baseBullet, dist)
                    : Math.round(baseBullet * 10f) / 10f;
            float pred = predictFor(ps, w, dist, charSpeed, bs, useSlotGap);
            float hd = lateralDecay(charSpeed, dist);
            out.add(new Segment(dist, charSpeed, bs, pred, hd,
                    Math.max(1f, Math.round(step / 5f))));
        }
        return out;
    }

    /** 用生成的表覆盖当前方案,保留方案名等全局项 */
    public static void apply(ParamSet ps, List<Segment> segs) {
        if (ps == null || segs == null || segs.isEmpty()) return;
        ps.segments.clear();
        ps.segments.addAll(segs);
        ps.sortByDistance();
        float hi = 0f;
        for (Segment s : ps.segments) if (s.distance > hi) hi = s.distance;
        if (hi > 0f) ps.totalDistance = hi;
    }

    /* ================= 一键调节 ================= */

    /**
     * 一键调节:把整张表按目标口径重算一遍。
     *
     * @param rep        视频分析报告(可为 null = 纯理论重算)
     * @param useMeasure 有实测建议值的段优先用实测
     * @return 改动了几段
     */
    public static int oneKey(ParamSet ps, WeaponPreset w, boolean useSlotGap,
                             Analysis.Report rep, boolean useMeasure) {
        if (ps == null) return 0;
        int n = 0;
        for (Segment s : ps.segments) {
            float target;

            Float measured = null;
            if (useMeasure && rep != null) {
                for (Analysis.SegRow row : rep.rows) {
                    if (Math.abs(row.distance - s.distance) < 0.5f && row.samples > 0) {
                        measured = row.suggest;
                        break;
                    }
                }
            }

            if (measured != null) {
                target = Physics.quantize(measured);
            } else {
                float bs = w != null ? w.bulletSpeedAt(ps.bulletRef, s.distance) : s.bulletSpeed;
                s.bulletSpeed = bs;
                target = predictFor(ps, w, s.distance, s.charSpeed, bs, useSlotGap);
            }

            if (Math.abs(target - s.predict) > 0.0005f) {
                s.predict = target;
                n++;
            }

            float hd = lateralDecay(s.charSpeed, s.distance);
            if (Math.abs(hd - s.hDecay) > 0.0005f) {
                s.hDecay = hd;
                n++;
            }
        }
        ps.sortByDistance();
        return n;
    }

    /** 只重算横向衰减(打顶飞那两档) */
    public static int recalcDecay(ParamSet ps) {
        if (ps == null) return 0;
        int n = 0;
        for (Segment s : ps.segments) {
            float hd = lateralDecay(s.charSpeed, s.distance);
            if (Math.abs(hd - s.hDecay) > 0.0005f) {
                s.hDecay = hd;
                n++;
            }
        }
        return n;
    }

    /* ================= ini 体积 ================= */

    /** 当前参数推到游戏里那份 ini 的字节数(UTF-8) */
    public static int iniSize(ParamSet ps, String template) {
        try {
            String t = (template == null || template.trim().isEmpty())
                    ? IniBuilder.DEFAULT_TEMPLATE : template;
            return IniBuilder.build(ps, t).getBytes("UTF-8").length;
        } catch (Throwable t) {
            return 0;
        }
    }

    /** 人类可读的体积 */
    public static String sizeText(int bytes) {
        if (bytes <= 0) return "—";
        if (bytes < 1024) return bytes + " B";
        return (Math.round(bytes / 1024f * 100f) / 100f) + " KB";
    }

    /** 当前参数的横向衰减一览(只列打顶飞那两档) */
    public static String decayText(ParamSet ps) {
        if (ps == null || ps.segments.isEmpty()) return "还没有分段";
        StringBuilder sb = new StringBuilder();
        int n = 0;
        for (Segment s : ps.segments) {
            if (!topFly(s.charSpeed)) continue;
            if (n > 0) sb.append(" · ");
            sb.append(Segment.trim(s.distance)).append("m:").append(Segment.trim(s.hDecay));
            n++;
        }
        if (n == 0) return "当前没有 19 / 20 档(打顶飞)的分段,不用动横向衰减";
        return sb.toString();
    }
}

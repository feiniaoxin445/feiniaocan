package com.feiniao.tuner.core;

import java.util.ArrayList;
import java.util.List;

/** 分析结果数据模型 */
public final class Analysis {

    private Analysis() {}

    /** 单帧采样 */
    public static class Sample {
        public int idx;
        public long tMs;
        public boolean hasBullet;
        public float bx, by;
        public int bulletType = -1;
        public boolean hasLead;
        public float lx, ly;
        public float frameW, frameH;
    }

    /** 一次交火(一串连续子弹轨迹) */
    public static class Burst {
        public int frames;
        public float trackLenPx;
        public float flightSec;
        public float estDistance;
        public float charSpeed;
        public float needPredict;
        public float leadMovePx;
        public float bulletPxPerSec;
        public int startIdx, endIdx;
        public boolean valid;
        public String reject;

        /** 命中判定:这次交火里测到了紫色预判点(即预判成立 → 打中) */
        public boolean hit;
        /** 归属的速度档(用于命中统计分组) */
        public float grpCharSpeed;
        public float grpBulletSpeed;
        /** 交火发生的时刻(毫秒),用于排序展示 */
        public long atMs;
        /** 这次交火的方向角(度):弹道相对画面水平轴的夹角 */
        public float angleDeg;
        /** 斜向系数 cos(方向角):1 = 正横 */
        public float slant = 1f;
        /** 视角偏移(度):交火点偏离画面中心多少度 */
        public float offsetDeg;
    }

    /** 按「人物速度 × 子弹速度」组合的命中统计 */
    public static class HitGroup {
        public float charSpeed;                      // 人物速度档
        public float bulletSpeed;                    // 子弹速度档
        public final List<Float> hitDist = new ArrayList<>();   // 打中的距离
        public final List<Float> missDist = new ArrayList<>();  // 没打中的距离

        public int volley() { return hitDist.size() + missDist.size(); }

        public float hitAvg() { return avg(hitDist); }

        public float missAvg() { return avg(missDist); }

        public int rate() {
            int n = volley();
            return n == 0 ? 0 : Math.round(hitDist.size() * 100f / n);
        }

        private static float avg(List<Float> l) {
            if (l.isEmpty()) return 0f;
            float s = 0;
            for (float v : l) s += v;
            return s / l.size();
        }
    }

    /** 距离概括:总距离、覆盖情况、命中/未命中的距离分布 */
    public static class DistSummary {
        public float total;          // 参数表总距离
        public int segCount;         // 参数表分段数
        public float segMin, segMax; // 分段最小 / 最大距离
        public float avgGap;         // 平均分段间隔

        public int volley;           // 实测交火总数
        public float mMin, mMax;     // 实测覆盖到的距离范围
        public boolean measured;

        public final List<Float> hitDist = new ArrayList<>();
        public final List<Float> missDist = new ArrayList<>();

        public float hitMin, hitMax, missMin, missMax;
        public boolean hasHit, hasMiss;

        /** 距离格:用于覆盖率与热力条 */
        public int cells;
        public float cellW;
        public int[] cellHit = new int[0];
        public int[] cellTotal = new int[0];

        /** 未覆盖区间 [from, to] */
        public final List<float[]> dead = new ArrayList<>();

        /** 按 人物速度 × 子弹速度 的分档统计 */
        public final List<HitGroup> groups = new ArrayList<>();

        /** 命中率 0~100 */
        public int rate() {
            int n = hitDist.size() + missDist.size();
            return n == 0 ? 0 : Math.round(hitDist.size() * 100f / n);
        }

        public void noteHit(float v) {
            if (!hasHit) { hitMin = v; hitMax = v; hasHit = true; }
            else { if (v < hitMin) hitMin = v; if (v > hitMax) hitMax = v; }
        }

        public void noteMiss(float v) {
            if (!hasMiss) { missMin = v; missMax = v; hasMiss = true; }
            else { if (v < missMin) missMin = v; if (v > missMax) missMax = v; }
        }
    }

    /** 按分段汇总的一行 */
    public static class SegRow {
        public float distance;
        public float charSpeed;      // 实测人物速度均值
        public float bulletSpeed;    // 该段参考子弹速度
        public float need;           // 实测所需预判(身位)
        public float cur;            // 参数当前预判
        public float diff;           // need - cur
        public float suggest;        // 建议预判值
        public int samples;
        public boolean hDecay;
        public int sumVerdict;
        public boolean theory;       // true = 未测到预判点,该行为理论推算

        public boolean empty() { return samples == 0; }
    }

    /** 整份报告 */
    public static class Report {
        public int framesTotal;
        public int bulletFrames;
        public int leadFrames;
        public int bursts;
        public int validBursts;
        public float fps;
        public long durationMs;
        public float pxPerMeter;
        public float estDistance;
        public String error;
        public final List<SegRow> rows = new ArrayList<>();
        public final List<Burst> burstList = new ArrayList<>();
        public final List<String> logs = new ArrayList<String>();
        /** 总距离概括 + 命中统计 */
        public final DistSummary dist = new DistSummary();
        /** 角度 / 视角偏移汇总 */
        public int angleSamples;
        public float angleSum;
        public float slantSum;
        public float offsetSum;
        public float angleAvgDeg;
        public float slantAvg = 1f;
        public float offsetAvgDeg;

        public void log(String s) {
            logs.add(s);
        }
    }
}

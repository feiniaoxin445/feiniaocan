package com.feiniao.tuner.core;

/**
 * 武器调参思路(口径版本:超自然)。
 *
 * 这一版的手感口径:
 *   · 猎枪 —— 子弹速度比左轮慢一截,140 米往上下坠明显,所以这一档的「子弹速度」参数要往下压,
 *             靠飞行时间把下坠量吃进预判里;同距离下猎枪要比左轮多给一点提前量。
 *   · 左轮 —— 子弹速度比猎枪快一点,提前量差不多差一个半身位,是这三档里的基准。
 *   · 步枪 —— 通用档,弹速居中,不做下坠补偿。
 *
 * ⚠ 版本提醒:以上只是「超自然」这一版的手感。下一版很可能反过来
 *   (弹速对调、下坠起始距离改、横向衰减档位换),换版本之后先跑一次视频调参重新校准,
 *   别直接沿用这一版数值。
 */
public final class WeaponPreset {

    /** 当前口径所属的版本 */
    public static final String VERSION = "超自然";

    public static final String VERSION_NOTE =
            "当前口径 = 超自然版:猎枪弹速慢、140 米起下坠,弹速要往下压;"
                    + "左轮比猎枪快一点,提前量差一个半身位左右。"
                    + "这套手感下一版很可能反过来,换版本先跑视频调参重新校准,别照搬。";

    public static final String ID_RIFLE = "rifle";
    public static final String ID_REVOLVER = "revolver";
    public static final String ID_SHOTGUN = "shotgun";

    public final String id;
    public final String name;
    /** 子弹速度系数:叠在方案的参考弹速上 */
    public final float bulletFactor;
    /** 下坠起始距离(米),0 = 不下坠 */
    public final float dropFrom;
    /** 超过下坠起始距离后,每米补多少身位 */
    public final float dropPerMeter;
    /** 相对基准(左轮)的提前量差(身位),正数 = 需要多给 */
    public final float slotGap;
    /** 这套思路的一句话说明 */
    public final String idea;

    private WeaponPreset(String id, String name, float bulletFactor,
                         float dropFrom, float dropPerMeter, float slotGap, String idea) {
        this.id = id;
        this.name = name;
        this.bulletFactor = bulletFactor;
        this.dropFrom = dropFrom;
        this.dropPerMeter = dropPerMeter;
        this.slotGap = slotGap;
        this.idea = idea;
    }

    /** 左轮:基准档,弹速比猎枪快 */
    public static final WeaponPreset REVOLVER = new WeaponPreset(
            ID_REVOLVER, "左轮", 1.00f, 0f, 0f, 0f,
            "左轮是基准。弹速比猎枪快一点,同一段距离、同一个人物速度下,"
                    + "左轮要的提前量比猎枪少差不多一个半身位。预判按理论值走,不做额外下坠补偿。");

    /** 猎枪:弹速慢,140 米起下坠 */
    public static final WeaponPreset SHOTGUN = new WeaponPreset(
            ID_SHOTGUN, "猎枪", 0.80f, 140f, 0.0035f, 1.5f,
            "猎枪弹速比左轮慢,140 米往上下坠,所以子弹速度参数要往下压 —— 弹速压低 = 飞行时间变长,"
                    + "预判自然变大,把下坠和下坠带来的提前量一起吃掉。140 米之后每米再补一点纵向量。");

    /** 步枪:通用档 */
    public static final WeaponPreset RIFLE = new WeaponPreset(
            ID_RIFLE, "通用 / 步枪", 1.06f, 0f, 0f, -0.2f,
            "通用档,弹速比左轮略快,不下坠。换枪但没摸清手感时先用这一档打底。");

    public static WeaponPreset[] all() {
        return new WeaponPreset[]{REVOLVER, SHOTGUN, RIFLE};
    }

    public static WeaponPreset byId(String id) {
        if (ID_SHOTGUN.equals(id)) return SHOTGUN;
        if (ID_RIFLE.equals(id)) return RIFLE;
        return REVOLVER;
    }

    public static String[] names() {
        WeaponPreset[] a = all();
        String[] out = new String[a.length];
        for (int i = 0; i < a.length; i++) out[i] = a[i].name;
        return out;
    }

    public static int indexOf(String id) {
        WeaponPreset[] a = all();
        for (int i = 0; i < a.length; i++) if (a[i].id.equals(id)) return i;
        return 0;
    }

    /** 该武器在某段距离上的子弹速度 */
    public float bulletSpeedAt(float baseBullet, float distance) {
        float v = baseBullet * bulletFactor;
        // 猎枪这类弹速慢的,越远越压一点,模拟下坠
        if (dropFrom > 0f && distance > dropFrom) {
            float over = (distance - dropFrom) / 100f;
            v *= Math.max(0.72f, 1f - 0.045f * over);
        }
        return Math.max(120f, Math.round(v * 10f) / 10f);
    }

    /** 该武器在某段距离上要额外补偿的纵向量(身位) */
    public float dropLead(float distance) {
        if (dropFrom <= 0f || distance <= dropFrom) return 0f;
        return (distance - dropFrom) * dropPerMeter;
    }
}

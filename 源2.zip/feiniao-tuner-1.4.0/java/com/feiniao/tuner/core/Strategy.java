package com.feiniao.tuner.core;

import com.feiniao.tuner.model.ParamSet;
import com.feiniao.tuner.model.Segment;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 思路导入调参 —— 把人话解析成口径,再按口径把整张表铺出来。
 *
 * 用法:
 *   Strategy.Brief b = Strategy.parse(用户输入的一段思路, ps);
 *   Strategy.applyEnv(b, ps);                 // 把思路里的全局项(武器 / 身位 / 换算)落到方案上
 *   List&lt;Segment&gt; segs = Strategy.plan(b, ps, w);   // 按思路铺表
 *
 * 解析走的全是规则,不需要联网、不需要模型:关键词命中 → 口径项,
 * 每个口径项都有明确的数值含义,解析结果会原样回显给用户核对,可手动改。
 */
public final class Strategy {

    /* ==================== 解析结果 ==================== */

    /** 一段思路解析出来的口径 */
    public static class Brief {
        public String raw = "";

        /* 全局项 */
        public String weaponId = "";
        public boolean hasWeapon = false;
        public float bodyWidth = 0f;        // >0 覆盖身位当量
        public float bulletRef = 0f;        // >0 覆盖参考弹速
        public float speedScale = 0f;       // >0 覆盖速度换算

        /* 表结构 */
        public float dFrom = 0f;
        public float dTo = 0f;
        public float dStep = 0f;
        public float sub = 0f;              // 小距离(细分步长),0 = 自动

        /* 手感项 */
        public float charSpeed = 0f;        // >0 目标速度档
        public float bulletBias = 0f;       // 弹速偏移:±0.05 = 快/慢 5%
        public float gapScale = 0f;         // 提前量整体倍率,>0 生效
        public float gapAdd = 0f;           // 提前量整体增量(身位)
        public float dropFrom = -1f;        // 下坠起始距离,>=0 覆盖武器曲线
        public float dropPerMeter = -1f;    // 下坠后每米补偿(身位)
        public float decayScale = -1f;      // 横向衰减倍率
        public float decayFixed = -1f;      // 横向衰减固定值
        public float angleDeg = 0f;         // 视角 / 角度偏移(度)
        public int useSlotGap = -1;         // -1 不改 / 1 用武器提前量差 / 0 不用

        /* 解析痕迹 */
        public final List<String> hits = new ArrayList<String>();
        public final List<String> notes = new ArrayList<String>();
        public int confidence = 0;

        public boolean empty() { return hits.isEmpty(); }

        public boolean hasPlan() { return dStep > 0f && dTo > dFrom; }

        /** 目标速度档是不是打顶飞档 */
        public boolean topFly() { return Physics.hitSpeedBracket(charSpeed); }
    }

    /** 距离区间解析结果的兜底 */
    private static final float[] RANGE_EMPTY = new float[]{0f, 0f, 0f};

    private Strategy() {}

    /* ==================== 文本归一化 ==================== */

    public static String norm(String s) {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch >= '０' && ch <= '９') ch = (char) ('0' + (ch - '０'));
            else if (ch == '．') ch = '.';
            else if (ch == '　') ch = ' ';
            else if (ch == '，') ch = ',';
            else if (ch == '：') ch = ':';
            else if (ch == '（') ch = '(';
            else if (ch == '）') ch = ')';
            sb.append(Character.toLowerCase(ch));
        }
        return sb.toString();
    }

    private static boolean has(String t, String... keys) {
        for (String k : keys) if (t.indexOf(k) >= 0) return true;
        return false;
    }

    /* ==================== 解析 ==================== */

    /**
     * 解析一段人话思路。
     *
     * @param text 用户输入
     * @param ps   当前方案(用于兜底距离区间、身位当量这些)
     */
    public static Brief parse(String text, ParamSet ps) {
        Brief b = new Brief();
        if (text == null) text = "";
        b.raw = text;
        String t = norm(text);
        if (t.trim().isEmpty()) {
            b.notes.add("还没写思路 —— 在输入框里写一段,或者点「填个示例」看看能识别哪些说法。");
            return b;
        }

        int score = 0;

        /* ---------- ① 武器 / 口径 ---------- */
        if (has(t, "猎枪", "霰弹", "喷子", "shotgun")) {
            b.weaponId = WeaponPreset.ID_SHOTGUN;
            b.hasWeapon = true;
            b.hits.add("武器 → 猎枪(弹速慢、远距离下坠)");
            score += 18;
        } else if (has(t, "左轮", "手枪", "revolver")) {
            b.weaponId = WeaponPreset.ID_REVOLVER;
            b.hasWeapon = true;
            b.hits.add("武器 → 左轮(基准档,提前量最小)");
            score += 18;
        } else if (has(t, "步枪", "通用", "冲锋", "rifle")) {
            b.weaponId = WeaponPreset.ID_RIFLE;
            b.hasWeapon = true;
            b.hits.add("武器 → 通用 / 步枪(弹速居中)");
            score += 15;
        }

        /* ---------- ② 距离区间 + 间隔 + 小距离 ---------- */
        float[] rng = parseRange(t);
        b.dFrom = rng[0];
        b.dTo = rng[1];
        b.dStep = rng[2];
        if (b.dStep > 0f && b.dTo > b.dFrom) {
            b.hits.add("距离 → " + fmt0(b.dFrom) + "~" + fmt0(b.dTo) + "m,每 "
                    + fmt0(b.dStep) + "m 一档");
            score += 22;
        } else if (b.dFrom > 0f || b.dTo > 0f) {
            b.notes.add("距离只认了一半(缺起止或间隔),已按当前表的范围兜底。");
            score += 8;
        }

        float sub = numAfter(t, new String[]{"小距离", "细分", "细分步长", "微调距离"}, 0f);
        if (sub > 0f) {
            b.sub = clamp(sub, 0.5f, 200f);
            b.hits.add("小距离 → 每 " + trim(b.sub) + "m 一个微调档");
            score += 12;
        }

        /* ---------- ③ 目标速度档 ---------- */
        float cs = numAfter(t, new String[]{"人物速度", "目标速度", "角色速度", "移动速度"}, 0f);
        if (cs <= 0f) {
            Matcher m = Pattern.compile("(1[5-9](?:\\.\\d)?|20(?:\\.\\d)?)\\s*档").matcher(t);
            if (m.find()) cs = f(m.group(1));
        }
        if (cs <= 0f && has(t, "打顶飞", "顶飞")) {
            cs = has(t, "20", "上限", "最快") ? 20f : 19f;
            b.hits.add("目标速度 → 打顶飞 " + trim(cs) + " 档(横向衰减要动)");
            score += 16;
        } else if (cs > 0f) {
            b.charSpeed = clamp(cs, 1f, 40f);
            b.hits.add("目标速度 → " + trim(b.charSpeed) + " 档"
                    + (Physics.hitSpeedBracket(b.charSpeed) ? "(打顶飞,要动横向衰减)" : "(常规档)"));
            score += 16;
        }

        /* ---------- ④ 弹速取向 ---------- */
        float bias = 0f;
        if (has(t, "弹速快", "枪快", "弹速提", "提速", "弹速加", "弹速往上", "快弹")) {
            bias += 0.06f;
        }
        if (has(t, "弹速慢", "慢枪", "压弹速", "弹速压", "往下压", "降速", "弹速降", "慢弹")) {
            bias -= 0.09f;
        }
        float bf = numAfter(t, new String[]{"弹速系数", "弹速倍率", "弹速x", "弹速×"}, 0f);
        if (bf > 0.2f && bf < 4f) {
            bias = bf - 1f;
            b.hits.add("弹速倍率 → " + trim(bf) + " 倍");
            score += 12;
        } else if (bias != 0f) {
            b.hits.add("弹速取向 → " + (bias > 0 ? "往上提" : "往下压")
                    + " " + trim(Math.abs(bias) * 100f) + "%");
            score += 10;
        }
        b.bulletBias = bias;

        float ref = numAfter(t, new String[]{"参考弹速", "基准弹速", "弹速基准"}, 0f);
        if (ref > 100f && ref < 3000f) {
            b.bulletRef = ref;
            b.hits.add("参考弹速 → " + fmt0(ref) + " m/s");
            score += 8;
        }

        /* ---------- ⑤ 下坠 ---------- */
        float dropFrom = numAfter(t, new String[]{"下坠起始", "开始下坠", "起下坠", "下坠从"}, -1f);
        if (dropFrom < 0f) {
            Matcher m = Pattern.compile("(\\d{2,4})\\s*米?\\s*(?:开始|起|后)?\\s*下坠").matcher(t);
            if (m.find()) dropFrom = f(m.group(1));
        }
        if (dropFrom < 0f && has(t, "下坠")) {
            Matcher m = Pattern.compile("下坠[^0-9]{0,6}(\\d{2,4})").matcher(t);
            if (m.find()) dropFrom = f(m.group(1));
        }
        if (has(t, "不下坠", "无下坠", "没有下坠", "不下掉")) {
            b.dropFrom = 0f;
            b.dropPerMeter = 0f;
            b.hits.add("下坠 → 按不下坠处理(纯弹速曲线)");
            score += 10;
        } else if (dropFrom >= 0f) {
            b.dropFrom = clamp(dropFrom, 0f, 2000f);
            float per = numAfter(t, new String[]{"每米补", "每米加", "每米补偿", "下坠系数"}, -1f);
            b.dropPerMeter = per > 0f ? per : 0.0035f;
            b.hits.add("下坠 → " + fmt0(b.dropFrom) + "m 起,每米补 "
                    + trim(b.dropPerMeter) + " 身位");
            score += 12;
        }

        /* ---------- ⑥ 提前量整体加减 ---------- */
        float gs = 0f, ga = 0f;
        Matcher pm = Pattern.compile("(提前量|预判)[^0-9%]{0,8}(\\d+(?:\\.\\d+)?)\\s*%").matcher(t);
        if (pm.find()) {
            float pct = f(pm.group(2));
            boolean up = has(t, "加", "放", "提", "涨", "多");
            gs = 1f + (up ? pct : -pct) / 100f;
            b.hits.add("提前量 → 整体" + (up ? "放大 " : "缩小 ") + fmt0(pct) + "%");
            score += 14;
        }
        Matcher xm = Pattern.compile("(提前量|预判)[^0-9]{0,8}(\\d+(?:\\.\\d+)?)\\s*(?:倍|x|×)").matcher(t);
        if (xm.find()) {
            float mul = f(xm.group(2));
            if (mul > 0.2f && mul < 4f) {
                gs = mul;
                b.hits.add("提前量 → 整体 ×" + trim(mul));
                score += 14;
            }
        }
        if (gs == 0f) {
            if (has(t, "提前量多一点", "预判大一点", "加大提前量", "加大预判", "预判加大",
                    "提前量加大", "多给一点", "往上加一点", "提前量往上")) {
                gs = 1.08f;
                b.hits.add("提前量 → 整体抬 8%(“多一点”按 8% 记)");
                score += 12;
            } else if (has(t, "提前量小一点", "预判小一点", "减小提前量", "减小预判", "预判减小",
                    "少给一点", "往下减一点", "提前量往下")) {
                gs = 0.92f;
                b.hits.add("提前量 → 整体压 8%(“少一点”按 8% 记)");
                score += 12;
            }
        }
        Matcher am = Pattern.compile("(?:加|多给|补|再给)\\s*(\\d+(?:\\.\\d+)?)\\s*个?身位").matcher(t);
        if (am.find()) {
            ga = f(am.group(1));
            b.hits.add("提前量 → 每档整体 +" + trim(ga) + " 身位");
            score += 12;
        }
        b.gapScale = gs;
        b.gapAdd = ga;

        /* ---------- ⑦ 横向衰减 ---------- */
        if (has(t, "衰减归零", "衰减清零", "不要衰减", "去掉衰减", "衰减去掉", "衰减设0")) {
            b.decayFixed = 0f;
            b.hits.add("横向衰减 → 全部归零");
            score += 8;
        } else {
            float fx = numAfter(t, new String[]{"衰减固定", "衰减值", "衰减设", "衰减改"}, -1f);
            if (fx >= 0f && fx <= 1f) {
                b.decayFixed = fx;
                b.hits.add("横向衰减 → 固定 " + trim(fx));
                score += 8;
            } else if (has(t, "衰减大", "衰减加", "衰减提高", "衰减往上")) {
                b.decayScale = 1.2f;
                b.hits.add("横向衰减 → 整体 ×1.2");
                score += 8;
            } else if (has(t, "衰减小", "衰减减", "衰减降低", "衰减往下")) {
                b.decayScale = 0.8f;
                b.hits.add("横向衰减 → 整体 ×0.8");
                score += 8;
            }
        }

        /* ---------- ⑧ 视角 / 角度偏移 ---------- */
        float ang = numAfter(t, new String[]{"视角偏移", "角度偏移", "偏角", "视角", "斜向角度",
                "角度补偿", "斜着打"}, -1f);
        if (ang < 0f) {
            Matcher m = Pattern.compile("(\\d+(?:\\.\\d+)?)\\s*(?:度|°)").matcher(t);
            if (m.find()) ang = f(m.group(1));
        }
        if (ang >= 0f) {
            b.angleDeg = clamp(ang, 0f, 75f);
            b.hits.add("视角 / 角度偏移 → " + trim(b.angleDeg) + "°(预判按 1/cos 放大 "
                    + trim(angleFactor(b.angleDeg) * 100f - 100f) + "%)");
            score += 10;
        } else if (has(t, "斜向交火", "斜着打", "角度对不齐", "视角对不上")) {
            b.angleDeg = 12f;
            b.hits.add("视角 / 角度偏移 → 没给度数,按经验 12° 记");
            score += 8;
        }

        /* ---------- ⑨ 提前量差 ---------- */
        if (has(t, "不要提前量差", "不用提前量差", "去掉提前量差", "不加提前量差")) {
            b.useSlotGap = 0;
            b.hits.add("武器提前量差 → 不加");
            score += 6;
        } else if (has(t, "加提前量差", "用提前量差", "带提前量差")) {
            b.useSlotGap = 1;
            b.hits.add("武器提前量差 → 加上");
            score += 6;
        }

        /* ---------- ⑩ 全局量 ---------- */
        float bw = numAfter(t, new String[]{"身位当量", "一个身位"}, 0f);
        if (bw > 0.01f && bw < 20f) {
            b.bodyWidth = bw;
            b.hits.add("身位当量 → " + trim(bw) + " m");
            score += 8;
        }
        float sc = numAfter(t, new String[]{"速度换算", "换算系数"}, 0f);
        if (sc > 0.001f && sc < 20f) {
            b.speedScale = sc;
            b.hits.add("速度换算 → " + trim(sc) + " m/s 每档");
            score += 6;
        }

        /* ---------- 兜底 ---------- */
        if (b.dStep <= 0f || b.dTo <= b.dFrom) {
            float fallbackFrom = ps != null && ps.segments.size() > 0 ? ps.segments.get(0).distance : 50f;
            float fallbackTo = ps != null && ps.totalDistance > 0 ? ps.totalDistance : 400f;
            if (b.dFrom <= 0f) b.dFrom = fallbackFrom;
            if (b.dTo <= b.dFrom) b.dTo = fallbackTo;
            if (b.dStep <= 0f) b.dStep = guessStep(b.dTo - b.dFrom);
        }
        if (b.sub <= 0f) b.sub = Math.max(1f, Math.round(b.dStep / 5f));

        if (b.hits.isEmpty()) {
            b.notes.add("这段话里没读到能落地的口径项 —— 试试写「猎枪,150 到 600 米,每 25 米一档,"
                    + "打顶飞 19 档,提前量整体加 10%,140 米起下坠」这种。");
        }
        if (score > 100) score = 100;
        b.confidence = score;
        return b;
    }

    /**
     * 把思路里的全局项落到方案上(武器 / 参考弹速 / 身位当量 / 换算 / 口径版本)。
     */
    public static void applyEnv(Brief b, ParamSet ps) {
        if (b == null || ps == null) return;
        if (b.hasWeapon) ps.weapon = b.weaponId;
        if (b.bulletRef > 0f) ps.bulletRef = b.bulletRef;
        if (b.bodyWidth > 0f) ps.bodyWidth = b.bodyWidth;
        if (b.speedScale > 0f) ps.speedScale = b.speedScale;
        ps.versionTag = WeaponPreset.VERSION;
    }

    /* ==================== 按思路铺表 ==================== */

    /** 按思路铺一张参数表(不直接改方案,交给 AutoTune.apply 落表) */
    public static List<Segment> plan(Brief b, ParamSet ps, WeaponPreset w) {
        List<Segment> out = new ArrayList<Segment>();
        if (b == null || ps == null) return out;

        float from = b.dFrom > 0f ? b.dFrom : 50f;
        float to = b.dTo > from ? b.dTo : from + 200f;
        float step = b.dStep > 0f ? b.dStep : guessStep(to - from);

        WeaponPreset wp = b.hasWeapon ? WeaponPreset.byId(b.weaponId)
                : (w != null ? w : WeaponPreset.REVOLVER);
        boolean slot = b.useSlotGap >= 0 ? b.useSlotGap == 1 : true;

        float base = b.bulletRef > 0f ? b.bulletRef : ps.bulletRef;
        float angK = angleFactor(b.angleDeg);
        float gs = b.gapScale > 0f ? b.gapScale : 1f;

        int guard = 0;
        for (float d = from; d <= to + 0.01f && guard < 600; d += step, guard++) {
            float dist = Math.round(d * 10f) / 10f;
            float cs = b.charSpeed > 0f ? b.charSpeed : csAt(ps, dist);
            float bs = wp.bulletSpeedAt(base, dist) * (1f + b.bulletBias);
            bs = Math.max(120f, Math.round(bs * 10f) / 10f);

            float need = Physics.requiredPredict(ps, dist, cs, bs);
            need += slot ? wp.slotGap : 0f;

            /* 下坠:思路里写了就按思路的曲线,没写就用武器曲线 */
            if (b.dropFrom >= 0f) {
                if (dist > b.dropFrom) {
                    float per = b.dropPerMeter >= 0f ? b.dropPerMeter : 0.0035f;
                    need += (dist - b.dropFrom) * per;
                }
            } else {
                need += wp.dropLead(dist);
            }

            need = need * gs + b.gapAdd;
            need *= angK;
            if (need < 0f) need = 0f;
            need = Physics.quantize(need);

            float hd = decay(cs, dist, b);
            out.add(new Segment(dist, cs, bs, need, hd, b.sub));
        }
        return out;
    }

    /** 思路口径下这一档的横向衰减 */
    public static float decay(float charSpeed, float distance, Brief b) {
        if (b != null && b.decayFixed >= 0f) {
            return b.decayFixed;
        }
        float v = AutoTune.lateralDecay(charSpeed, distance);
        if (b != null && b.decayScale > 0f) v = v * b.decayScale;
        return Math.round(clamp(v, 0f, 1f) * 100f) / 100f;
    }

    /** 斜向系数:目标斜着走,横向分量按 cos 缩,反过来预判得按 1/cos 放大 */
    public static float angleFactor(float deg) {
        if (deg <= 0.01f) return 1f;
        double rad = Math.toRadians(clamp(deg, 0f, 80f));
        double c = Math.cos(rad);
        if (c < 0.2) c = 0.2;
        return (float) (1.0 / c);
    }

    /** 把思路概括成几行人话,回显给用户核对 */
    public static String summary(Brief b) {
        if (b == null || b.empty()) return "没解析出内容。";
        StringBuilder sb = new StringBuilder();
        sb.append("识别到 ").append(b.hits.size()).append(" 项口径,把握度 ")
                .append(b.confidence).append("%\n");
        for (String h : b.hits) sb.append("· ").append(h).append("\n");
        sb.append("\n落表规则:").append(fmt0(b.dFrom)).append("~").append(fmt0(b.dTo))
                .append("m,每 ").append(trim(b.dStep)).append("m 一档,小距离 ")
                .append(trim(b.sub)).append("m");
        if (!b.notes.isEmpty()) {
            sb.append("\n");
            for (String n : b.notes) sb.append("注:").append(n).append("\n");
        }
        return sb.toString().trim();
    }

    /* ==================== 小工具 ==================== */

    private static float[] parseRange(String t) {
        float[] v = new float[]{0f, 0f, 0f};
        /* 距离区间 */
        Matcher m = Pattern.compile("(\\d{1,4})\\s*(?:米)?\\s*(?:-|~|—|到|至|→)\\s*(\\d{1,4})\\s*米")
                .matcher(t);
        if (!m.find()) {
            m = Pattern.compile("(\\d{1,4})\\s*米?\\s*到\\s*(\\d{1,4})").matcher(t);
        }
        if (m.find() || m.reset().find()) {
            v[0] = f(m.group(1));
            v[1] = f(m.group(2));
            if (v[0] > v[1]) { float tmp = v[0]; v[0] = v[1]; v[1] = tmp; }
        }
        /* 间隔 */
        Matcher s = Pattern.compile("每\\s*(\\d+(?:\\.\\d+)?)\\s*米(?:一档|一档|一个档|一档位|档|一格|间隔)?")
                .matcher(t);
        if (s.find()) {
            float step = f(s.group(1));
            if (step >= 1f && step <= 400f) v[2] = step;
        } else {
            Matcher s2 = Pattern.compile("(?:间隔|步长|每档)\\s*(\\d+(?:\\.\\d+)?)\\s*米").matcher(t);
            if (s2.find()) {
                float step = f(s2.group(1));
                if (step >= 1f && step <= 400f) v[2] = step;
            }
        }
        if (v[2] <= 0f && v[1] > v[0]) {
            /* 用户没写间隔但给了一档数 → 按档数均分 */
            Matcher c = Pattern.compile("(\\d{1,3})\\s*档").matcher(t);
            if (c.find()) {
                int n = (int) f(c.group(1));
                if (n >= 2 && n <= 200) v[2] = Math.max(1f, Math.round((v[1] - v[0]) / (n - 1)));
            }
        }
        return v;
    }

    /** 「关键词 + 后面的数字」取值 */
    private static float numAfter(String t, String[] keys, float def) {
        for (String k : keys) {
            int idx = t.indexOf(k);
            if (idx < 0) continue;
            String tail = t.substring(Math.min(t.length(), idx + k.length()));
            Matcher m = Pattern.compile("^[^0-9]{0,10}?(\\d+(?:\\.\\d+)?)").matcher(tail);
            if (m.find()) return f(m.group(1));
        }
        return def;
    }

    private static float csAt(ParamSet ps, float dist) {
        if (ps != null && !ps.segments.isEmpty()) {
            Segment s = ps.nearest(dist);
            if (s != null) return s.charSpeed;
        }
        return 19f;
    }

    private static float guessStep(float span) {
        if (span <= 0f) return 25f;
        float step = Math.round(span / 16f);
        if (step < 5f) step = 5f;
        if (step > 100f) step = 100f;
        return step;
    }

    public static float clamp(float v, float lo, float hi) {
        if (v < lo) return lo;
        if (v > hi) return hi;
        return v;
    }

    private static float f(String s) {
        try { return Float.parseFloat(s.trim()); } catch (Throwable t) { return 0f; }
    }

    public static String trim(float v) {
        if (Math.abs(v - Math.round(v)) < 0.001f) return String.valueOf(Math.round(v));
        return String.valueOf(Math.round(v * 100f) / 100f);
    }

    private static String fmt0(float v) { return String.valueOf(Math.round(v)); }
}

package com.feiniao.tuner.core;

/**
 * 最近一次分析结果的共享位。
 *
 * 「调参」页跑完视频分析就放一份在这里,「思路」页的智能推演直接拿来用,
 * 不用来回切页重新导视频。进程内有效,退出应用就没了。
 */
public final class Reports {

    /** 最近一次视频分析报告(可为 null) */
    public static volatile Analysis.Report last;

    /** 最近一次实时识别里测到的角度(度),HUD 写、推演读 */
    public static volatile float liveAngleDeg = 0f;
    public static volatile int liveAngleSamples = 0;

    private Reports() {}

    /** 有没有可用的实测数据 */
    public static boolean hasMeasured() {
        Analysis.Report r = last;
        if (r == null || r.rows == null) return false;
        for (Analysis.SegRow row : r.rows) {
            if (row != null && row.samples > 0 && !row.theory) return true;
        }
        return false;
    }

    /** 一句话说明实测数据的状态,给界面显示 */
    public static String status() {
        Analysis.Report r = last;
        if (r == null) return "还没有实测数据 —— 推演会走理论模型,精度够用但不如实测准。";
        int measured = 0;
        if (r.rows != null) {
            for (Analysis.SegRow row : r.rows) if (row != null && row.samples > 0 && !row.theory) measured++;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("最近一次视频分析:").append(Math.round(r.durationMs / 1000f)).append("s · 有效弹道 ")
                .append(r.validBursts).append("/").append(r.bursts)
                .append(" · 打中 ").append(r.dist != null ? r.dist.hitDist.size() : 0)
                .append(" · 没打中 ").append(r.dist != null ? r.dist.missDist.size() : 0)
                .append(" · 有实测值的段 ").append(measured);
        if (r.angleSamples > 0) {
            sb.append("\n镜头角度:平均 ").append(Physics.fmt(r.angleAvgDeg, 1))
                    .append("° · 斜向系数 ").append(Physics.fmt(r.slantAvg, 2))
                    .append("(").append(r.angleSamples).append(" 次交火)");
        }
        return sb.toString();
    }
}

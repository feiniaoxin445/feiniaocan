package com.feiniao.tuner.core;

import com.feiniao.tuner.model.Segment;

import java.util.ArrayList;
import java.util.List;

/**
 * 总距离概括 + 命中统计。
 *
 * 纯计算,不依赖任何 Android 类,方便离线验证。
 *
 *   ① 把参数表的距离范围概括出来(总距离 / 档数 / 间隔)
 *   ② 把实测交火按距离铺进格子,得到覆盖率与空白区间
 *   ③ 按「人物速度 × 子弹速度」分组,分别记录打中 / 没打中的距离
 */
public final class DistStats {

    /** 距离条切成的格子数 */
    public static final int CELLS = 40;

    private DistStats() {}

    /**
     * @param segments      参数表的分段(可为 null)
     * @param totalDistance 参数表声明的总距离(<=0 时按 400 处理)
     * @param bulletRef     参考子弹速度(没有分段时的兜底)
     * @param rep           分析报告(读 burstList,写 dist)
     */
    public static void build(List<Segment> segments, float totalDistance, float bulletRef,
                             Analysis.Report rep) {
        if (rep == null) return;
        final Analysis.DistSummary d = rep.dist;

        /* ---- ① 参数表总距离概括 ---- */
        d.total = totalDistance > 0 ? totalDistance : 400f;
        if (segments != null && !segments.isEmpty()) {
            d.segCount = segments.size();
            float lo = Float.MAX_VALUE, hi = 0f;
            for (Segment s : segments) {
                if (s == null) continue;
                if (s.distance < lo) lo = s.distance;
                if (s.distance > hi) hi = s.distance;
            }
            if (lo == Float.MAX_VALUE) lo = 0f;
            d.segMin = lo;
            d.segMax = hi;
            d.avgGap = d.segCount > 1 ? (hi - lo) / (d.segCount - 1) : 0f;
        }

        /* ---- ② 距离格子 ---- */
        final float total = Math.max(60f, d.total);
        final int cells = CELLS;
        final float cw = total / cells;
        d.cells = cells;
        d.cellW = cw;
        d.cellHit = new int[cells];
        d.cellTotal = new int[cells];

        java.util.LinkedHashMap<String, Analysis.HitGroup> map =
                new java.util.LinkedHashMap<String, Analysis.HitGroup>();
        d.mMin = Float.MAX_VALUE;

        /* ---- ③ 逐次交火归档 ---- */
        if (rep.burstList != null) {
            for (Analysis.Burst b : rep.burstList) {
                if (b == null) continue;
                if (!(b.estDistance >= 3f && b.estDistance <= 1200f)) continue;

                d.measured = true;
                d.volley++;
                if (b.estDistance < d.mMin) d.mMin = b.estDistance;
                if (b.estDistance > d.mMax) d.mMax = b.estDistance;

                if (b.hit) {
                    d.hitDist.add(b.estDistance);
                    d.noteHit(b.estDistance);
                } else {
                    d.missDist.add(b.estDistance);
                    d.noteMiss(b.estDistance);
                }

                int ci = (int) (b.estDistance / cw);
                if (ci < 0) ci = 0;
                if (ci >= cells) ci = cells - 1;
                d.cellTotal[ci]++;
                if (b.hit) d.cellHit[ci]++;

                final float cs = Math.round(b.grpCharSpeed);
                final float bs = Math.round(b.grpBulletSpeed / 10f) * 10f;
                String key = ((int) cs) + "|" + ((int) bs);
                Analysis.HitGroup g = map.get(key);
                if (g == null) {
                    g = new Analysis.HitGroup();
                    g.charSpeed = cs;
                    g.bulletSpeed = bs;
                    map.put(key, g);
                }
                if (b.hit) g.hitDist.add(b.estDistance);
                else g.missDist.add(b.estDistance);
            }
        }

        List<Analysis.HitGroup> gs = new ArrayList<Analysis.HitGroup>(map.values());
        java.util.Collections.sort(gs, new java.util.Comparator<Analysis.HitGroup>() {
            @Override
            public int compare(Analysis.HitGroup a, Analysis.HitGroup b) {
                int c = Float.compare(a.charSpeed, b.charSpeed);
                return c != 0 ? c : Float.compare(a.bulletSpeed, b.bulletSpeed);
            }
        });
        d.groups.addAll(gs);

        /* ---- ④ 空白区间 ---- */
        boolean open = false;
        float from = 0f;
        for (int i = 0; i < cells; i++) {
            boolean empty = d.cellTotal[i] == 0;
            if (empty && !open) {
                open = true;
                from = i * cw;
            } else if (!empty && open) {
                open = false;
                d.dead.add(new float[]{from, i * cw});
            }
        }
        if (open) d.dead.add(new float[]{from, total});

        /* ---- ⑤ 日志 ---- */
        if (d.measured) {
            rep.log("实测交火 " + d.volley + " 次 · 打中 " + d.hitDist.size()
                    + " · 没打中 " + d.missDist.size());
            rep.log("覆盖距离 " + Math.round(d.mMin) + "~" + Math.round(d.mMax) + "m");
            rep.log("未覆盖区间 " + d.dead.size() + " 段");
        }
    }
}

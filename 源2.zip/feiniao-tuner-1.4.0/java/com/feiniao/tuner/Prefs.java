package com.feiniao.tuner;

import android.content.Context;
import android.content.SharedPreferences;

/** 轻量偏好存储 */
public final class Prefs {
    private static SharedPreferences sp;

    private Prefs() {}

    public static void init(Context c) {
        if (sp == null) {
            sp = c.getApplicationContext().getSharedPreferences("feiniao_tuner", Context.MODE_PRIVATE);
        }
    }

    public static String getStr(String k, String def) {
        try { return sp.getString(k, def); } catch (Throwable t) { return def; }
    }

    public static void setStr(String k, String v) { sp.edit().putString(k, v).apply(); }

    public static float getF(String k, float def) {
        try { return sp.getFloat(k, def); } catch (Throwable t) { return def; }
    }

    public static void setF(String k, float v) { sp.edit().putFloat(k, v).apply(); }

    public static int getI(String k, int def) {
        try { return sp.getInt(k, def); } catch (Throwable t) { return def; }
    }

    public static void setI(String k, int v) { sp.edit().putInt(k, v).apply(); }

    public static boolean getB(String k, boolean def) {
        try { return sp.getBoolean(k, def); } catch (Throwable t) { return def; }
    }

    public static void setB(String k, boolean v) { sp.edit().putBoolean(k, v).apply(); }
}
